# CampusConnect - Complete Step-by-Step Setup Guide for Beginners

## Table of Contents
1. [Prerequisites & Understanding](#prerequisites)
2. [Part 1: Setting Up Your Development Environment](#part-1-development-environment)
3. [Part 2: Creating the Database](#part-2-database-setup)
4. [Part 3: Building the Backend](#part-3-backend-setup)
5. [Part 4: Connecting Frontend to Backend](#part-4-frontend-integration)
6. [Part 5: Testing Everything](#part-5-testing)
7. [Part 6: Deploying to Production](#part-6-deployment)

---

## Prerequisites & Understanding

### What You Need to Know

Before we start, let's understand the basic architecture:

\`\`\`
┌─────────────────────────────────────────────────────────────┐
│                    YOUR BROWSER                             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Frontend (HTML, CSS, JavaScript)                    │   │
│  │  - Login page, dashboards, forms                     │   │
│  │  - Sends requests to Backend                         │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                          ↕ (HTTP Requests)
┌─────────────────────────────────────────────────────────────┐
│                    YOUR SERVER                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Backend (Node.js + Express)                         │   │
│  │  - Receives requests from Frontend                   │   │
│  │  - Processes data, validates input                   │   │
│  │  - Stores/retrieves data from Database               │   │
│  │  - Sends responses back to Frontend                  │   │
│  └──────────────────────────────────────────────────────┘   │
│                          ↕                                   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Database (PostgreSQL)                               │   │
│  │  - Stores all user data, resources, events, etc.     │   │
│  │  - Organized in tables (like Excel sheets)           │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
\`\`\`

### What You'll Need to Install

1. **Node.js** - JavaScript runtime (like Python for JavaScript)
2. **PostgreSQL** - Database to store data
3. **Git** - Version control (optional but recommended)
4. **VS Code** - Code editor
5. **Postman** - Tool to test API endpoints

---

## Part 1: Development Environment Setup

### Step 1.1: Install Node.js

**What is Node.js?** It's a runtime that lets you run JavaScript on your computer (not just in browsers).

**Installation:**

1. Go to https://nodejs.org
2. Download the **LTS (Long Term Support)** version
3. Run the installer and follow the steps
4. Accept all default options
5. Restart your computer

**Verify Installation:**
\`\`\`bash
# Open Command Prompt (Windows) or Terminal (Mac/Linux)
node --version
npm --version
\`\`\`

You should see version numbers like `v18.17.0` and `9.6.7`

---

### Step 1.2: Install PostgreSQL

**What is PostgreSQL?** It's a database - a place to store all your data in organized tables.

**Installation:**

1. Go to https://www.postgresql.org/download
2. Download for your operating system
3. Run the installer
4. When asked for a password, remember it (you'll need it later)
5. Keep the default port as 5432
6. Complete the installation

**Verify Installation:**
\`\`\`bash
psql --version
\`\`\`

---

### Step 1.3: Install VS Code

**What is VS Code?** It's a code editor where you'll write your backend code.

1. Go to https://code.visualstudio.com
2. Download and install
3. Open VS Code

**Install Extensions in VS Code:**
- Click Extensions (left sidebar)
- Search and install:
  - "Prisma" (for database management)
  - "REST Client" (for testing APIs)
  - "Thunder Client" (alternative to Postman)

---

### Step 1.4: Install Postman (Optional but Recommended)

**What is Postman?** It's a tool to test your API endpoints without needing the frontend.

1. Go to https://www.postman.com/downloads
2. Download and install
3. Create a free account

---

## Part 2: Database Setup

### Step 2.1: Create Your Database

**What we're doing:** Creating an empty database where all your data will be stored.

**Using pgAdmin (GUI - Easier):**

1. Open pgAdmin (installed with PostgreSQL)
2. Right-click "Databases" → "Create" → "Database"
3. Name it: `campusconnect`
4. Click "Save"

**Using Command Line (Alternative):**
\`\`\`bash
psql -U postgres
# Enter your password when prompted

# Inside psql:
CREATE DATABASE campusconnect;
\q  # Exit psql
\`\`\`

---

### Step 2.2: Create Database Tables

**What we're doing:** Creating the structure (tables) where data will be stored.

**Option A: Using Prisma (Recommended - We'll do this in Part 3)**

**Option B: Manual SQL (If you want to do it now)**

1. Open pgAdmin
2. Right-click your `campusconnect` database → "Query Tool"
3. Copy and paste the SQL from `DATABASE_DOCUMENTATION.md`
4. Click "Execute"

---

## Part 3: Backend Setup

### Step 3.1: Create Backend Project Folder

\`\`\`bash
# Create a folder for your backend
mkdir campusconnect-backend
cd campusconnect-backend

# Initialize Node.js project
npm init -y

# This creates a package.json file (like a recipe for your project)
\`\`\`

---

### Step 3.2: Install Required Packages

**What are packages?** They're pre-written code libraries that do common tasks.

\`\`\`bash
# Install Express (web framework)
npm install express

# Install Prisma (database tool)
npm install @prisma/client
npm install -D prisma

# Install other essential packages
npm install jsonwebtoken bcryptjs dotenv cors express-validator multer

# Install development tools
npm install -D nodemon  # Auto-restarts server when you make changes
\`\`\`

---

### Step 3.3: Setup Prisma

**What is Prisma?** It's a tool that makes it easy to work with databases.

\`\`\`bash
# Initialize Prisma
npx prisma init

# This creates:
# - prisma/schema.prisma (database structure)
# - .env (configuration file)
\`\`\`

---

### Step 3.4: Configure Database Connection

**Edit `.env` file:**

\`\`\`
DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@localhost:5432/campusconnect"
JWT_SECRET="your_super_secret_key_change_this_in_production"
PORT=5000
NODE_ENV=development
\`\`\`

Replace `YOUR_PASSWORD` with the password you set during PostgreSQL installation.

---

### Step 3.5: Create Database Schema

**Edit `prisma/schema.prisma`:**

Replace everything with this:

\`\`\`prisma
// This file defines your database structure

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// User model - stores user information
model User {
  id            Int     @id @default(autoincrement())
  regNumber     String  @unique
  name          String
  email         String? @unique
  password      String
  role          String  // "student", "teacher", "organizer", "admin"
  branch        String?
  semester      String?
  profileImage  String?
  bio           String?
  points        Int     @default(0)
  isBanned      Boolean @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  // Relationships
  resources     Resource[]
  marketplace   MarketplaceItem[]
  events        Event[]
  registrations EventRegistration[]
  discussions   Discussion[]
  comments      Comment[]
  lostFound     LostFoundItem[]
  announcements Announcement[]
  votes         Vote[]

  @@index([regNumber])
  @@index([role])
}

// Resource model - stores uploaded study materials
model Resource {
  id              Int     @id @default(autoincrement())
  title           String
  subject         String
  description     String?
  branch          String?
  semester        String?
  fileUrl         String
  fileName        String?
  uploadedById    Int
  uploadedBy      User    @relation(fields: [uploadedById], references: [id], onDelete: Cascade)
  status          String  @default("pending") // "pending", "verified", "rejected"
  verifiedById    Int?
  downloads       Int     @default(0)
  upvotes         Int     @default(0)
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  votes           Vote[]
  wishlist        Wishlist[]

  @@index([subject])
  @@index([branch])
  @@index([status])
}

// Marketplace model - stores items for buying/selling
model MarketplaceItem {
  id            Int     @id @default(autoincrement())
  title         String
  price         Float
  description   String?
  imageUrl      String?
  contact       String
  postedById    Int
  postedBy      User    @relation(fields: [postedById], references: [id], onDelete: Cascade)
  sold          Boolean @default(false)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  @@index([postedById])
  @@index([sold])
}

// Event model - stores campus events
model Event {
  id                  Int     @id @default(autoincrement())
  title               String
  description         String?
  date                DateTime
  venue               String
  googleFormUrl       String?
  posterUrl           String?
  organizerId         Int
  organizer           User    @relation(fields: [organizerId], references: [id], onDelete: Cascade)
  registrationClosed  Boolean @default(false)
  createdAt           DateTime @default(now())
  updatedAt           DateTime @updatedAt

  registrations       EventRegistration[]

  @@index([organizerId])
  @@index([date])
}

// Event Registration model - tracks who registered for events
model EventRegistration {
  id          Int     @id @default(autoincrement())
  eventId     Int
  event       Event   @relation(fields: [eventId], references: [id], onDelete: Cascade)
  userId      Int
  user        User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  registeredAt DateTime @default(now())

  @@unique([eventId, userId])
  @@index([eventId])
  @@index([userId])
}

// Discussion model - stores community discussions
model Discussion {
  id        Int     @id @default(autoincrement())
  title     String
  content   String
  category  String  @default("general") // "general", "academic", "events", "help"
  postedById Int
  postedBy  User    @relation(fields: [postedById], references: [id], onDelete: Cascade)
  upvotes   Int     @default(0)
  downvotes Int     @default(0)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  comments  Comment[]
  votes     Vote[]

  @@index([category])
  @@index([postedById])
}

// Comment model - stores discussion comments
model Comment {
  id            Int     @id @default(autoincrement())
  discussionId  Int
  discussion    Discussion @relation(fields: [discussionId], references: [id], onDelete: Cascade)
  postedById    Int
  postedBy      User    @relation(fields: [postedById], references: [id], onDelete: Cascade)
  content       String
  createdAt     DateTime @default(now())

  @@index([discussionId])
  @@index([postedById])
}

// Lost & Found model - stores lost and found items
model LostFoundItem {
  id        Int     @id @default(autoincrement())
  type      String  // "lost" or "found"
  itemName  String
  description String?
  location  String?
  contact   String
  imageUrl  String?
  postedById Int
  postedBy  User    @relation(fields: [postedById], references: [id], onDelete: Cascade)
  resolved  Boolean @default(false)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([type])
  @@index([postedById])
  @@index([resolved])
}

// Vote model - tracks upvotes/downvotes
model Vote {
  id          Int     @id @default(autoincrement())
  userId      Int
  user        User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  targetType  String  // "resource", "discussion", "comment"
  targetId    Int
  voteType    String  // "upvote", "downvote"
  createdAt   DateTime @default(now())

  @@unique([userId, targetType, targetId])
  @@index([userId])
}

// Announcement model - stores announcements
model Announcement {
  id        Int     @id @default(autoincrement())
  title     String
  content   String
  postedById Int
  postedBy  User    @relation(fields: [postedById], references: [id], onDelete: Cascade)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  @@index([postedById])
}

// Wishlist model - stores user wishlists
model Wishlist {
  id          Int     @id @default(autoincrement())
  userId      Int
  resourceId  Int
  resource    Resource @relation(fields: [resourceId], references: [id], onDelete: Cascade)
  addedAt     DateTime @default(now())

  @@unique([userId, resourceId])
  @@index([userId])
}
\`\`\`

---

### Step 3.6: Create Database Tables from Schema

\`\`\`bash
# This creates all tables in your database based on the schema
npx prisma migrate dev --name init

# When asked for a name, type: init
# This creates the tables in your PostgreSQL database
\`\`\`

**Verify it worked:**
\`\`\`bash
# Open pgAdmin and check if tables were created
# You should see: users, resources, events, discussions, etc.
\`\`\`

---

### Step 3.7: Create Project Structure

Create these folders in your `campusconnect-backend` folder:

\`\`\`
campusconnect-backend/
├── src/
│   ├── routes/
│   ├── controllers/
│   ├── middleware/
│   ├── utils/
│   └── app.js
├── prisma/
│   └── schema.prisma
├── .env
├── .gitignore
├── package.json
└── server.js
\`\`\`

**Create `.gitignore` file:**
\`\`\`
node_modules/
.env
.env.local
uploads/
*.log
\`\`\`

---

### Step 3.8: Create Main Server File

**Create `server.js`:**

\`\`\`javascript
const app = require('./src/app');

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
\`\`\`

---

### Step 3.9: Create Express App

**Create `src/app.js`:**

\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test route
app.get('/api/test', (req, res) => {
  res.json({ message: 'Backend is working!' });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

module.exports = app;
\`\`\`

---

### Step 3.10: Test Your Backend

\`\`\`bash
# Start the server
npm start

# You should see: "Server running on http://localhost:5000"
\`\`\`

**Test in browser:**
- Go to http://localhost:5000/api/test
- You should see: `{"message":"Backend is working!"}`

---

## Part 4: Frontend Integration

### Step 4.1: Update Frontend to Connect to Backend

**Edit your `script.js` file in the frontend:**

Find the login function and update it:

\`\`\`javascript
// OLD CODE (commented out)
// const users = JSON.parse(localStorage.getItem('users')) || [];

// NEW CODE - Connect to backend
async function login(regNumber, password) {
  try {
    const response = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ regNumber, password })
    });

    const data = await response.json();

    if (response.ok) {
      // Save token to localStorage
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      
      // Redirect to dashboard
      window.location.href = 'dashboard.html';
    } else {
      alert(data.message || 'Login failed');
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('Connection error. Make sure backend is running.');
  }
}
\`\`\`

---

### Step 4.2: Create Backend Authentication Endpoints

**Create `src/middleware/auth.js`:**

\`\`\`javascript
const jwt = require('jsonwebtoken');

const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};

module.exports = authMiddleware;
\`\`\`

**Create `src/controllers/authController.js`:**

\`\`\`javascript
const { PrismaClient } = require('@prisma/client');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

// Login
exports.login = async (req, res) => {
  try {
    const { regNumber, password } = req.body;

    // Find user
    const user = await prisma.user.findUnique({
      where: { regNumber }
    });

    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    // Generate token
    const token = jwt.sign(
      { userId: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        regNumber: user.regNumber,
        name: user.name,
        role: user.role,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};

// Register (Admin only)
exports.register = async (req, res) => {
  try {
    const { regNumber, password, name, role, email } = req.body;

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = await prisma.user.create({
      data: {
        regNumber,
        password: hashedPassword,
        name,
        role,
        email
      }
    });

    res.status(201).json({
      success: true,
      message: 'User created successfully',
      user: {
        id: user.id,
        regNumber: user.regNumber,
        name: user.name,
        role: user.role
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};
\`\`\`

**Create `src/routes/auth.js`:**

\`\`\`javascript
const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

router.post('/login', authController.login);
router.post('/register', authController.register);

module.exports = router;
\`\`\`

**Update `src/app.js`:**

\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/auth');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);

// Test route
app.get('/api/test', (req, res) => {
  res.json({ message: 'Backend is working!' });
});

module.exports = app;
\`\`\`

---

### Step 4.3: Create Sample Users in Database

**Create `scripts/seed.js`:**

\`\`\`javascript
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  // Create sample users
  const hashedPassword = await bcrypt.hash('password123', 10);

  const student = await prisma.user.create({
    data: {
      regNumber: '23L31A0501',
      name: 'User_0501',
      email: 'user@viit.ac.in',
      password: hashedPassword,
      role: 'student',
      branch: 'CSE',
      semester: '3-1'
    }
  });

  const admin = await prisma.user.create({
    data: {
      regNumber: 'ADMIN01',
      name: 'Admin User',
      email: 'admin@viit.ac.in',
      password: hashedPassword,
      role: 'admin'
    }
  });

  console.log('Sample users created:', { student, admin });
}

main()
  .catch(e => console.error(e))
  .finally(async () => await prisma.$disconnect());
\`\`\`

**Run the seed script:**
\`\`\`bash
node scripts/seed.js
\`\`\`

---

### Step 4.4: Test Login

1. Start your backend: `npm start`
2. Open your frontend in browser
3. Try logging in with:
   - **Username**: 23L31A0501
   - **Password**: password123

---

## Part 5: Testing Everything

### Step 5.1: Test with Postman

1. Open Postman
2. Create a new request
3. Set method to `POST`
4. URL: `http://localhost:5000/api/auth/login`
5. Go to "Body" tab → "raw" → select "JSON"
6. Paste:
\`\`\`json
{
  "regNumber": "23L31A0501",
  "password": "password123"
}
\`\`\`
7. Click "Send"
8. You should get a response with a token

---

### Step 5.2: Common Issues & Solutions

**Issue: "Cannot find module 'express'"**
\`\`\`bash
# Solution: Install dependencies
npm install
\`\`\`

**Issue: "Connection refused" when connecting to database**
\`\`\`bash
# Solution: Make sure PostgreSQL is running
# Windows: Check Services
# Mac: brew services list
# Linux: sudo systemctl status postgresql
\`\`\`

**Issue: "EADDRINUSE: address already in use :::5000"**
\`\`\`bash
# Solution: Another app is using port 5000
# Kill the process or use a different port
\`\`\`

**Issue: Frontend can't connect to backend**
\`\`\`bash
# Make sure:
# 1. Backend is running (npm start)
# 2. Frontend is using correct URL (http://localhost:5000)
# 3. CORS is enabled in backend
\`\`\`

---

## Part 6: Deployment to Production

### Step 6.1: Choose a Hosting Provider

**Recommended: Render (Free tier available)**

1. Go to https://render.com
2. Sign up with GitHub
3. Create a new "Web Service"
4. Connect your GitHub repository
5. Set environment variables
6. Deploy

**Alternative: Railway**

1. Go to https://railway.app
2. Sign up
3. Create new project
4. Connect GitHub
5. Deploy

---

### Step 6.2: Prepare for Production

**Update `.env` for production:**
\`\`\`
DATABASE_URL="postgresql://user:password@your-db-host:5432/campusconnect"
JWT_SECRET="generate-a-random-secret-key-here"
PORT=5000
NODE_ENV=production
FRONTEND_URL="https://your-frontend-domain.com"
\`\`\`

**Update CORS in `src/app.js`:**
\`\`\`javascript
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true
}));
\`\`\`

---

### Step 6.3: Deploy Database

**Using Supabase (PostgreSQL + Auth):**

1. Go to https://supabase.com
2. Create new project
3. Copy connection string
4. Update `DATABASE_URL` in `.env`
5. Run migrations: `npx prisma migrate deploy`

---

## Summary

You now have:
✅ A working backend server
✅ A PostgreSQL database
✅ Authentication system
✅ Frontend connected to backend
✅ Ready to add more features

### Next Steps:
1. Add more API endpoints (resources, events, discussions)
2. Implement file uploads
3. Add more validation
4. Deploy to production
5. Monitor and optimize

---

## Helpful Resources

- **Node.js Docs**: https://nodejs.org/docs
- **Express Docs**: https://expressjs.com
- **Prisma Docs**: https://www.prisma.io/docs
- **PostgreSQL Docs**: https://www.postgresql.org/docs
- **JWT Explanation**: https://jwt.io/introduction
- **REST API Guide**: https://restfulapi.net

---

## Getting Help

If you get stuck:
1. Read the error message carefully
2. Google the error message
3. Check the documentation
4. Ask in developer communities (Stack Overflow, Reddit r/learnprogramming)

Good luck! 🚀
