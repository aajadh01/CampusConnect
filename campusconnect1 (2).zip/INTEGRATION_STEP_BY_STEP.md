# FRONTEND-BACKEND INTEGRATION - COMPLETE GUIDE
## Connecting Your Website to the Backend

---

## PART 1: UNDERSTANDING THE CONNECTION

### How Frontend Talks to Backend

**Before (Frontend Only):**
\`\`\`
User clicks button → JavaScript function → Data stored in localStorage
\`\`\`

**After (With Backend):**
\`\`\`
User clicks button → JavaScript function → Send request to backend → 
Backend processes → Database stores → Response sent back → Update frontend
\`\`\`

### What We're Doing

We're replacing all the `localStorage` calls with **API calls** to the backend.

---

## PART 2: SETUP FRONTEND FOR API CALLS

### Step 1: Create API Helper File

Create a new file `api-helper.js` in your project root:

\`\`\`javascript
// API Configuration
const API_BASE_URL = 'http://localhost:5000/api';

// Store token in localStorage
function setToken(token) {
  localStorage.setItem('authToken', token);
}

// Get token from localStorage
function getToken() {
  return localStorage.getItem('authToken');
}

// Make API requests
async function apiCall(endpoint, method = 'GET', data = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${getToken()}`
    }
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'API request failed');
    }

    return await response.json();
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}

// Authentication APIs
async function registerUser(email, password, fullName, role, department) {
  return apiCall('/auth/register', 'POST', {
    email,
    password,
    fullName,
    role,
    department
  });
}

async function loginUser(email, password) {
  return apiCall('/auth/login', 'POST', {
    email,
    password
  });
}

async function getCurrentUser() {
  return apiCall('/auth/me', 'GET');
}

// Resources APIs
async function getAllResources() {
  return apiCall('/resources', 'GET');
}

async function getResourceById(id) {
  return apiCall(`/resources/${id}`, 'GET');
}

async function createResource(title, description, category, fileUrl) {
  return apiCall('/resources', 'POST', {
    title,
    description,
    category,
    fileUrl
  });
}

async function deleteResource(id) {
  return apiCall(`/resources/${id}`, 'DELETE');
}

// Events APIs
async function getAllEvents() {
  return apiCall('/events', 'GET');
}

async function getEventById(id) {
  return apiCall(`/events/${id}`, 'GET');
}

async function createEvent(title, description, date, location, category, maxAttendees, imageUrl) {
  return apiCall('/events', 'POST', {
    title,
    description,
    date,
    location,
    category,
    maxAttendees,
    imageUrl
  });
}

async function joinEvent(eventId) {
  return apiCall(`/events/${eventId}/join`, 'POST');
}

async function leaveEvent(eventId) {
  return apiCall(`/events/${eventId}/leave`, 'POST');
}

async function deleteEvent(id) {
  return apiCall(`/events/${id}`, 'DELETE');
}

// Discussions APIs
async function getAllDiscussions() {
  return apiCall('/discussions', 'GET');
}

async function getDiscussionById(id) {
  return apiCall(`/discussions/${id}`, 'GET');
}

async function createDiscussion(title, description, category) {
  return apiCall('/discussions', 'POST', {
    title,
    description,
    category
  });
}

async function addComment(discussionId, comment) {
  return apiCall(`/discussions/${discussionId}/comments`, 'POST', {
    comment
  });
}

async function voteComment(commentId, voteType) {
  return apiCall(`/discussions/comments/${commentId}/vote`, 'POST', {
    voteType
  });
}

async function deleteDiscussion(id) {
  return apiCall(`/discussions/${id}`, 'DELETE');
}

// Marketplace APIs
async function getAllMarketplaceItems() {
  return apiCall('/marketplace', 'GET');
}

async function getMarketplaceItemById(id) {
  return apiCall(`/marketplace/${id}`, 'GET');
}

async function createMarketplaceItem(title, description, price, category, imageUrl, condition) {
  return apiCall('/marketplace', 'POST', {
    title,
    description,
    price,
    category,
    imageUrl,
    condition
  });
}

async function updateMarketplaceItemStatus(id, status) {
  return apiCall(`/marketplace/${id}/status`, 'PATCH', {
    status
  });
}

async function deleteMarketplaceItem(id) {
  return apiCall(`/marketplace/${id}`, 'DELETE');
}

// Lost & Found APIs
async function getAllLostFoundItems() {
  return apiCall('/lost-found', 'GET');
}

async function getLostFoundItemById(id) {
  return apiCall(`/lost-found/${id}`, 'GET');
}

async function createLostFoundItem(title, description, type, location, imageUrl) {
  return apiCall('/lost-found', 'POST', {
    title,
    description,
    type,
    location,
    imageUrl
  });
}

async function updateLostFoundItemStatus(id, status) {
  return apiCall(`/lost-found/${id}/status`, 'PATCH', {
    status
  });
}

async function deleteLostFoundItem(id) {
  return apiCall(`/lost-found/${id}`, 'DELETE');
}

// Logout
function logout() {
  localStorage.removeItem('authToken');
  localStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}
\`\`\`

### Step 2: Add API Helper to HTML Files

Add this line to the `<head>` section of all your HTML files (before other scripts):

\`\`\`html
<script src="api-helper.js"></script>
\`\`\`

---

## PART 3: UPDATE LOGIN PAGE

### Update `login.html` script section:

Find the login form submission and replace with:

\`\`\`javascript
// Login form submission
document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  try {
    const response = await loginUser(email, password);
    
    // Store token
    setToken(response.token);
    
    // Store user info
    localStorage.setItem('currentUser', JSON.stringify(response.user));
    
    // Redirect based on role
    const role = response.user.role;
    if (role === 'student') {
      window.location.href = 'student-dashboard.html';
    } else if (role === 'faculty') {
      window.location.href = 'dashboard.html';
    } else if (role === 'organizer') {
      window.location.href = 'organizer-dashboard.html';
    } else if (role === 'admin') {
      window.location.href = 'admin-user-management.html';
    }
  } catch (error) {
    alert('Login failed: ' + error.message);
  }
});
\`\`\`

---

## PART 4: UPDATE STUDENT DASHBOARD

### Update Resources Section:

\`\`\`javascript
// Load resources
async function loadResources() {
  try {
    const resources = await getAllResources();
    
    const resourcesList = document.getElementById('resourcesList');
    resourcesList.innerHTML = '';
    
    resources.forEach(resource => {
      const resourceCard = document.createElement('div');
      resourceCard.className = 'resource-card';
      resourceCard.innerHTML = `
        <h3>${resource.title}</h3>
        <p>${resource.description}</p>
        <p><strong>Category:</strong> ${resource.category}</p>
        <p><strong>Uploaded by:</strong> ${resource.uploadedBy.fullName}</p>
        <a href="${resource.fileUrl}" target="_blank" class="btn">Download</a>
        ${resource.uploadedById === getCurrentUserId() ? `
          <button onclick="deleteResourceItem(${resource.id})" class="btn btn-danger">Delete</button>
        ` : ''}
      `;
      resourcesList.appendChild(resourceCard);
    });
  } catch (error) {
    console.error('Failed to load resources:', error);
  }
}

// Upload resource
document.getElementById('uploadResourceForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = document.getElementById('resourceTitle').value;
  const description = document.getElementById('resourceDescription').value;
  const category = document.getElementById('resourceCategory').value;
  const fileUrl = document.getElementById('resourceFileUrl').value;

  try {
    await createResource(title, description, category, fileUrl);
    alert('Resource uploaded successfully!');
    document.getElementById('uploadResourceForm').reset();
    loadResources();
  } catch (error) {
    alert('Failed to upload resource: ' + error.message);
  }
});

// Delete resource
async function deleteResourceItem(id) {
  if (confirm('Are you sure you want to delete this resource?')) {
    try {
      await deleteResource(id);
      alert('Resource deleted successfully!');
      loadResources();
    } catch (error) {
      alert('Failed to delete resource: ' + error.message);
    }
  }
}

// Load on page load
loadResources();
\`\`\`

### Update Events Section:

\`\`\`javascript
// Load events
async function loadEvents() {
  try {
    const events = await getAllEvents();
    
    const eventsList = document.getElementById('eventsList');
    eventsList.innerHTML = '';
    
    events.forEach(event => {
      const eventCard = document.createElement('div');
      eventCard.className = 'event-card';
      
      const isAttending = event.attendees.some(a => a.userId === getCurrentUserId());
      
      eventCard.innerHTML = `
        <h3>${event.title}</h3>
        <p>${event.description}</p>
        <p><strong>Date:</strong> ${new Date(event.date).toLocaleString()}</p>
        <p><strong>Location:</strong> ${event.location}</p>
        <p><strong>Organizer:</strong> ${event.organizer.fullName}</p>
        <p><strong>Attendees:</strong> ${event.attendees.length}${event.maxAttendees ? `/${event.maxAttendees}` : ''}</p>
        ${isAttending ? `
          <button onclick="leaveEventItem(${event.id})" class="btn btn-danger">Leave Event</button>
        ` : `
          <button onclick="joinEventItem(${event.id})" class="btn">Join Event</button>
        `}
      `;
      eventsList.appendChild(eventCard);
    });
  } catch (error) {
    console.error('Failed to load events:', error);
  }
}

// Join event
async function joinEventItem(eventId) {
  try {
    await joinEvent(eventId);
    alert('Joined event successfully!');
    loadEvents();
  } catch (error) {
    alert('Failed to join event: ' + error.message);
  }
}

// Leave event
async function leaveEventItem(eventId) {
  try {
    await leaveEvent(eventId);
    alert('Left event successfully!');
    loadEvents();
  } catch (error) {
    alert('Failed to leave event: ' + error.message);
  }
}

// Create event (for organizers)
document.getElementById('createEventForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = document.getElementById('eventTitle').value;
  const description = document.getElementById('eventDescription').value;
  const date = document.getElementById('eventDate').value;
  const location = document.getElementById('eventLocation').value;
  const category = document.getElementById('eventCategory').value;
  const maxAttendees = document.getElementById('eventMaxAttendees').value;
  const imageUrl = document.getElementById('eventImageUrl').value;

  try {
    await createEvent(title, description, date, location, category, maxAttendees, imageUrl);
    alert('Event created successfully!');
    document.getElementById('createEventForm').reset();
    loadEvents();
  } catch (error) {
    alert('Failed to create event: ' + error.message);
  }
});

// Load on page load
loadEvents();
\`\`\`

### Update Discussions Section:

\`\`\`javascript
// Load discussions
async function loadDiscussions() {
  try {
    const discussions = await getAllDiscussions();
    
    const discussionsList = document.getElementById('discussionsList');
    discussionsList.innerHTML = '';
    
    discussions.forEach(discussion => {
      const discussionCard = document.createElement('div');
      discussionCard.className = 'discussion-card';
      discussionCard.innerHTML = `
        <h3>${discussion.title}</h3>
        <p>${discussion.description}</p>
        <p><strong>Category:</strong> ${discussion.category}</p>
        <p><strong>Created by:</strong> ${discussion.createdBy.fullName}</p>
        <p><strong>Comments:</strong> ${discussion.comments.length}</p>
        <button onclick="viewDiscussion(${discussion.id})" class="btn">View Discussion</button>
        ${discussion.createdById === getCurrentUserId() ? `
          <button onclick="deleteDiscussionItem(${discussion.id})" class="btn btn-danger">Delete</button>
        ` : ''}
      `;
      discussionsList.appendChild(discussionCard);
    });
  } catch (error) {
    console.error('Failed to load discussions:', error);
  }
}

// View discussion details
async function viewDiscussion(discussionId) {
  try {
    const discussion = await getDiscussionById(discussionId);
    
    // Display discussion details
    const modal = document.getElementById('discussionModal');
    modal.innerHTML = `
      <div class="modal-content">
        <span class="close" onclick="this.parentElement.parentElement.style.display='none'">&times;</span>
        <h2>${discussion.title}</h2>
        <p>${discussion.description}</p>
        
        <h3>Comments:</h3>
        <div id="commentsList"></div>
        
        <form id="addCommentForm">
          <textarea id="commentText" placeholder="Add a comment..." required></textarea>
          <button type="submit" class="btn">Post Comment</button>
        </form>
      `;
      
      // Load comments
      const commentsList = modal.querySelector('#commentsList');
      discussion.comments.forEach(comment => {
        const commentDiv = document.createElement('div');
        commentDiv.className = 'comment';
        commentDiv.innerHTML = `
          <p><strong>${comment.user.fullName}:</strong> ${comment.comment}</p>
          <p>Upvotes: ${comment.upvotes} | Downvotes: ${comment.downvotes}</p>
          <button onclick="voteOnComment(${comment.id}, 'upvote')" class="btn-small">👍 Upvote</button>
          <button onclick="voteOnComment(${comment.id}, 'downvote')" class="btn-small">👎 Downvote</button>
        `;
        commentsList.appendChild(commentDiv);
      });
      
      // Add comment form
      modal.querySelector('#addCommentForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const comment = document.getElementById('commentText').value;
        try {
          await addComment(discussionId, comment);
          alert('Comment added!');
          viewDiscussion(discussionId); // Refresh
        } catch (error) {
          alert('Failed to add comment: ' + error.message);
        }
      });
      
      modal.style.display = 'block';
  } catch (error) {
    alert('Failed to load discussion: ' + error.message);
  }
}

// Vote on comment
async function voteOnComment(commentId, voteType) {
  try {
    await voteComment(commentId, voteType);
    alert('Vote recorded!');
  } catch (error) {
    alert('Failed to vote: ' + error.message);
  }
}

// Delete discussion
async function deleteDiscussionItem(id) {
  if (confirm('Are you sure you want to delete this discussion?')) {
    try {
      await deleteDiscussion(id);
      alert('Discussion deleted successfully!');
      loadDiscussions();
    } catch (error) {
      alert('Failed to delete discussion: ' + error.message);
    }
  }
}

// Create discussion
document.getElementById('createDiscussionForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = document.getElementById('discussionTitle').value;
  const description = document.getElementById('discussionDescription').value;
  const category = document.getElementById('discussionCategory').value;

  try {
    await createDiscussion(title, description, category);
    alert('Discussion created successfully!');
    document.getElementById('createDiscussionForm').reset();
    loadDiscussions();
  } catch (error) {
    alert('Failed to create discussion: ' + error.message);
  }
});

// Load on page load
loadDiscussions();
\`\`\`

### Update Marketplace Section:

\`\`\`javascript
// Load marketplace items
async function loadMarketplaceItems() {
  try {
    const items = await getAllMarketplaceItems();
    
    const itemsList = document.getElementById('marketplaceList');
    itemsList.innerHTML = '';
    
    items.forEach(item => {
      const itemCard = document.createElement('div');
      itemCard.className = 'marketplace-card';
      itemCard.innerHTML = `
        <h3>${item.title}</h3>
        <p>${item.description}</p>
        <p><strong>Price:</strong> ₹${item.price}</p>
        <p><strong>Condition:</strong> ${item.condition}</p>
        <p><strong>Seller:</strong> ${item.seller.fullName}</p>
        <p><strong>Contact:</strong> ${item.seller.phone || item.seller.email}</p>
        ${item.sellerId === getCurrentUserId() ? `
          <button onclick="markItemSold(${item.id})" class="btn">Mark as Sold</button>
          <button onclick="deleteMarketplaceItemFunc(${item.id})" class="btn btn-danger">Delete</button>
        ` : ''}
      `;
      itemsList.appendChild(itemCard);
    });
  } catch (error) {
    console.error('Failed to load marketplace items:', error);
  }
}

// Create marketplace item
document.getElementById('createMarketplaceForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = document.getElementById('itemTitle').value;
  const description = document.getElementById('itemDescription').value;
  const price = document.getElementById('itemPrice').value;
  const category = document.getElementById('itemCategory').value;
  const imageUrl = document.getElementById('itemImageUrl').value;
  const condition = document.getElementById('itemCondition').value;

  try {
    await createMarketplaceItem(title, description, price, category, imageUrl, condition);
    alert('Item listed successfully!');
    document.getElementById('createMarketplaceForm').reset();
    loadMarketplaceItems();
  } catch (error) {
    alert('Failed to list item: ' + error.message);
  }
});

// Mark item as sold
async function markItemSold(id) {
  try {
    await updateMarketplaceItemStatus(id, 'sold');
    alert('Item marked as sold!');
    loadMarketplaceItems();
  } catch (error) {
    alert('Failed to update item: ' + error.message);
  }
}

// Delete marketplace item
async function deleteMarketplaceItemFunc(id) {
  if (confirm('Are you sure you want to delete this item?')) {
    try {
      await deleteMarketplaceItem(id);
      alert('Item deleted successfully!');
      loadMarketplaceItems();
    } catch (error) {
      alert('Failed to delete item: ' + error.message);
    }
  }
}

// Load on page load
loadMarketplaceItems();
\`\`\`

### Update Lost & Found Section:

\`\`\`javascript
// Load lost & found items
async function loadLostFoundItems() {
  try {
    const items = await getAllLostFoundItems();
    
    const itemsList = document.getElementById('lostFoundList');
    itemsList.innerHTML = '';
    
    items.forEach(item => {
      const itemCard = document.createElement('div');
      itemCard.className = 'lost-found-card';
      itemCard.innerHTML = `
        <h3>${item.type.toUpperCase()}: ${item.title}</h3>
        <p>${item.description}</p>
        <p><strong>Location:</strong> ${item.location}</p>
        <p><strong>Reported by:</strong> ${item.reportedBy.fullName}</p>
        <p><strong>Contact:</strong> ${item.reportedBy.phone || item.reportedBy.email}</p>
        ${item.reportedById === getCurrentUserId() ? `
          <button onclick="markItemResolved(${item.id})" class="btn">Mark as Resolved</button>
          <button onclick="deleteLostFoundItemFunc(${item.id})" class="btn btn-danger">Delete</button>
        ` : ''}
      `;
      itemsList.appendChild(itemCard);
    });
  } catch (error) {
    console.error('Failed to load lost & found items:', error);
  }
}

// Create lost & found item
document.getElementById('createLostFoundForm')?.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const title = document.getElementById('lostFoundTitle').value;
  const description = document.getElementById('lostFoundDescription').value;
  const type = document.getElementById('lostFoundType').value;
  const location = document.getElementById('lostFoundLocation').value;
  const imageUrl = document.getElementById('lostFoundImageUrl').value;

  try {
    await createLostFoundItem(title, description, type, location, imageUrl);
    alert('Item reported successfully!');
    document.getElementById('createLostFoundForm').reset();
    loadLostFoundItems();
  } catch (error) {
    alert('Failed to report item: ' + error.message);
  }
});

// Mark item as resolved
async function markItemResolved(id) {
  try {
    await updateLostFoundItemStatus(id, 'resolved');
    alert('Item marked as resolved!');
    loadLostFoundItems();
  } catch (error) {
    alert('Failed to update item: ' + error.message);
  }
}

// Delete lost & found item
async function deleteLostFoundItemFunc(id) {
  if (confirm('Are you sure you want to delete this item?')) {
    try {
      await deleteLostFoundItem(id);
      alert('Item deleted successfully!');
      loadLostFoundItems();
    } catch (error) {
      alert('Failed to delete item: ' + error.message);
    }
  }
}

// Load on page load
loadLostFoundItems();
\`\`\`

---

## PART 5: HELPER FUNCTIONS

Add these helper functions to your `script.js`:

\`\`\`javascript
// Get current user ID
function getCurrentUserId() {
  const user = JSON.parse(localStorage.getItem('currentUser'));
  return user ? user.id : null;
}

// Check if user is logged in
function isLoggedIn() {
  return !!localStorage.getItem('authToken');
}

// Redirect if not logged in
function requireLogin() {
  if (!isLoggedIn()) {
    window.location.href = 'login.html';
  }
}

// Logout function
function logoutUser() {
  logout();
}
\`\`\`

---

## PART 6: TESTING THE INTEGRATION

### Step 1: Start Backend

\`\`\`bash
npm run dev
\`\`\`

### Step 2: Open Frontend

Open your HTML files in a browser

### Step 3: Test Each Feature

1. **Register** - Create a new account
2. **Login** - Login with your account
3. **Upload Resource** - Upload a study material
4. **Create Event** - Create an event
5. **Join Event** - Join an event
6. **Create Discussion** - Start a discussion
7. **Add Comment** - Comment on a discussion
8. **Vote** - Upvote/downvote comments
9. **Marketplace** - List an item for sale
10. **Lost & Found** - Report a lost item

---

## PART 7: TROUBLESHOOTING

### Problem: "CORS error"
**Solution:** Make sure backend is running and CORS is enabled

### Problem: "401 Unauthorized"
**Solution:** Make sure you're logged in and token is stored

### Problem: "404 Not Found"
**Solution:** Check API endpoint URLs match backend routes

### Problem: "Data not showing"
**Solution:** Check browser console for errors, verify backend is running

---

## SUMMARY

You now have:
✅ Frontend connected to backend
✅ All features working with real database
✅ User authentication
✅ Data persistence
✅ Multi-user support

**Congratulations! Your website is now fully functional!**

---
