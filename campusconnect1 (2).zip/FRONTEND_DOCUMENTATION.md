# CampusConnect - Frontend Project Documentation

## Project Overview

**CampusConnect** is a comprehensive role-based campus management platform for VIIT (Vignan's Institute of Information Technology). It provides a unified ecosystem for **Students, Faculty, Organizers, and Admins** to collaborate, share resources, organize events, and engage in community discussions.

**Key Characteristic**: No public signup - only Admin creates users with credentials stored in database.

---

## Technology Stack

- **Frontend Framework**: HTML5, CSS3, JavaScript (Vanilla)
- **Architecture**: Multi-page application with role-based dashboards
- **State Management**: localStorage (client-side) + Backend API
- **Styling**: Custom CSS with responsive design
- **Icons & Assets**: SVG icons, PNG/JPG images stored in `/public/images/`

---

## Project Structure

\`\`\`
campusconnect/
├── index.html                    # Welcome page with "Get Started" button
├── dashboard.html                # Role selection page
├── login.html                    # Login page (shared across all roles)
├── student-dashboard.html        # Student dashboard
├── teacher-dashboard.html        # Faculty/Teacher dashboard
├── organizer-dashboard.html      # Event organizer dashboard
├── admin-user-management.html    # Admin user management page
├── script.js                     # Main application logic
├── admin-script.js               # Admin-specific functionality
├── styles.css                    # Global styles
├── styles-student.css            # Student dashboard styles
├── styles-faculty.css            # Faculty dashboard styles
├── styles-organizer.css          # Organizer dashboard styles
├── styles-admin.css              # Admin dashboard styles
├── public/
│   ├── images/
│   │   ├── viit-logo-circle.png  # VIIT institution logo
│   │   ├── viit-campus.jpg       # Campus building image
│   │   ├── event-icon.png        # Event management icon
│   │   └── hamburger.png         # Menu icon
│   └── placeholder.svg
└── package.json                  # Project dependencies
\`\`\`

---

## System Flow

### 1. Welcome Page (index.html)
- Displays welcome message
- Contains "Get Started" button
- Navigates to role selection dashboard

### 2. Role Selection Dashboard (dashboard.html)
- User selects role: **Student**, **Faculty**, **Organizer**, or **Admin**
- Redirects to login page with role context

### 3. Login (login.html)
- Users enter credentials (email/username + password)
- Backend validates against database
- On success, JWT token issued
- User redirected to appropriate dashboard

### 4. Dashboards (Role-Specific)
- **Student**: Access to resources, events, marketplace, discussions, lost & found
- **Faculty**: Access to resources, events, discussions, note verification
- **Organizer**: Create/manage events, post announcements
- **Admin**: User management, content moderation

---

## User Roles & Dashboards

### 1. **Student Dashboard** (`student-dashboard.html`)

**Home Section**
- Welcome message: "Welcome [User Name] ([Registered ID])"
- Dashboard cards showing:
  - Resources Uploaded
  - Events Registered
  - Points Earned
  - Community Posts
- Quick Actions for primary tasks

**Features**:
1. **Notes Section**
   - Display all uploaded notes (from Students and Faculty)
   - Filter by category or uploader type
   - Upload new notes
   - Download and view notes
   - Upvote notes
   - Add notes to Wishlist
   - Delete own notes

2. **Marketplace**
   - Display all marketplace posts
   - Each item shows images, descriptions, price
   - Upload items for sale
   - Delete own listings

3. **Events**
   - Display all events created by Organizers
   - Event cards: title, description, date, image
   - Register for events
   - View registered events

4. **Lost & Found**
   - Upload details and images of lost/found items
   - Display all existing posts
   - Filter by type (lost/found)

5. **Community**
   - Posts from all roles (Students, Faculty, Organizers)
   - Create posts
   - View all posts
   - Upvote/downvote posts
   - Reply to posts
   - View Organizer announcements

6. **Wishlist**
   - Display notes saved from Notes section
   - Quick access to saved resources

7. **Settings**
   - Change password
   - New password saved to database immediately

---

### 2. **Faculty Dashboard** (`teacher-dashboard.html`)

**Home Section**
- Welcome message: "Welcome [User Name] ([Registered ID])"
- Real-time counts of resources, events, posts

**Features**:
1. **Resources**
   - Display all notes (from Faculty and Students)
   - Same UI as Student Notes section
   - Upload, view, download, upvote, manage own notes

2. **Events**
   - Display same event list as Students
   - Register for events

3. **Community**
   - Display posts from Students, Faculty, Organizers
   - Create posts, upvote/downvote, reply

4. **Verify Notes**
   - Display all uploaded notes
   - Click "Verify" to approve note
   - Adds "Verified" tag to note

5. **Settings**
   - Password change functionality

---

### 3. **Organizer Dashboard** (`organizer-dashboard.html`)

**Home Section**
- Welcome message: "Welcome [Organizer Name] ([Organizer ID])"

**Features**:
1. **Create Event**
   - Form with: Title, description, date, images
   - On submission, event data displayed in Student/Faculty dashboards

2. **Manage Event**
   - List all created events
   - Edit or Delete events
   - Manage registered users for each event

3. **Announcements**
   - Post announcements visible to all Students and Faculty
   - Announcements appear in Community section
   - Delete announcements anytime

4. **Settings**
   - Change Organizer account password

---

### 4. **Admin Dashboard** (`admin-user-management.html`)

**Home Section**
- Welcome message: "Welcome Admin ([Admin Name])"

**Features**:
1. **Manage Users**
   - Create new users (Student, Faculty, Organizer)
   - Delete existing users
   - Change user passwords
   - All actions directly on database

2. **Manage Content**
   - Delete any post, note, event, announcement
   - Moderate user-generated content

3. **Settings**
   - Admin password change

---

## Authentication & Authorization

### Login Flow
1. User selects role on `dashboard.html`
2. Redirected to `login.html`
3. Enters email/username and password
4. Backend validates credentials against database
5. On success, JWT token issued
6. User data stored in localStorage
7. Redirected to role-specific dashboard

### Session Management
- User data stored in `localStorage` under key `currentUser`
- User role stored under key `userRole`
- JWT token stored under key `token`
- Logout clears localStorage and redirects to role selection

---

## Data Models

### User Object
\`\`\`javascript
{
  id: 1,
  email: "student@viit.ac.in",
  fullName: "John Doe",
  registeredId: "23L31A0501",
  role: "student",  // student | faculty | organizer | admin
  isActive: true,
  createdAt: "2024-10-17T10:30:00Z"
}
\`\`\`

### Resource Object
\`\`\`javascript
{
  id: 1,
  title: "DBMS Notes",
  category: "notes",
  description: "Comprehensive notes on DBMS",
  uploaderId: 1,
  uploaderName: "John Doe",
  uploaderRole: "student",
  filePath: "/uploads/dbms-notes.pdf",
  isVerified: false,
  upvoteCount: 12,
  downloadCount: 5,
  createdAt: "2024-10-17T10:30:00Z"
}
\`\`\`

### Event Object
\`\`\`javascript
{
  id: 1,
  title: "Tech Fest 2024",
  description: "Annual technology festival",
  eventDate: "2024-11-15",
  eventTime: "10:00 AM",
  location: "Main Auditorium",
  organizerId: 2,
  organizerName: "Event Team",
  imagePath: "/images/event-poster.jpg",
  registeredCount: 45,
  capacity: 100,
  createdAt: "2024-10-17T10:30:00Z"
}
\`\`\`

### Marketplace Item Object
\`\`\`javascript
{
  id: 1,
  title: "Physics Textbook",
  price: 250,
  description: "Used but in good condition",
  sellerId: 1,
  sellerName: "John Doe",
  imagePath: "/images/book.jpg",
  category: "books",
  condition: "good",
  contactInfo: "9876543210",
  isSold: false,
  createdAt: "2024-10-17T10:30:00Z"
}
\`\`\`

### Community Post Object
\`\`\`javascript
{
  id: 1,
  content: "Can anyone recommend good DBMS resources?",
  authorId: 1,
  authorName: "John Doe",
  authorRole: "student",
  upvoteCount: 5,
  downvoteCount: 1,
  replyCount: 3,
  createdAt: "2024-10-17T10:30:00Z",
  replies: [
    {
      id: 1,
      content: "Check the verified notes section",
      authorName: "Dr. Jane Smith",
      createdAt: "2024-10-17T11:00:00Z"
    }
  ]
}
\`\`\`

### Lost & Found Item Object
\`\`\`javascript
{
  id: 1,
  type: "lost",  // lost | found
  title: "Blue Backpack",
  description: "Contains laptop and books",
  location: "Library, 2nd Floor",
  posterId: 1,
  posterName: "John Doe",
  imagePath: "/images/backpack.jpg",
  contactInfo: "9876543210",
  isResolved: false,
  createdAt: "2024-10-17T10:30:00Z"
}
\`\`\`

---

## Global State Management

### AppState Object (in `script.js`)
\`\`\`javascript
const appState = {
  currentUser: null,              // Current logged-in user
  userRole: null,                 // User's role
  token: null,                    // JWT token
  resources: [],                  // All resources
  events: [],                     // All events
  discussions: [],                // All discussions
  marketplaceItems: [],           // All marketplace items
  lostFoundItems: [],             // All lost & found items
  announcements: [],              // All announcements
  wishlist: [],                   // User's wishlist
  userPoints: 0                   // User's points
}
\`\`\`

### LocalStorage Keys
- `currentUser`: Current user object
- `userRole`: Current user's role
- `token`: JWT authentication token
- `wishlist_[userId]`: User's wishlist items

---

## Key Functions & Features

### Authentication Functions
- `selectRole(role)`: Set selected role and redirect to login
- `handleLogin(email, password, role)`: Process login and store user data
- `logout()`: Clear session and return to role selection
- `checkAuth()`: Verify user is logged in

### Navigation & UI
- `navigateToSection(sectionId)`: Switch between dashboard sections
- `toggleModal(modalId)`: Open/close modal dialogs
- `toggleSidebar()`: Open/close mobile sidebar

### Resource Management
- `handleUploadResource(e)`: Upload study notes
- `renderResources()`: Display resources with filters
- `downloadResource(resourceId)`: Download resource file
- `upvoteResource(resourceId)`: Upvote a resource
- `deleteResource(resourceId)`: Delete a resource
- `verifyResource(id)`: Faculty verify resource

### Event Management
- `handleCreateEvent()`: Create new event
- `renderEvents()`: Display events
- `registerForEvent(eventId)`: Register for event
- `leaveEvent(eventId)`: Leave event

### Community Features
- `handlePostDiscussion(e)`: Post discussion
- `renderDiscussions()`: Display discussions
- `addComment(id)`: Add comment to discussion
- `upvoteComment(id)`: Upvote comment
- `downvoteComment(id)`: Downvote comment

### Marketplace Functions
- `handlePostItem(e)`: Post item for sale
- `renderMarketplace()`: Display marketplace items
- `deleteMarketplaceItem(itemId)`: Delete listing

### Lost & Found
- `handlePostLostFound(e)`: Report lost/found item
- `renderLostFound()`: Display lost & found items
- `deleteLostFound(itemId)`: Delete lost & found post

---

## Backend Integration Points

The frontend communicates with backend via REST API:

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout

### Resources
- `GET /api/resources` - Fetch all resources
- `POST /api/resources` - Upload resource
- `DELETE /api/resources/:id` - Delete resource
- `POST /api/resources/:id/upvote` - Upvote resource
- `POST /api/resources/:id/verify` - Verify resource (faculty)

### Events
- `GET /api/events` - Fetch all events
- `POST /api/events` - Create event
- `POST /api/events/:id/register` - Register for event
- `DELETE /api/events/:id` - Delete event

### Discussions
- `GET /api/discussions` - Fetch all discussions
- `POST /api/discussions` - Create discussion
- `POST /api/discussions/:id/comments` - Add comment
- `POST /api/discussions/comments/:id/vote` - Vote on comment

### Marketplace
- `GET /api/marketplace` - Fetch all items
- `POST /api/marketplace` - Post item
- `DELETE /api/marketplace/:id` - Delete item

### Lost & Found
- `GET /api/lost-found` - Fetch all items
- `POST /api/lost-found` - Report item
- `DELETE /api/lost-found/:id` - Delete item

---

## Features Matrix

| Feature | Student | Faculty | Organizer | Admin |
|---------|---------|---------|-----------|-------|
| Upload Resources | ✓ | ✓ | ✗ | ✗ |
| Verify Resources | ✗ | ✓ | ✗ | ✓ |
| Create Events | ✗ | ✗ | ✓ | ✗ |
| Register Events | ✓ | ✓ | ✗ | ✗ |
| Post Discussions | ✓ | ✓ | ✗ | ✗ |
| Marketplace | ✓ | ✗ | ✗ | ✗ |
| Lost & Found | ✓ | ✗ | ✗ | ✗ |
| Manage Users | ✗ | ✗ | ✗ | ✓ |
| Post Announcements | ✗ | ✗ | ✓ | ✗ |

---

## Security Notes

- Currently uses localStorage for state (not secure for production)
- Implement proper backend authentication and authorization
- Add CSRF protection
- Validate all user inputs on backend
- Use HTTPS in production
- Implement rate limiting on auth endpoints

---

## Browser Compatibility

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

---

## Performance Considerations

- All data synced with backend database
- Implement pagination for large datasets
- Optimize image sizes before upload
- Use lazy loading for images
- Cache frequently accessed data

---

## Future Enhancements

1. Real-time notifications using WebSockets
2. File storage integration (AWS S3, Vercel Blob)
3. Email notifications
4. Advanced search and filtering
5. User profiles with avatars
6. Direct messaging between users
7. Resource recommendations
8. Analytics dashboard
9. Mobile app
10. Dark mode toggle

---
