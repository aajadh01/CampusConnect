# CampusConnect - Complete Setup Guide (For Beginners)

## Welcome!

This guide will walk you through creating a complete backend and database for CampusConnect. Even if you've never done this before, follow each step carefully and you'll have a working system!

---

## PART 1: UNDERSTANDING THE BASICS

### What is a Backend?
A backend is a server that:
- Stores data in a database
- Handles user login/authentication
- Processes requests from the frontend
- Sends data back to the frontend

### What is a Database?
A database is like a digital filing system that stores:
- User accounts
- Notes/resources
- Events
- Marketplace items
- Community posts
- Everything else

### How They Work Together
\`\`\`
Frontend (Your Website)
        ↓ (sends request)
Backend Server (Node.js + Express)
        ↓ (queries)
Database (PostgreSQL)
        ↓ (returns data)
Backend Server
        ↓ (sends response)
Frontend (displays data)
\`\`\`

---

## PART 2: INSTALLATION (Windows, Mac, Linux)

### Step 1: Install Node.js

**What is Node.js?** It's a runtime that lets you run JavaScript on a server.

**Windows:**
1. Go to https://nodejs.org/
2. Download LTS version (Long Term Support)
3. Run the installer
4. Click "Next" through all screens
5. Restart your computer

**Mac:**
1. Go to https://nodejs.org/
2. Download LTS version
3. Run the installer
4. Follow the prompts

**Linux (Ubuntu/Debian):**
\`\`\`bash
sudo apt update
sudo apt install nodejs npm
\`\`\`

**Verify Installation:**
\`\`\`bash
node --version
npm --version
\`\`\`

You should see version numbers like `v18.0.0` and `9.0.0`

---

### Step 2: Install PostgreSQL

**What is PostgreSQL?** It's a database system that stores all your data.

**Windows:**
1. Go to https://www.postgresql.org/download/windows/
2. Download the installer
3. Run it
4. When asked for password, enter: `postgres123`
5. Keep port as `5432`
6. Complete installation

**Mac:**
1. Go to https://www.postgresql.org/download/macosx/
2. Download installer
3. Run it
4. Follow prompts
5. Remember the password you set

**Linux (Ubuntu/Debian):**
\`\`\`bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
\`\`\`

**Verify Installation:**
\`\`\`bash
psql --version
\`\`\`

You should see version like `psql (PostgreSQL) 14.0`

---

### Step 3: Install VS Code (Code Editor)

**What is VS Code?** It's where you'll write and edit code.

1. Go to https://code.visualstudio.com/
2. Download for your operating system
3. Install it
4. Open VS Code

**Install Extensions in VS Code:**
1. Click Extensions icon (left sidebar)
2. Search and install:
   - "Prisma"
   - "Thunder Client" (for testing APIs)
   - "REST Client"

---

## PART 3: CREATE BACKEND PROJECT

### Step 1: Create Project Folder

**Windows (Command Prompt):**
\`\`\`bash
mkdir campusconnect-backend
cd campusconnect-backend
\`\`\`

**Mac/Linux (Terminal):**
\`\`\`bash
mkdir campusconnect-backend
cd campusconnect-backend
\`\`\`

### Step 2: Initialize Node Project

\`\`\`bash
npm init -y
\`\`\`

This creates a `package.json` file that lists all your project dependencies.

### Step 3: Install Dependencies

\`\`\`bash
npm install express cors dotenv bcryptjs jsonwebtoken multer prisma @prisma/client
\`\`\`

**What are these?**
- `express` - Web framework
- `cors` - Allow frontend to communicate
- `dotenv` - Manage environment variables
- `bcryptjs` - Hash passwords
- `jsonwebtoken` - Create authentication tokens
- `multer` - Handle file uploads
- `prisma` - Database helper

### Step 4: Setup Prisma

\`\`\`bash
npx prisma init
\`\`\`

This creates:
- `.env` file (for secrets)
- `prisma/schema.prisma` (database structure)

---

## PART 4: CONFIGURE DATABASE

### Step 1: Create Database

**Windows (Command Prompt):**
\`\`\`bash
psql -U postgres
\`\`\`

When prompted, enter password: `postgres123`

**Mac/Linux (Terminal):**
\`\`\`bash
sudo -u postgres psql
\`\`\`

### Step 2: Create Database

In the PostgreSQL prompt, type:
\`\`\`sql
CREATE DATABASE campusconnect_db;
\q
\`\`\`

The `\q` command exits PostgreSQL.

### Step 3: Update .env File

Open `.env` file in VS Code and replace with:

\`\`\`
DATABASE_URL="postgresql://postgres:postgres123@localhost:5432/campusconnect_db"
JWT_SECRET="your_super_secret_key_change_this_in_production"
JWT_EXPIRE="7d"
NODE_ENV="development"
PORT=5000
\`\`\`

---

## PART 5: CREATE DATABASE SCHEMA

### Step 1: Update prisma/schema.prisma

Open `prisma/schema.prisma` and replace everything with:

\`\`\`prisma
// This file is the database structure

generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

// Users table
model User {
  id            Int     @id @default(autoincrement())
  username      String  @unique
  email         String  @unique
  passwordHash  String
  role          Role
  registeredId  String  @unique
  fullName      String
  isActive      Boolean @default(true)
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt

  // Relations
  uploadedNotes       Note[]
  verifiedNotes       Note[] @relation("VerifiedBy")
  noteUpvotes         NoteUpvote[]
  wishlistItems       Wishlist[]
  marketplaceItems    Marketplace[]
  eventRegistrations  EventRegistration[]
  lostFoundPosts      LostFound[]
  communityPosts      CommunityPost[]
  postVotes           PostVote[]
  postReplies         PostReply[]
  createdEvents       Event[]
  announcements       Announcement[]

  @@index([role])
  @@index([username])
}

enum Role {
  student
  faculty
  organizer
  admin
}

// Notes table
model Note {
  id              Int     @id @default(autoincrement())
  title           String
  category        String
  uploaderId      Int
  uploaderRole    String
  filePath        String
  fileName        String
  description     String?
  isVerified      Boolean @default(false)
  verifiedById    Int?
  verifiedAt      DateTime?
  upvoteCount     Int     @default(0)
  downloadCount   Int     @default(0)
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  // Relations
  uploader        User    @relation(fields: [uploaderId], references: [id], onDelete: Cascade)
  verifiedBy      User?   @relation("VerifiedBy", fields: [verifiedById], references: [id], onDelete: SetNull)
  upvotes         NoteUpvote[]
  wishlistItems   Wishlist[]

  @@index([uploaderId])
  @@index([category])
  @@index([isVerified])
}

// Note upvotes
model NoteUpvote {
  id        Int     @id @default(autoincrement())
  noteId    Int
  userId    Int
  createdAt DateTime @default(now())

  note      Note    @relation(fields: [noteId], references: [id], onDelete: Cascade)
  user      User    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([noteId, userId])
}

// Wishlist
model Wishlist {
  id        Int     @id @default(autoincrement())
  userId    Int
  noteId    Int
  addedAt   DateTime @default(now())

  user      User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  note      Note    @relation(fields: [noteId], references: [id], onDelete: Cascade)

  @@unique([userId, noteId])
}

// Marketplace
model Marketplace {
  id          Int     @id @default(autoincrement())
  title       String
  description String
  price       Decimal
  sellerId    Int
  imagePath   String?
  category    String?
  condition   String?
  contactInfo String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  isSold      Boolean @default(false)

  seller      User    @relation(fields: [sellerId], references: [id], onDelete: Cascade)

  @@index([sellerId])
  @@index([category])
}

// Events
model Event {
  id                  Int     @id @default(autoincrement())
  title               String
  description         String
  eventDate           DateTime
  eventTime           String
  location            String
  organizerId         Int
  imagePath           String?
  category            String?
  capacity            Int?
  registeredCount     Int     @default(0)
  createdAt           DateTime @default(now())
  updatedAt           DateTime @updatedAt

  organizer           User    @relation(fields: [organizerId], references: [id], onDelete: Cascade)
  registrations       EventRegistration[]

  @@index([organizerId])
}

// Event registrations
model EventRegistration {
  id                  Int     @id @default(autoincrement())
  eventId             Int
  userId              Int
  registeredAt        DateTime @default(now())
  attendanceStatus    String  @default("registered")

  event               Event   @relation(fields: [eventId], references: [id], onDelete: Cascade)
  user                User    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([eventId, userId])
}

// Lost & Found
model LostFound {
  id              Int     @id @default(autoincrement())
  title           String
  description     String
  type            String  // "lost" or "found"
  location        String
  posterId        Int
  imagePath       String?
  contactInfo     String?
  isResolved      Boolean @default(false)
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  poster          User    @relation(fields: [posterId], references: [id], onDelete: Cascade)

  @@index([posterId])
  @@index([type])
}

// Community posts
model CommunityPost {
  id              Int     @id @default(autoincrement())
  content         String
  authorId        Int
  authorRole      String
  upvoteCount     Int     @default(0)
  downvoteCount   Int     @default(0)
  replyCount      Int     @default(0)
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  author          User    @relation(fields: [authorId], references: [id], onDelete: Cascade)
  votes           PostVote[]
  replies         PostReply[]

  @@index([authorId])
}

// Post votes
model PostVote {
  id              Int     @id @default(autoincrement())
  postId          Int
  userId          Int
  voteType        String  // "upvote" or "downvote"
  createdAt       DateTime @default(now())

  post            CommunityPost @relation(fields: [postId], references: [id], onDelete: Cascade)
  user            User    @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@unique([postId, userId])
}

// Post replies
model PostReply {
  id              Int     @id @default(autoincrement())
  postId          Int
  authorId        Int
  content         String
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  post            CommunityPost @relation(fields: [postId], references: [id], onDelete: Cascade)
  author          User    @relation(fields: [authorId], references: [id], onDelete: Cascade)

  @@index([postId])
}

// Announcements
model Announcement {
  id              Int     @id @default(autoincrement())
  content         String
  organizerId     Int
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt

  organizer       User    @relation(fields: [organizerId], references: [id], onDelete: Cascade)

  @@index([organizerId])
}
\`\`\`

### Step 2: Run Migration

\`\`\`bash
npx prisma migrate dev --name init
\`\`\`

This creates all tables in your database. You'll be asked to name the migration - just press Enter.

### Step 3: Verify Database

\`\`\`bash
npx prisma studio
\`\`\`

This opens a visual database viewer. You should see all 12 tables created!

---

## PART 6: CREATE BACKEND SERVER

### Step 1: Create app.js

Create a new file `app.js` in your project root:

\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes will go here

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Server error',
    error: err.message
  });
});

module.exports = app;
\`\`\`

### Step 2: Create server.js

Create a new file `server.js` in your project root:

\`\`\`javascript
const app = require('./app');

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
\`\`\`

### Step 3: Update package.json

Open `package.json` and add this in the `"scripts"` section:

\`\`\`json
"scripts": {
  "start": "node server.js",
  "dev": "node server.js"
}
\`\`\`

### Step 4: Test Server

\`\`\`bash
npm start
\`\`\`

You should see: `Server running on http://localhost:5000`

Press `Ctrl+C` to stop the server.

---

## PART 7: CREATE API ENDPOINTS

### Step 1: Create Controllers Folder

\`\`\`bash
mkdir controllers
mkdir routes
mkdir middleware
\`\`\`

### Step 2: Create Auth Controller

Create `controllers/authController.js`:

\`\`\`javascript
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const prisma = new PrismaClient();

// Login
exports.login = async (req, res) => {
  try {
    const { username, password, role } = req.body;

    // Validate input
    if (!username || !password || !role) {
      return res.status(400).json({
        success: false,
        message: 'Username, password, and role are required'
      });
    }

    // Find user
    const user = await prisma.user.findUnique({
      where: { username }
    });

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, user.passwordHash);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }

    // Check role
    if (user.role !== role) {
      return res.status(401).json({
        success: false,
        message: 'Invalid role'
      });
    }

    // Create JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        username: user.username,
        role: user.role
      },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRE }
    );

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        registeredId: user.registeredId,
        fullName: user.fullName
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({
      success: false,
      message: 'Server error'
    });
  }
};

// Logout
exports.logout = (req, res) => {
  res.json({
    success: true,
    message: 'Logged out successfully'
  });
};
\`\`\`

### Step 3: Create Auth Routes

Create `routes/auth.js`:

\`\`\`javascript
const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

router.post('/login', authController.login);
router.post('/logout', authController.logout);

module.exports = router;
\`\`\`

### Step 4: Create Auth Middleware

Create `middleware/auth.js`:

\`\`\`javascript
const jwt = require('jsonwebtoken');

exports.verifyToken = (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];

    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'No token provided'
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({
      success: false,
      message: 'Invalid token'
    });
  }
};
\`\`\`

### Step 5: Update app.js

Update `app.js` to include routes:

\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const authRoutes = require('./routes/auth');

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);

// Test route
app.get('/api/test', (req, res) => {
  res.json({ success: true, message: 'Backend is working!' });
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({
    success: false,
    message: 'Server error',
    error: err.message
  });
});

module.exports = app;
\`\`\`

---

## PART 8: CREATE SAMPLE DATA

### Step 1: Create Seed Script

Create `seed.js`:

\`\`\`javascript
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  // Create sample users
  const hashedPassword = await bcrypt.hash('password123', 10);

  const student = await prisma.user.create({
    data: {
      username: 'student1',
      email: 'student1@campus.edu',
      passwordHash: hashedPassword,
      role: 'student',
      registeredId: 'STU001',
      fullName: 'John Doe'
    }
  });

  const faculty = await prisma.user.create({
    data: {
      username: 'faculty1',
      email: 'faculty1@campus.edu',
      passwordHash: hashedPassword,
      role: 'faculty',
      registeredId: 'FAC001',
      fullName: 'Dr. Jane Smith'
    }
  });

  const organizer = await prisma.user.create({
    data: {
      username: 'organizer1',
      email: 'organizer1@campus.edu',
      passwordHash: hashedPassword,
      role: 'organizer',
      registeredId: 'ORG001',
      fullName: 'Event Team'
    }
  });

  const admin = await prisma.user.create({
    data: {
      username: 'admin',
      email: 'admin@campus.edu',
      passwordHash: hashedPassword,
      role: 'admin',
      registeredId: 'ADM001',
      fullName: 'Administrator'
    }
  });

  console.log('Sample users created!');
  console.log('Student:', student);
  console.log('Faculty:', faculty);
  console.log('Organizer:', organizer);
  console.log('Admin:', admin);
}

main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
\`\`\`

### Step 2: Run Seed

\`\`\`bash
node seed.js
\`\`\`

You should see the sample users created!

---

## PART 9: TEST YOUR BACKEND

### Step 1: Start Server

\`\`\`bash
npm start
\`\`\`

### Step 2: Test Login

Open Thunder Client in VS Code (or use Postman):

1. Create new request
2. Set method to `POST`
3. Set URL to `http://localhost:5000/api/auth/login`
4. Go to Body tab
5. Select JSON
6. Paste:

\`\`\`json
{
  "username": "student1",
  "password": "password123",
  "role": "student"
}
\`\`\`

7. Click Send

You should get a response with a token!

---

## PART 10: CONNECT TO FRONTEND

### Step 1: Update Frontend JavaScript

In your `script.js`, add this API helper:

\`\`\`javascript
const API_URL = 'http://localhost:5000/api';

// API Helper function
async function apiCall(endpoint, method = 'GET', data = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    }
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, options);
    const result = await response.json();
    return result;
  } catch (error) {
    console.error('API Error:', error);
    return { success: false, message: 'Network error' };
  }
}

// Update login function
async function handleLogin(username, password, role) {
  const result = await apiCall('/auth/login', 'POST', {
    username,
    password,
    role
  });

  if (result.success) {
    localStorage.setItem('token', result.token);
    localStorage.setItem('user', JSON.stringify(result.user));
    // Redirect to dashboard
    window.location.href = `${role}-dashboard.html`;
  } else {
    alert(result.message);
  }
}
\`\`\`

### Step 2: Update CORS in Backend

Update `app.js`:

\`\`\`javascript
app.use(cors({
  origin: 'http://localhost:3000', // Your frontend URL
  credentials: true
}));
\`\`\`

---

## PART 11: TROUBLESHOOTING

### Problem: "Connection refused"
**Solution:** Make sure PostgreSQL is running
- Windows: Check Services
- Mac: Check System Preferences
- Linux: `sudo systemctl status postgresql`

### Problem: "Database does not exist"
**Solution:** Create database again
\`\`\`bash
psql -U postgres
CREATE DATABASE campusconnect_db;
\q
\`\`\`

### Problem: "Port 5000 already in use"
**Solution:** Change port in `.env`
\`\`\`
PORT=5001
\`\`\`

### Problem: "CORS error"
**Solution:** Make sure CORS is enabled in app.js

### Problem: "Token invalid"
**Solution:** Make sure JWT_SECRET is set in `.env`

---

## SUMMARY

You now have:
✅ PostgreSQL database running
✅ Node.js backend server
✅ 12 database tables
✅ Authentication system
✅ Sample users
✅ API endpoints
✅ Frontend connected

**Next Steps:**
1. Create remaining API endpoints (notes, events, marketplace, etc.)
2. Add file upload handling
3. Deploy to production
4. Add more features

Congratulations! You've built a backend! 🎉

---
