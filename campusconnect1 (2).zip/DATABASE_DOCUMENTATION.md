# CampusConnect - Database Documentation

## Overview

This document provides comprehensive database design for CampusConnect, a role-based campus management platform. The database stores all user data, resources, events, discussions, marketplace items, and lost & found posts.

---

## Database Choice: PostgreSQL (Recommended)

**Why PostgreSQL?**
- ACID Compliance: Ensures data integrity
- Advanced Features: JSON support, full-text search
- Scalability: Handles millions of records efficiently
- Reliability: Battle-tested in production
- Cost: Free and open-source
- Performance: Excellent query optimization

---

## Complete Database Schema

### 1. Users Table

**Purpose**: Store user information for all roles

\`\`\`sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(100) UNIQUE NOT NULL,
  passwordHash VARCHAR(255) NOT NULL,
  fullName VARCHAR(100) NOT NULL,
  registeredId VARCHAR(20) UNIQUE NOT NULL,
  role ENUM('student', 'faculty', 'organizer', 'admin') NOT NULL,
  isActive BOOLEAN DEFAULT true,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX idx_email (email),
  INDEX idx_role (role),
  INDEX idx_registeredId (registeredId)
);
\`\`\`

---

### 2. Resources Table

**Purpose**: Store uploaded study materials

\`\`\`sql
CREATE TABLE resources (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  description TEXT,
  uploaderId INT NOT NULL,
  uploaderRole VARCHAR(50),
  filePath VARCHAR(500) NOT NULL,
  fileName VARCHAR(255),
  isVerified BOOLEAN DEFAULT false,
  verifiedById INT,
  verifiedAt TIMESTAMP,
  upvoteCount INT DEFAULT 0,
  downloadCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (uploaderId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (verifiedById) REFERENCES users(id) ON DELETE SET NULL,
  
  INDEX idx_uploaderId (uploaderId),
  INDEX idx_category (category),
  INDEX idx_isVerified (isVerified)
);
\`\`\`

---

### 3. Events Table

**Purpose**: Store campus events

\`\`\`sql
CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  eventDate DATETIME NOT NULL,
  eventTime VARCHAR(50),
  location VARCHAR(255),
  organizerId INT NOT NULL,
  imagePath VARCHAR(500),
  category VARCHAR(100),
  capacity INT,
  registeredCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (organizerId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_organizerId (organizerId),
  INDEX idx_eventDate (eventDate)
);
\`\`\`

---

### 4. Event Registrations Table

**Purpose**: Track user registrations for events

\`\`\`sql
CREATE TABLE event_registrations (
  id SERIAL PRIMARY KEY,
  eventId INT NOT NULL,
  userId INT NOT NULL,
  registeredAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (eventId) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_registration (eventId, userId),
  INDEX idx_eventId (eventId),
  INDEX idx_userId (userId)
);
\`\`\`

---

### 5. Marketplace Items Table

**Purpose**: Store items for buying/selling

\`\`\`sql
CREATE TABLE marketplace_items (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10, 2) NOT NULL,
  sellerId INT NOT NULL,
  imagePath VARCHAR(500),
  category VARCHAR(100),
  condition VARCHAR(50),
  contactInfo VARCHAR(20),
  isSold BOOLEAN DEFAULT false,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (sellerId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_sellerId (sellerId),
  INDEX idx_isSold (isSold),
  INDEX idx_category (category)
);
\`\`\`

---

### 6. Community Posts Table

**Purpose**: Store community discussions

\`\`\`sql
CREATE TABLE community_posts (
  id SERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  authorId INT NOT NULL,
  authorRole VARCHAR(50),
  upvoteCount INT DEFAULT 0,
  downvoteCount INT DEFAULT 0,
  replyCount INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (authorId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_authorId (authorId),
  INDEX idx_createdAt (createdAt)
);
\`\`\`

---

### 7. Post Replies Table

**Purpose**: Store replies to community posts

\`\`\`sql
CREATE TABLE post_replies (
  id SERIAL PRIMARY KEY,
  postId INT NOT NULL,
  authorId INT NOT NULL,
  content TEXT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (postId) REFERENCES community_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (authorId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_postId (postId),
  INDEX idx_authorId (authorId)
);
\`\`\`

---

### 8. Post Votes Table

**Purpose**: Track upvotes/downvotes on posts

\`\`\`sql
CREATE TABLE post_votes (
  id SERIAL PRIMARY KEY,
  postId INT NOT NULL,
  userId INT NOT NULL,
  voteType ENUM('upvote', 'downvote') NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (postId) REFERENCES community_posts(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_vote (postId, userId),
  INDEX idx_userId (userId)
);
\`\`\`

---

### 9. Lost & Found Items Table

**Purpose**: Store lost and found items

\`\`\`sql
CREATE TABLE lost_found_items (
  id SERIAL PRIMARY KEY,
  type ENUM('lost', 'found') NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  location VARCHAR(255),
  posterId INT NOT NULL,
  imagePath VARCHAR(500),
  contactInfo VARCHAR(20),
  isResolved BOOLEAN DEFAULT false,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (posterId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_posterId (posterId),
  INDEX idx_type (type),
  INDEX idx_isResolved (isResolved)
);
\`\`\`

---

### 10. Wishlist Table

**Purpose**: Store user wishlists for resources

\`\`\`sql
CREATE TABLE wishlist (
  id SERIAL PRIMARY KEY,
  userId INT NOT NULL,
  resourceId INT NOT NULL,
  addedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (resourceId) REFERENCES resources(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_wishlist (userId, resourceId),
  INDEX idx_userId (userId)
);
\`\`\`

---

### 11. Note Upvotes Table

**Purpose**: Track upvotes on resources

\`\`\`sql
CREATE TABLE note_upvotes (
  id SERIAL PRIMARY KEY,
  resourceId INT NOT NULL,
  userId INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (resourceId) REFERENCES resources(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  
  UNIQUE KEY unique_upvote (resourceId, userId),
  INDEX idx_userId (userId)
);
\`\`\`

---

### 12. Announcements Table

**Purpose**: Store announcements from organizers

\`\`\`sql
CREATE TABLE announcements (
  id SERIAL PRIMARY KEY,
  content TEXT NOT NULL,
  organizerId INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  FOREIGN KEY (organizerId) REFERENCES users(id) ON DELETE CASCADE,
  
  INDEX idx_organizerId (organizerId),
  INDEX idx_createdAt (createdAt)
);
\`\`\`

---

## Database Relationships Diagram

\`\`\`
users (1) ──────────────────────── (many) resources
  │                                    │
  │                                    ├─ note_upvotes
  │                                    └─ wishlist
  │
  ├─ (1) ──────────────────────── (many) marketplace_items
  │
  ├─ (1) ──────────────────────── (many) events
  │                                    │
  │                                    └─ event_registrations
  │
  ├─ (1) ──────────────────────── (many) community_posts
  │                                    │
  │                                    ├─ post_replies
  │                                    └─ post_votes
  │
  ├─ (1) ──────────────────────── (many) lost_found_items
  │
  └─ (1) ──────────────────────── (many) announcements
\`\`\`

---

## Indexing Strategy

### Primary Indexes (Must Have)

\`\`\`sql
-- User lookups
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_registeredId ON users(registeredId);

-- Resource filtering
CREATE INDEX idx_resources_uploaderId ON resources(uploaderId);
CREATE INDEX idx_resources_category ON resources(category);
CREATE INDEX idx_resources_isVerified ON resources(isVerified);

-- Event filtering
CREATE INDEX idx_events_organizerId ON events(organizerId);
CREATE INDEX idx_events_eventDate ON events(eventDate);

-- Marketplace filtering
CREATE INDEX idx_marketplace_sellerId ON marketplace_items(sellerId);
CREATE INDEX idx_marketplace_isSold ON marketplace_items(isSold);

-- Lost & Found filtering
CREATE INDEX idx_lostfound_posterId ON lost_found_items(posterId);
CREATE INDEX idx_lostfound_type ON lost_found_items(type);
\`\`\`

---

## Query Optimization Examples

### 1. Get All Resources with Uploader Info

\`\`\`sql
SELECT r.*, u.fullName as uploaderName
FROM resources r
JOIN users u ON r.uploaderId = u.id
WHERE r.isVerified = true
ORDER BY r.upvoteCount DESC
LIMIT 20;
\`\`\`

### 2. Get Events with Attendee Count

\`\`\`sql
SELECT e.*, COUNT(er.id) as attendeeCount
FROM events e
LEFT JOIN event_registrations er ON e.id = er.eventId
WHERE e.eventDate >= CURDATE()
GROUP BY e.id
ORDER BY e.eventDate ASC;
\`\`\`

### 3. Get Community Posts with Reply Count

\`\`\`sql
SELECT cp.*, u.fullName as authorName, COUNT(pr.id) as replyCount
FROM community_posts cp
JOIN users u ON cp.authorId = u.id
LEFT JOIN post_replies pr ON cp.id = pr.postId
GROUP BY cp.id
ORDER BY cp.createdAt DESC;
\`\`\`

---

## Data Integrity & Constraints

### Foreign Key Constraints

\`\`\`sql
-- Cascade delete: When user deleted, all their resources deleted
ALTER TABLE resources 
ADD CONSTRAINT fk_resources_uploaderId 
FOREIGN KEY (uploaderId) REFERENCES users(id) ON DELETE CASCADE;

-- Set null: When verifier deleted, verification info cleared
ALTER TABLE resources 
ADD CONSTRAINT fk_resources_verifiedById 
FOREIGN KEY (verifiedById) REFERENCES users(id) ON DELETE SET NULL;
\`\`\`

### Unique Constraints

\`\`\`sql
-- Prevent duplicate event registrations
ALTER TABLE event_registrations 
ADD UNIQUE KEY unique_registration (eventId, userId);

-- Prevent duplicate votes
ALTER TABLE post_votes 
ADD UNIQUE KEY unique_vote (postId, userId);

-- Prevent duplicate wishlist entries
ALTER TABLE wishlist 
ADD UNIQUE KEY unique_wishlist (userId, resourceId);
\`\`\`

---

## Backup & Recovery

### Automated Backup Strategy

\`\`\`bash
#!/bin/bash
# Daily backup script
BACKUP_DIR="/backups/campusconnect"
DATE=$(date +%Y%m%d_%H%M%S)

# Full backup
pg_dump -U postgres campusconnect | gzip > $BACKUP_DIR/full_$DATE.sql.gz

# Keep only last 30 days
find $BACKUP_DIR -name "full_*.sql.gz" -mtime +30 -delete
\`\`\`

---

## Performance Monitoring

### Key Metrics

\`\`\`sql
-- Slow queries
SELECT query, calls, mean_time 
FROM pg_stat_statements 
WHERE mean_time > 1000 
ORDER BY mean_time DESC;

-- Table sizes
SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) 
FROM pg_tables 
WHERE schemaname = 'public' 
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;
\`\`\`

---

## Scalability Considerations

### Current Capacity
- Handles 1,000+ concurrent users
- Stores millions of records
- Supports multiple institutions

### Future Scaling
- Add read replicas
- Implement caching layer (Redis)
- Use CDN for file storage
- Horizontal scaling with load balancer

---

## Migration Strategy

### Using Prisma Migrations

\`\`\`bash
# Create migration
npx prisma migrate dev --name init

# Apply migrations to production
npx prisma migrate deploy

# Reset database (development only)
npx prisma migrate reset
\`\`\`

---

## Data Validation Rules

### User Registration

\`\`\`javascript
const userValidation = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
  password: {
    minLength: 8,
    requireUppercase: true,
    requireNumbers: true
  },
  fullName: { minLength: 3, maxLength: 100 }
};
\`\`\`

### Resource Upload

\`\`\`javascript
const resourceValidation = {
  title: { minLength: 5, maxLength: 255 },
  fileSize: { max: 50 * 1024 * 1024 }, // 50MB
  allowedTypes: ['pdf', 'doc', 'docx', 'txt', 'jpg', 'png']
};
\`\`\`

---

## Security Considerations

### 1. Encryption
- Passwords hashed with bcrypt
- Sensitive data encrypted at rest

### 2. Row-Level Security
- Users can only see their own data
- Faculty can verify resources
- Admin can see all data

### 3. Audit Logging
- Track all user actions
- Log all data modifications
- Monitor suspicious activity

---

## Cost Optimization

### Database Sizing
- **Small (< 1GB)**: Free tier PostgreSQL
- **Medium (1-10GB)**: $7-15/month (Render, Railway)
- **Large (10-100GB)**: $50-200/month (AWS, DigitalOcean)

---

## Troubleshooting Common Issues

### Issue: Slow Queries
\`\`\`sql
-- Analyze query plan
EXPLAIN ANALYZE SELECT * FROM resources WHERE category = 'notes';

-- Add missing index
CREATE INDEX idx_resources_category ON resources(category);
\`\`\`

### Issue: Disk Space Full
\`\`\`sql
-- Find large tables
SELECT schemaname, tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) 
FROM pg_tables 
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC 
LIMIT 5;
\`\`\`

---

## Next Steps

1. Choose PostgreSQL for production
2. Set up local PostgreSQL instance
3. Create database schema using provided SQL
4. Set up automated backups
5. Configure monitoring and alerts
6. Implement connection pooling
7. Test disaster recovery procedures
8. Deploy to production database service

---
