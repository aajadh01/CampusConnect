# FRONTEND MODIFICATIONS NEEDED
## What IDs and Changes Are Required

---

## PART 1: UNDERSTANDING IDs

### What Are IDs?

IDs are **unique numbers** that identify each item in the database:
- Each user gets an ID (1, 2, 3, etc.)
- Each event gets an ID (1, 2, 3, etc.)
- Each resource gets an ID (1, 2, 3, etc.)

**Why?** So the backend knows which item you're talking about when you delete or update something.

---

## PART 2: REQUIRED HTML MODIFICATIONS

### Modification 1: Add Hidden Input Fields for IDs

In all forms where you create/edit items, add hidden fields to store IDs:

**Example in `student-dashboard.html`:**

\`\`\`html
<!-- Resource Upload Form -->
<form id="uploadResourceForm">
  <input type="hidden" id="resourceId" value="">
  <input type="text" id="resourceTitle" placeholder="Resource Title" required>
  <textarea id="resourceDescription" placeholder="Description" required></textarea>
  <select id="resourceCategory" required>
    <option value="">Select Category</option>
    <option value="notes">Notes</option>
    <option value="books">Books</option>
    <option value="tutorials">Tutorials</option>
  </select>
  <input type="url" id="resourceFileUrl" placeholder="File URL" required>
  <button type="submit">Upload Resource</button>
</form>

<!-- Event Creation Form -->
<form id="createEventForm">
  <input type="hidden" id="eventId" value="">
  <input type="text" id="eventTitle" placeholder="Event Title" required>
  <textarea id="eventDescription" placeholder="Description" required></textarea>
  <input type="datetime-local" id="eventDate" required>
  <input type="text" id="eventLocation" placeholder="Location" required>
  <select id="eventCategory" required>
    <option value="">Select Category</option>
    <option value="workshop">Workshop</option>
    <option value="seminar">Seminar</option>
    <option value="competition">Competition</option>
  </select>
  <input type="number" id="eventMaxAttendees" placeholder="Max Attendees">
  <input type="url" id="eventImageUrl" placeholder="Image URL">
  <button type="submit">Create Event</button>
</form>

<!-- Discussion Form -->
<form id="createDiscussionForm">
  <input type="hidden" id="discussionId" value="">
  <input type="text" id="discussionTitle" placeholder="Discussion Title" required>
  <textarea id="discussionDescription" placeholder="Description" required></textarea>
  <select id="discussionCategory" required>
    <option value="">Select Category</option>
    <option value="academics">Academics</option>
    <option value="placements">Placements</option>
    <option value="general">General</option>
  </select>
  <button type="submit">Create Discussion</button>
</form>

<!-- Marketplace Form -->
<form id="createMarketplaceForm">
  <input type="hidden" id="marketplaceId" value="">
  <input type="text" id="itemTitle" placeholder="Item Title" required>
  <textarea id="itemDescription" placeholder="Description" required></textarea>
  <input type="number" id="itemPrice" placeholder="Price" step="0.01" required>
  <select id="itemCategory" required>
    <option value="">Select Category</option>
    <option value="books">Books</option>
    <option value="electronics">Electronics</option>
    <option value="furniture">Furniture</option>
  </select>
  <input type="url" id="itemImageUrl" placeholder="Image URL">
  <select id="itemCondition" required>
    <option value="">Select Condition</option>
    <option value="new">New</option>
    <option value="like-new">Like New</option>
    <option value="good">Good</option>
    <option value="fair">Fair</option>
  </select>
  <button type="submit">List Item</button>
</form>

<!-- Lost & Found Form -->
<form id="createLostFoundForm">
  <input type="hidden" id="lostFoundId" value="">
  <input type="text" id="lostFoundTitle" placeholder="Item Title" required>
  <textarea id="lostFoundDescription" placeholder="Description" required></textarea>
  <select id="lostFoundType" required>
    <option value="">Select Type</option>
    <option value="lost">Lost</option>
    <option value="found">Found</option>
  </select>
  <input type="text" id="lostFoundLocation" placeholder="Location" required>
  <input type="url" id="lostFoundImageUrl" placeholder="Image URL">
  <button type="submit">Report Item</button>
</form>
\`\`\`

### Modification 2: Add Data Attributes to Display Elements

When displaying items, add data attributes to store IDs:

\`\`\`html
<!-- Resources Display -->
<div id="resourcesList" class="resources-container">
  <!-- Items will be added here dynamically with data-id -->
</div>

<!-- Events Display -->
<div id="eventsList" class="events-container">
  <!-- Items will be added here dynamically with data-id -->
</div>

<!-- Discussions Display -->
<div id="discussionsList" class="discussions-container">
  <!-- Items will be added here dynamically with data-id -->
</div>

<!-- Marketplace Display -->
<div id="marketplaceList" class="marketplace-container">
  <!-- Items will be added here dynamically with data-id -->
</div>

<!-- Lost & Found Display -->
<div id="lostFoundList" class="lost-found-container">
  <!-- Items will be added here dynamically with data-id -->
</div>
\`\`\`

---

## PART 3: REQUIRED JAVASCRIPT MODIFICATIONS

### Modification 1: Update Display Functions to Include IDs

When creating item cards, add `data-id` attribute:

\`\`\`javascript
// Example for resources
const resourceCard = document.createElement('div');
resourceCard.className = 'resource-card';
resourceCard.setAttribute('data-id', resource.id);  // <-- ADD THIS
resourceCard.innerHTML = `
  <h3>${resource.title}</h3>
  <p>${resource.description}</p>
  <p><strong>Category:</strong> ${resource.category}</p>
  <p><strong>Uploaded by:</strong> ${resource.uploadedBy.fullName}</p>
  <a href="${resource.fileUrl}" target="_blank" class="btn">Download</a>
  ${resource.uploadedById === getCurrentUserId() ? `
    <button onclick="deleteResourceItem(${resource.id})" class="btn btn-danger">Delete</button>
  ` : ''}
`;
resourcesList.appendChild(resourceCard);
\`\`\`

### Modification 2: Update Event Attendee Display

Show who is attending:

\`\`\`javascript
// In event card
const attendeesList = event.attendees.map(a => a.user.fullName).join(', ');
eventCard.innerHTML = `
  <h3>${event.title}</h3>
  <p>${event.description}</p>
  <p><strong>Date:</strong> ${new Date(event.date).toLocaleString()}</p>
  <p><strong>Location:</strong> ${event.location}</p>
  <p><strong>Organizer:</strong> ${event.organizer.fullName}</p>
  <p><strong>Attendees (${event.attendees.length}):</strong> ${attendeesList}</p>
  ${isAttending ? `
    <button onclick="leaveEventItem(${event.id})" class="btn btn-danger">Leave Event</button>
  ` : `
    <button onclick="joinEventItem(${event.id})" class="btn">Join Event</button>
  `}
`;
\`\`\`

### Modification 3: Update Comment Display with User Info

\`\`\`javascript
// In discussion comments
discussion.comments.forEach(comment => {
  const commentDiv = document.createElement('div');
  commentDiv.className = 'comment';
  commentDiv.setAttribute('data-comment-id', comment.id);  // <-- ADD THIS
  commentDiv.innerHTML = `
    <div class="comment-header">
      <strong>${comment.user.fullName}</strong>
      <small>${new Date(comment.createdAt).toLocaleString()}</small>
    </div>
    <p>${comment.comment}</p>
    <div class="comment-votes">
      <button onclick="voteOnComment(${comment.id}, 'upvote')" class="btn-small">
        👍 Upvote (${comment.upvotes})
      </button>
      <button onclick="voteOnComment(${comment.id}, 'downvote')" class="btn-small">
        👎 Downvote (${comment.downvotes})
      </button>
    </div>
  `;
  commentsList.appendChild(commentDiv);
});
\`\`\`

---

## PART 4: REQUIRED CHANGES IN script.js

### Change 1: Remove localStorage for Data

**Before (Old Way):**
\`\`\`javascript
// OLD - Don't use this anymore
let resources = JSON.parse(localStorage.getItem('resources')) || [];
resources.push(newResource);
localStorage.setItem('resources', JSON.stringify(resources));
\`\`\`

**After (New Way):**
\`\`\`javascript
// NEW - Use API calls
const response = await createResource(title, description, category, fileUrl);
// Data is automatically saved in database
\`\`\`

### Change 2: Update User Profile Display

\`\`\`javascript
// Display current user info
function displayUserProfile() {
  const user = JSON.parse(localStorage.getItem('currentUser'));
  
  if (user) {
    document.getElementById('userName').textContent = user.fullName;
    document.getElementById('userEmail').textContent = user.email;
    document.getElementById('userRole').textContent = user.role;
    document.getElementById('userId').value = user.id;  // Store ID for later use
  }
}

// Call on page load
displayUserProfile();
\`\`\`

### Change 3: Add Logout Button

\`\`\`html
<!-- In navigation/header -->
<button onclick="logoutUser()" class="btn btn-logout">Logout</button>
\`\`\`

### Change 4: Update Form Validation

\`\`\`javascript
// Validate before sending to backend
function validateResourceForm() {
  const title = document.getElementById('resourceTitle').value.trim();
  const description = document.getElementById('resourceDescription').value.trim();
  const category = document.getElementById('resourceCategory').value;
  const fileUrl = document.getElementById('resourceFileUrl').value.trim();

  if (!title || !description || !category || !fileUrl) {
    alert('Please fill all fields');
    return false;
  }

  if (!isValidUrl(fileUrl)) {
    alert('Please enter a valid file URL');
    return false;
  }

  return true;
}

function isValidUrl(string) {
  try {
    new URL(string);
    return true;
  } catch (_) {
    return false;
  }
}
\`\`\`

---

## PART 5: REQUIRED CHANGES IN HTML FILES

### Change 1: Update Login Form

\`\`\`html
<!-- login.html -->
<form id="loginForm">
  <input type="email" id="email" placeholder="Email" required>
  <input type="password" id="password" placeholder="Password" required>
  <button type="submit">Login</button>
</form>

<p>Don't have an account? <a href="register.html">Register here</a></p>
\`\`\`

### Change 2: Create Registration Page

Create `register.html`:

\`\`\`html
<!DOCTYPE html>
<html>
<head>
  <title>Register - CampusConnect</title>
  <link rel="stylesheet" href="styles-student.css">
</head>
<body>
  <div class="container">
    <h1>Register</h1>
    
    <form id="registerForm">
      <input type="email" id="email" placeholder="Email" required>
      <input type="password" id="password" placeholder="Password" required>
      <input type="text" id="fullName" placeholder="Full Name" required>
      
      <select id="role" required>
        <option value="">Select Role</option>
        <option value="student">Student</option>
        <option value="faculty">Faculty</option>
        <option value="organizer">Organizer</option>
      </select>
      
      <input type="text" id="department" placeholder="Department" required>
      <input type="tel" id="phone" placeholder="Phone Number">
      
      <button type="submit">Register</button>
    </form>
    
    <p>Already have an account? <a href="login.html">Login here</a></p>
  </div>

  <script src="api-helper.js"></script>
  <script>
    document.getElementById('registerForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      
      const email = document.getElementById('email').value;
      const password = document.getElementById('password').value;
      const fullName = document.getElementById('fullName').value;
      const role = document.getElementById('role').value;
      const department = document.getElementById('department').value;

      try {
        const response = await registerUser(email, password, fullName, role, department);
        
        setToken(response.token);
        localStorage.setItem('currentUser', JSON.stringify(response.user));
        
        alert('Registration successful!');
        window.location.href = 'login.html';
      } catch (error) {
        alert('Registration failed: ' + error.message);
      }
    });
  </script>
</body>
</html>
\`\`\`

### Change 3: Add User Profile Page

Create `profile.html`:

\`\`\`html
<!DOCTYPE html>
<html>
<head>
  <title>Profile - CampusConnect</title>
  <link rel="stylesheet" href="styles-student.css">
</head>
<body>
  <div class="container">
    <h1>My Profile</h1>
    
    <div id="profileInfo">
      <p><strong>Name:</strong> <span id="profileName"></span></p>
      <p><strong>Email:</strong> <span id="profileEmail"></span></p>
      <p><strong>Role:</strong> <span id="profileRole"></span></p>
      <p><strong>Department:</strong> <span id="profileDepartment"></span></p>
      <p><strong>Phone:</strong> <span id="profilePhone"></span></p>
      <p><strong>Bio:</strong> <span id="profileBio"></span></p>
    </div>
    
    <button onclick="editProfile()" class="btn">Edit Profile</button>
    <button onclick="logoutUser()" class="btn btn-danger">Logout</button>
  </div>

  <script src="api-helper.js"></script>
  <script>
    async function loadProfile() {
      try {
        const user = await getCurrentUser();
        
        document.getElementById('profileName').textContent = user.fullName;
        document.getElementById('profileEmail').textContent = user.email;
        document.getElementById('profileRole').textContent = user.role;
        document.getElementById('profileDepartment').textContent = user.department || 'N/A';
        document.getElementById('profilePhone').textContent = user.phone || 'N/A';
        document.getElementById('profileBio').textContent = user.bio || 'No bio added';
      } catch (error) {
        alert('Failed to load profile: ' + error.message);
      }
    }

    function editProfile() {
      alert('Edit profile feature coming soon!');
    }

    loadProfile();
  </script>
</body>
</html>
\`\`\`

---

## PART 6: SUMMARY OF ALL CHANGES

### Files to Modify:
1. ✅ `login.html` - Update login form
2. ✅ `student-dashboard.html` - Add forms with hidden ID fields
3. ✅ `teacher-dashboard.html` - Add forms with hidden ID fields
4. ✅ `organizer-dashboard.html` - Add forms with hidden ID fields
5. ✅ `admin-user-management.html` - Add admin functions
6. ✅ `script.js` - Replace localStorage with API calls
7. ✅ `api-helper.js` - Add this new file

### Files to Create:
1. ✅ `register.html` - Registration page
2. ✅ `profile.html` - User profile page
3. ✅ `api-helper.js` - API helper functions

### Key Changes:
- Remove all `localStorage` data storage
- Add hidden ID fields to all forms
- Add `data-id` attributes to display elements
- Replace all data operations with API calls
- Add user authentication checks
- Add logout functionality

---

## PART 7: TESTING CHECKLIST

After making all changes, test:

- [ ] User can register
- [ ] User can login
- [ ] User can view profile
- [ ] User can upload resources
- [ ] User can create events
- [ ] User can join events
- [ ] User can create discussions
- [ ] User can comment on discussions
- [ ] User can vote on comments
- [ ] User can list marketplace items
- [ ] User can report lost/found items
- [ ] User can logout
- [ ] Data persists after page refresh
- [ ] Multiple users can see each other's data
- [ ] Users can only delete their own items

---

## PART 8: IMPORTANT NOTES

### Security:
- Never store passwords in localStorage
- Always use HTTPS in production
- Validate all inputs on frontend and backend
- Use strong JWT secrets

### Performance:
- Cache API responses when possible
- Use pagination for large lists
- Minimize API calls
- Optimize images

### User Experience:
- Show loading indicators during API calls
- Display error messages clearly
- Confirm before deleting items
- Auto-save form data

---

**You're all set! Your frontend is now ready to connect to the backend!**

---
