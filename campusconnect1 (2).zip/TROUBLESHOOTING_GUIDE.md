# Troubleshooting Guide

## Common Issues & Solutions

---

## Backend Issues

### Issue 1: "npm: command not found"

**Problem:** Node.js is not installed or not in PATH

**Solution:**
1. Download Node.js from https://nodejs.org
2. Install it
3. Restart your terminal/command prompt
4. Try `node --version` again

---

### Issue 2: "Cannot find module 'express'"

**Problem:** Dependencies are not installed

**Solution:**
\`\`\`bash
# Make sure you're in the backend folder
cd campusconnect-backend

# Install all dependencies
npm install
\`\`\`

---

### Issue 3: "EADDRINUSE: address already in use :::5000"

**Problem:** Another application is using port 5000

**Solution:**

**Windows:**
\`\`\`bash
# Find process using port 5000
netstat -ano | findstr :5000

# Kill the process (replace PID with the number)
taskkill /PID <PID> /F

# Or use a different port
PORT=5001 npm start
\`\`\`

**Mac/Linux:**
\`\`\`bash
# Find process using port 5000
lsof -i :5000

# Kill the process
kill -9 <PID>

# Or use a different port
PORT=5001 npm start
\`\`\`

---

### Issue 4: "Cannot connect to database"

**Problem:** PostgreSQL is not running or connection string is wrong

**Solution:**

1. **Check if PostgreSQL is running:**

   **Windows:**
   - Open Services (services.msc)
   - Look for "PostgreSQL"
   - If not running, right-click and start it

   **Mac:**
   \`\`\`bash
   brew services list
   # If postgresql is not running:
   brew services start postgresql
   \`\`\`

   **Linux:**
   \`\`\`bash
   sudo systemctl status postgresql
   # If not running:
   sudo systemctl start postgresql
   \`\`\`

2. **Check connection string in `.env`:**
   \`\`\`
   DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@localhost:5432/campusconnect"
   \`\`\`
   - Replace `YOUR_PASSWORD` with your PostgreSQL password
   - Make sure database name is `campusconnect`

3. **Test connection:**
   \`\`\`bash
   psql -U postgres -d campusconnect
   # If successful, you'll see: campusconnect=#
   # Type \q to exit
   \`\`\`

---

### Issue 5: "relation 'users' does not exist"

**Problem:** Database tables haven't been created

**Solution:**
\`\`\`bash
# Run migrations to create tables
npx prisma migrate dev --name init

# Or reset database (WARNING: deletes all data)
npx prisma migrate reset
\`\`\`

---

### Issue 6: "JWT_SECRET is not defined"

**Problem:** Environment variables are not loaded

**Solution:**

1. Check `.env` file exists in root of backend folder
2. Make sure it has: `JWT_SECRET="your_secret_key"`
3. Restart the server: `npm start`

---

### Issue 7: "CORS error: Access to XMLHttpRequest blocked"

**Problem:** Frontend can't access backend due to CORS

**Solution:**

**In `src/app.js`:**
\`\`\`javascript
const cors = require('cors');

app.use(cors({
  origin: 'http://localhost:3000', // Your frontend URL
  credentials: true
}));
\`\`\`

Or allow all origins (development only):
\`\`\`javascript
app.use(cors());
\`\`\`

---

### Issue 8: "TypeError: Cannot read property 'password' of null"

**Problem:** User not found in database

**Solution:**

1. Check if user exists in database:
   \`\`\`bash
   psql -U postgres -d campusconnect
   SELECT * FROM users;
   \`\`\`

2. If no users, create sample users:
   \`\`\`bash
   node scripts/seed.js
   \`\`\`

---

### Issue 9: "Unexpected token < in JSON at position 0"

**Problem:** Backend is returning HTML instead of JSON (usually an error page)

**Solution:**

1. Check backend logs for errors
2. Make sure endpoint exists
3. Check request URL is correct
4. Make sure backend is running

---

### Issue 10: "Error: listen EACCES: permission denied 0.0.0.0:5000"

**Problem:** Permission denied to use port 5000

**Solution:**

**Mac/Linux:**
\`\`\`bash
# Use a port above 1024
PORT=3001 npm start

# Or use sudo (not recommended)
sudo npm start
\`\`\`

---

## Database Issues

### Issue 1: "FATAL: password authentication failed"

**Problem:** Wrong PostgreSQL password

**Solution:**

1. Reset PostgreSQL password:

   **Windows:**
   - Uninstall PostgreSQL
   - Reinstall and remember the password

   **Mac:**
   \`\`\`bash
   brew uninstall postgresql
   brew install postgresql
   \`\`\`

   **Linux:**
   \`\`\`bash
   sudo -u postgres psql
   ALTER USER postgres WITH PASSWORD 'newpassword';
   \q
   \`\`\`

2. Update `.env`:
   \`\`\`
   DATABASE_URL="postgresql://postgres:newpassword@localhost:5432/campusconnect"
   \`\`\`

---

### Issue 2: "database 'campusconnect' does not exist"

**Problem:** Database hasn't been created

**Solution:**
\`\`\`bash
# Create database
psql -U postgres
CREATE DATABASE campusconnect;
\q

# Then run migrations
npx prisma migrate dev --name init
\`\`\`

---

### Issue 3: "Disk quota exceeded"

**Problem:** Database storage is full

**Solution:**

1. Delete old data:
   \`\`\`sql
   DELETE FROM resources WHERE createdAt < NOW() - INTERVAL '1 year';
   DELETE FROM discussions WHERE createdAt < NOW() - INTERVAL '1 year';
   \`\`\`

2. Vacuum database:
   \`\`\`bash
   psql -U postgres -d campusconnect
   VACUUM ANALYZE;
   \q
   \`\`\`

---

### Issue 4: "Connection pool exhausted"

**Problem:** Too many database connections

**Solution:**

**In `.env`:**
\`\`\`
DATABASE_URL="postgresql://postgres:password@localhost:5432/campusconnect?connection_limit=20"
\`\`\`

---

## Frontend Issues

### Issue 1: "Failed to fetch" when logging in

**Problem:** Backend is not running or wrong URL

**Solution:**

1. Make sure backend is running:
   \`\`\`bash
   npm start
   # Should show: Server running on http://localhost:5000
   \`\`\`

2. Check frontend is using correct URL:
   \`\`\`javascript
   // In script.js
   const response = await fetch('http://localhost:5000/api/auth/login', {
     // ...
   });
   \`\`\`

3. Check CORS is enabled in backend

---

### Issue 2: "Login successful but page doesn't redirect"

**Problem:** Token is not being saved or redirect is failing

**Solution:**

1. Check token is being saved:
   \`\`\`javascript
   // In browser console
   localStorage.getItem('token')
   // Should show a long string starting with "eyJ"
   \`\`\`

2. Check redirect URL is correct:
   \`\`\`javascript
   // Make sure file exists
   // student-dashboard.html
   // teacher-dashboard.html
   // etc.
   \`\`\`

---

### Issue 3: "Blank page after login"

**Problem:** Dashboard page is not loading data

**Solution:**

1. Check browser console for errors (F12)
2. Make sure `loadResources()` is being called
3. Check backend is returning data:
   \`\`\`bash
   # In Postman
   GET http://localhost:5000/api/resources
   Headers: Authorization: Bearer {token}
   \`\`\`

---

### Issue 4: "File upload not working"

**Problem:** Backend doesn't have file upload endpoint

**Solution:**

1. Create upload endpoint in backend:
   \`\`\`javascript
   const multer = require('multer');
   const upload = multer({ dest: 'uploads/' });

   app.post('/api/resources', upload.single('file'), (req, res) => {
     // Handle file upload
   });
   \`\`\`

2. Update frontend to use FormData:
   \`\`\`javascript
   const formData = new FormData();
   formData.append('file', fileInput.files[0]);
   formData.append('title', title);

   const response = await fetch('http://localhost:5000/api/resources', {
     method: 'POST',
     headers: {
       'Authorization': `Bearer ${token}`
     },
     body: formData
   });
   \`\`\`

---

## Integration Issues

### Issue 1: "Token is undefined after login"

**Problem:** Response doesn't contain token

**Solution:**

1. Check backend login endpoint returns token:
   \`\`\`javascript
   // In backend authController.js
   res.json({
     success: true,
     token: jwt.sign(...),  // Make sure this is here
     user: { ... }
   });
   \`\`\`

2. Check frontend is saving token:
   \`\`\`javascript
   localStorage.setItem('token', data.token);
   \`\`\`

---

### Issue 2: "401 Unauthorized on protected endpoints"

**Problem:** Token is not being sent or is invalid

**Solution:**

1. Check token is being sent:
   \`\`\`javascript
   const token = localStorage.getItem('token');
   headers['Authorization'] = `Bearer ${token}`;
   \`\`\`

2. Check token format is correct:
   \`\`\`
   Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
   \`\`\`

3. Check token hasn't expired:
   \`\`\`javascript
   // In backend
   jwt.verify(token, process.env.JWT_SECRET);
   \`\`\`

---

### Issue 3: "Data not persisting after page refresh"

**Problem:** Data is only in memory, not in database

**Solution:**

1. Make sure data is being saved to database:
   \`\`\`javascript
   // In backend
   await prisma.resource.create({
     data: { ... }
   });
   \`\`\`

2. Make sure frontend is loading from backend:
   \`\`\`javascript
   // Not from localStorage
   const data = await apiCall('/api/resources');
   \`\`\`

---

### Issue 4: "Different data on different pages"

**Problem:** Frontend is using localStorage instead of backend

**Solution:**

1. Remove all localStorage usage except for token and user info
2. Always fetch data from backend:
   \`\`\`javascript
   // OLD (wrong)
   const resources = JSON.parse(localStorage.getItem('resources'));

   // NEW (correct)
   const data = await apiCall('/api/resources');
   \`\`\`

---

## Performance Issues

### Issue 1: "Page is loading slowly"

**Problem:** Too many database queries or large responses

**Solution:**

1. Add pagination:
   \`\`\`javascript
   // Backend
   const resources = await prisma.resource.findMany({
     take: 20,
     skip: 0
   });

   // Frontend
   const data = await apiCall('/api/resources?limit=20&offset=0');
   \`\`\`

2. Add indexes to database:
   \`\`\`sql
   CREATE INDEX idx_resources_status ON resources(status);
   CREATE INDEX idx_resources_branch ON resources(branch);
   \`\`\`

---

### Issue 2: "Memory usage keeps increasing"

**Problem:** Memory leak in backend

**Solution:**

1. Close database connections:
   \`\`\`javascript
   // At end of request
   await prisma.$disconnect();
   \`\`\`

2. Use connection pooling:
   \`\`\`
   DATABASE_URL="postgresql://...?connection_limit=10"
   \`\`\`

---

## Deployment Issues

### Issue 1: "Backend works locally but not on production"

**Problem:** Environment variables not set on production

**Solution:**

1. Set environment variables on hosting platform:
   - DATABASE_URL
   - JWT_SECRET
   - NODE_ENV=production

2. Update CORS for production domain:
   \`\`\`javascript
   app.use(cors({
     origin: 'https://your-frontend-domain.com'
   }));
   \`\`\`

---

### Issue 2: "Database connection fails on production"

**Problem:** Production database URL is wrong

**Solution:**

1. Get correct connection string from database provider
2. Update DATABASE_URL in production environment
3. Run migrations on production:
   \`\`\`bash
   npx prisma migrate deploy
   \`\`\`

---

## Getting Help

### Resources

- **Stack Overflow**: https://stackoverflow.com (search your error)
- **GitHub Issues**: Search the library's GitHub repo
- **Official Docs**: Check the official documentation
- **Reddit**: r/learnprogramming, r/node, r/webdev

### How to Ask for Help

1. **Describe the problem clearly**
   - What were you trying to do?
   - What happened?
   - What did you expect?

2. **Share error messages**
   - Full error text
   - Stack trace
   - Line numbers

3. **Share relevant code**
   - The function that's failing
   - Configuration files
   - Request/response examples

4. **Share environment info**
   - Node.js version
   - Operating system
   - Database version

### Example Help Request

\`\`\`
Title: "Login returns 401 Unauthorized even with correct credentials"

Description:
I'm trying to login with:
- regNumber: 23L31A0501
- password: password123

Error:
401 Unauthorized
{
  "message": "Invalid credentials"
}

I've verified:
- User exists in database
- Password is correct
- Backend is running

Code:
[paste your login function]

Environment:
- Node.js v18.17.0
- PostgreSQL 14
- Windows 10
\`\`\`

---

## Debugging Tips

### 1. Use Console Logs

\`\`\`javascript
// In backend
console.log('User found:', user);
console.log('Password valid:', isPasswordValid);
console.log('Token generated:', token);

// In frontend
console.log('Response:', data);
console.log('Token saved:', localStorage.getItem('token'));
\`\`\`

### 2. Use Browser DevTools

- Press F12 to open DevTools
- Go to "Network" tab to see requests
- Go to "Console" tab to see errors
- Go to "Application" tab to see localStorage

### 3. Use Postman

- Test endpoints without frontend
- Check request/response format
- Verify authentication

### 4. Check Logs

\`\`\`bash
# Backend logs
# Check terminal where npm start is running

# Database logs
# Check PostgreSQL logs
\`\`\`

### 5. Isolate the Problem

- Test one thing at a time
- Use Postman to test backend
- Use browser console to test frontend
- Check database directly

---

## Quick Checklist

Before asking for help, verify:

- [ ] Backend is running (`npm start`)
- [ ] Database is running (PostgreSQL)
- [ ] Database is connected (check `.env`)
- [ ] Tables are created (`npx prisma migrate dev`)
- [ ] Sample data exists (`node scripts/seed.js`)
- [ ] Frontend URL is correct
- [ ] Backend URL is correct
- [ ] CORS is enabled
- [ ] Token is being saved
- [ ] Token is being sent with requests
- [ ] Error messages are clear
- [ ] No typos in code

---

## Still Stuck?

1. Take a break and come back fresh
2. Re-read the error message carefully
3. Check the official documentation
4. Search for similar issues online
5. Ask in developer communities
6. Contact your instructor/mentor

Remember: Every developer gets stuck sometimes. It's part of learning! 🚀
