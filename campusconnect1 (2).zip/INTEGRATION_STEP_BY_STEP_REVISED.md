# CampusConnect - Frontend & Backend Integration Guide

## Overview

This guide shows you exactly how to connect your frontend to the backend API. Every button, form, and feature will communicate with the backend.

---

## PART 1: SETUP API COMMUNICATION

### Step 1: Create API Helper File

Create a new file `api-helper.js` in your project root:

\`\`\`javascript
// API Configuration
const API_URL = 'http://localhost:5000/api';

// Generic API call function
async function apiCall(endpoint, method = 'GET', data = null, isFormData = false) {
  const options = {
    method,
    headers: {
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    }
  };

  // Only set Content-Type if not FormData
  if (!isFormData) {
    options.headers['Content-Type'] = 'application/json';
  }

  if (data) {
    if (isFormData) {
      options.body = data; // FormData object
    } else {
      options.body = JSON.stringify(data);
    }
  }

  try {
    const response = await fetch(`${API_URL}${endpoint}`, options);
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.message || 'API Error');
    }

    const result = await response.json();
    return result;
  } catch (error) {
    console.error('API Error:', error);
    return {
      success: false,
      message: error.message || 'Network error'
    };
  }
}

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { apiCall, API_URL };
}
\`\`\`

### Step 2: Include in HTML

Add this to the `<head>` of all your HTML files:

\`\`\`html
<script src="api-helper.js"></script>
\`\`\`

---

## PART 2: AUTHENTICATION

### Update Login Function

Replace the login function in `script.js`:

\`\`\`javascript
async function handleLogin(event) {
  event.preventDefault();

  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const role = document.getElementById('role').value;

  // Validate input
  if (!username || !password || !role) {
    alert('Please fill all fields');
    return;
  }

  // Call backend
  const result = await apiCall('/auth/login', 'POST', {
    username,
    password,
    role
  });

  if (result.success) {
    // Save token and user data
    localStorage.setItem('token', result.token);
    localStorage.setItem('user', JSON.stringify(result.user));
    localStorage.setItem('userRole', result.user.role);

    // Redirect to appropriate dashboard
    const dashboardMap = {
      'student': 'student-dashboard.html',
      'faculty': 'teacher-dashboard.html',
      'organizer': 'organizer-dashboard.html',
      'admin': 'admin-user-management.html'
    };

    window.location.href = dashboardMap[result.user.role];
  } else {
    alert('Login failed: ' + result.message);
  }
}

// Add logout function
function handleLogout() {
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  localStorage.removeItem('userRole');
  window.location.href = 'index.html';
}

// Check if user is logged in
function checkAuth() {
  const token = localStorage.getItem('token');
  if (!token) {
    window.location.href = 'login.html';
  }
}

// Get current user
function getCurrentUser() {
  const userStr = localStorage.getItem('user');
  return userStr ? JSON.parse(userStr) : null;
}
\`\`\`

---

## PART 3: NOTES/RESOURCES SECTION

### Get All Notes

\`\`\`javascript
async function loadNotes(category = null, verified = null) {
  let endpoint = '/notes';
  const params = new URLSearchParams();

  if (category) params.append('category', category);
  if (verified !== null) params.append('verified', verified);

  if (params.toString()) {
    endpoint += '?' + params.toString();
  }

  const result = await apiCall(endpoint);

  if (result.success) {
    displayNotes(result.data);
  } else {
    alert('Failed to load notes: ' + result.message);
  }
}

function displayNotes(notes) {
  const notesContainer = document.getElementById('notes-container');
  notesContainer.innerHTML = '';

  notes.forEach(note => {
    const noteCard = document.createElement('div');
    noteCard.className = 'note-card';
    noteCard.innerHTML = `
      <div class="note-header">
        <h3>${note.title}</h3>
        <span class="category-badge">${note.category}</span>
        ${note.isVerified ? '<span class="verified-badge">✓ Verified</span>' : ''}
      </div>
      <p class="note-uploader">By: ${note.uploaderName} (${note.uploaderRole})</p>
      <p class="note-description">${note.description || 'No description'}</p>
      <div class="note-stats">
        <span>👍 ${note.upvoteCount} upvotes</span>
        <span>⬇️ ${note.downloadCount} downloads</span>
      </div>
      <div class="note-actions">
        <button onclick="downloadNote(${note.id})">Download</button>
        <button onclick="upvoteNote(${note.id})">Upvote</button>
        <button onclick="addToWishlist(${note.id})">Wishlist</button>
        ${note.uploaderId === getCurrentUser().id ? 
          `<button onclick="deleteNote(${note.id})">Delete</button>` : ''}
      </div>
    `;
    notesContainer.appendChild(noteCard);
  });
}
\`\`\`

### Upload Note

\`\`\`javascript
async function handleNoteUpload(event) {
  event.preventDefault();

  const formData = new FormData();
  formData.append('file', document.getElementById('note-file').files[0]);
  formData.append('title', document.getElementById('note-title').value);
  formData.append('category', document.getElementById('note-category').value);
  formData.append('description', document.getElementById('note-description').value);

  const result = await apiCall('/notes/upload', 'POST', formData, true);

  if (result.success) {
    alert('Note uploaded successfully!');
    document.getElementById('note-form').reset();
    loadNotes(); // Reload notes
  } else {
    alert('Upload failed: ' + result.message);
  }
}

async function downloadNote(noteId) {
  const result = await apiCall(`/notes/${noteId}/download`);
  if (result.success) {
    // Trigger download
    const link = document.createElement('a');
    link.href = result.downloadUrl;
    link.download = result.fileName;
    link.click();
  }
}

async function upvoteNote(noteId) {
  const result = await apiCall(`/notes/${noteId}/upvote`, 'POST');
  if (result.success) {
    loadNotes(); // Reload to show updated count
  }
}

async function deleteNote(noteId) {
  if (confirm('Are you sure you want to delete this note?')) {
    const result = await apiCall(`/notes/${noteId}`, 'DELETE');
    if (result.success) {
      alert('Note deleted successfully');
      loadNotes();
    }
  }
}
\`\`\`

### Verify Notes (Faculty Only)

\`\`\`javascript
async function verifyNote(noteId) {
  const result = await apiCall(`/notes/${noteId}/verify`, 'POST');
  if (result.success) {
    alert('Note verified successfully');
    loadNotes();
  } else {
    alert('Verification failed: ' + result.message);
  }
}
\`\`\`

---

## PART 4: EVENTS SECTION

### Get All Events

\`\`\`javascript
async function loadEvents() {
  const result = await apiCall('/events');

  if (result.success) {
    displayEvents(result.data);
  } else {
    alert('Failed to load events: ' + result.message);
  }
}

function displayEvents(events) {
  const eventsContainer = document.getElementById('events-container');
  eventsContainer.innerHTML = '';

  events.forEach(event => {
    const eventCard = document.createElement('div');
    eventCard.className = 'event-card';
    eventCard.innerHTML = `
      <img src="${event.imagePath || '/placeholder.svg'}" alt="${event.title}">
      <div class="event-content">
        <h3>${event.title}</h3>
        <p>${event.description}</p>
        <div class="event-details">
          <span>📅 ${new Date(event.eventDate).toLocaleDateString()}</span>
          <span>🕐 ${event.eventTime}</span>
          <span>📍 ${event.location}</span>
        </div>
        <p class="event-organizer">By: ${event.organizerName}</p>
        <p class="event-registered">Registered: ${event.registeredCount}/${event.capacity || 'Unlimited'}</p>
        <button onclick="registerEvent(${event.id})">Register</button>
      </div>
    `;
    eventsContainer.appendChild(eventCard);
  });
}

async function registerEvent(eventId) {
  const result = await apiCall(`/events/${eventId}/register`, 'POST');
  if (result.success) {
    alert('Registered for event successfully!');
    loadEvents();
  } else {
    alert('Registration failed: ' + result.message);
  }
}
\`\`\`

### Create Event (Organizer Only)

\`\`\`javascript
async function handleEventCreate(event) {
  event.preventDefault();

  const formData = new FormData();
  formData.append('title', document.getElementById('event-title').value);
  formData.append('description', document.getElementById('event-description').value);
  formData.append('eventDate', document.getElementById('event-date').value);
  formData.append('eventTime', document.getElementById('event-time').value);
  formData.append('location', document.getElementById('event-location').value);
  formData.append('capacity', document.getElementById('event-capacity').value);
  formData.append('image', document.getElementById('event-image').files[0]);

  const result = await apiCall('/events/create', 'POST', formData, true);

  if (result.success) {
    alert('Event created successfully!');
    document.getElementById('event-form').reset();
    loadEvents();
  } else {
    alert('Event creation failed: ' + result.message);
  }
}
\`\`\`

---

## PART 5: MARKETPLACE SECTION

### Get All Items

\`\`\`javascript
async function loadMarketplaceItems() {
  const result = await apiCall('/marketplace');

  if (result.success) {
    displayMarketplaceItems(result.data);
  } else {
    alert('Failed to load items: ' + result.message);
  }
}

function displayMarketplaceItems(items) {
  const container = document.getElementById('marketplace-container');
  container.innerHTML = '';

  items.forEach(item => {
    const itemCard = document.createElement('div');
    itemCard.className = 'marketplace-card';
    itemCard.innerHTML = `
      <img src="${item.imagePath || '/placeholder.svg'}" alt="${item.title}">
      <div class="item-content">
        <h3>${item.title}</h3>
        <p>${item.description}</p>
        <p class="item-price">₹${item.price}</p>
        <p class="item-seller">Seller: ${item.sellerName}</p>
        <p class="item-condition">Condition: ${item.condition}</p>
        <p class="item-contact">Contact: ${item.contactInfo}</p>
        ${item.sellerId === getCurrentUser().id ? 
          `<button onclick="deleteMarketplaceItem(${item.id})">Delete</button>` : ''}
      </div>
    `;
    container.appendChild(itemCard);
  });
}

async function handleMarketplaceUpload(event) {
  event.preventDefault();

  const formData = new FormData();
  formData.append('title', document.getElementById('item-title').value);
  formData.append('description', document.getElementById('item-description').value);
  formData.append('price', document.getElementById('item-price').value);
  formData.append('category', document.getElementById('item-category').value);
  formData.append('condition', document.getElementById('item-condition').value);
  formData.append('image', document.getElementById('item-image').files[0]);

  const result = await apiCall('/marketplace/upload', 'POST', formData, true);

  if (result.success) {
    alert('Item listed successfully!');
    document.getElementById('marketplace-form').reset();
    loadMarketplaceItems();
  } else {
    alert('Upload failed: ' + result.message);
  }
}

async function deleteMarketplaceItem(itemId) {
  if (confirm('Delete this item?')) {
    const result = await apiCall(`/marketplace/${itemId}`, 'DELETE');
    if (result.success) {
      alert('Item deleted');
      loadMarketplaceItems();
    }
  }
}
\`\`\`

---

## PART 6: LOST & FOUND SECTION

### Get All Posts

\`\`\`javascript
async function loadLostFoundPosts() {
  const result = await apiCall('/lostfound');

  if (result.success) {
    displayLostFoundPosts(result.data);
  } else {
    alert('Failed to load posts: ' + result.message);
  }
}

function displayLostFoundPosts(posts) {
  const container = document.getElementById('lostfound-container');
  container.innerHTML = '';

  posts.forEach(post => {
    const postCard = document.createElement('div');
    postCard.className = `lostfound-card ${post.type}`;
    postCard.innerHTML = `
      <span class="type-badge">${post.type.toUpperCase()}</span>
      <img src="${post.imagePath || '/placeholder.svg'}" alt="${post.title}">
      <div class="post-content">
        <h3>${post.title}</h3>
        <p>${post.description}</p>
        <p class="location">📍 ${post.location}</p>
        <p class="poster">Posted by: ${post.posterName}</p>
        <p class="contact">Contact: ${post.contactInfo}</p>
        ${post.posterId === getCurrentUser().id ? 
          `<button onclick="deleteLostFoundPost(${post.id})">Delete</button>` : ''}
      </div>
    `;
    container.appendChild(postCard);
  });
}

async function handleLostFoundPost(event) {
  event.preventDefault();

  const formData = new FormData();
  formData.append('title', document.getElementById('lf-title').value);
  formData.append('description', document.getElementById('lf-description').value);
  formData.append('type', document.getElementById('lf-type').value);
  formData.append('location', document.getElementById('lf-location').value);
  formData.append('contactInfo', document.getElementById('lf-contact').value);
  formData.append('image', document.getElementById('lf-image').files[0]);

  const result = await apiCall('/lostfound/create', 'POST', formData, true);

  if (result.success) {
    alert('Post created successfully!');
    document.getElementById('lf-form').reset();
    loadLostFoundPosts();
  } else {
    alert('Post creation failed: ' + result.message);
  }
}

async function deleteLostFoundPost(postId) {
  if (confirm('Delete this post?')) {
    const result = await apiCall(`/lostfound/${postId}`, 'DELETE');
    if (result.success) {
      alert('Post deleted');
      loadLostFoundPosts();
    }
  }
}
\`\`\`

---

## PART 7: COMMUNITY SECTION

### Get All Posts

\`\`\`javascript
async function loadCommunityPosts() {
  const result = await apiCall('/community/posts');

  if (result.success) {
    displayCommunityPosts(result.data);
  } else {
    alert('Failed to load posts: ' + result.message);
  }
}

function displayCommunityPosts(posts) {
  const container = document.getElementById('community-container');
  container.innerHTML = '';

  posts.forEach(post => {
    const postCard = document.createElement('div');
    postCard.className = 'community-post';
    postCard.innerHTML = `
      <div class="post-header">
        <strong>${post.authorName}</strong>
        <span class="role-badge">${post.authorRole}</span>
        <span class="timestamp">${new Date(post.createdAt).toLocaleDateString()}</span>
      </div>
      <p class="post-content">${post.content}</p>
      <div class="post-stats">
        <span>👍 ${post.upvoteCount}</span>
        <span>👎 ${post.downvoteCount}</span>
        <span>💬 ${post.replyCount} replies</span>
      </div>
      <div class="post-actions">
        <button onclick="upvotePost(${post.id})">Upvote</button>
        <button onclick="downvotePost(${post.id})">Downvote</button>
        <button onclick="showReplies(${post.id})">Replies</button>
        ${post.authorId === getCurrentUser().id ? 
          `<button onclick="deletePost(${post.id})">Delete</button>` : ''}
      </div>
    `;
    container.appendChild(postCard);
  });
}

async function handleCommunityPost(event) {
  event.preventDefault();

  const content = document.getElementById('post-content').value;

  const result = await apiCall('/community/posts/create', 'POST', {
    content
  });

  if (result.success) {
    alert('Post created successfully!');
    document.getElementById('post-form').reset();
    loadCommunityPosts();
  } else {
    alert('Post creation failed: ' + result.message);
  }
}

async function upvotePost(postId) {
  const result = await apiCall(`/community/posts/${postId}/upvote`, 'POST');
  if (result.success) {
    loadCommunityPosts();
  }
}

async function downvotePost(postId) {
  const result = await apiCall(`/community/posts/${postId}/downvote`, 'POST');
  if (result.success) {
    loadCommunityPosts();
  }
}

async function showReplies(postId) {
  const result = await apiCall(`/community/posts/${postId}/replies`);
  if (result.success) {
    displayReplies(result.data, postId);
  }
}

function displayReplies(replies, postId) {
  const modal = document.createElement('div');
  modal.className = 'modal';
  modal.innerHTML = `
    <div class="modal-content">
      <h3>Replies</h3>
      <div class="replies-list">
        ${replies.map(reply => `
          <div class="reply">
            <strong>${reply.authorName}</strong>
            <p>${reply.content}</p>
            <small>${new Date(reply.createdAt).toLocaleDateString()}</small>
          </div>
        `).join('')}
      </div>
      <textarea id="reply-content" placeholder="Write a reply..."></textarea>
      <button onclick="submitReply(${postId})">Reply</button>
      <button onclick="this.parentElement.parentElement.remove()">Close</button>
    </div>
  `;
  document.body.appendChild(modal);
}

async function submitReply(postId) {
  const content = document.getElementById('reply-content').value;
  const result = await apiCall(`/community/posts/${postId}/reply`, 'POST', {
    content
  });

  if (result.success) {
    alert('Reply added!');
    document.querySelector('.modal').remove();
    loadCommunityPosts();
  }
}

async function deletePost(postId) {
  if (confirm('Delete this post?')) {
    const result = await apiCall(`/community/posts/${postId}`, 'DELETE');
    if (result.success) {
      alert('Post deleted');
      loadCommunityPosts();
    }
  }
}
\`\`\`

---

## PART 8: WISHLIST SECTION

\`\`\`javascript
async function loadWishlist() {
  const result = await apiCall('/wishlist');

  if (result.success) {
    displayWishlist(result.data);
  } else {
    alert('Failed to load wishlist: ' + result.message);
  }
}

function displayWishlist(items) {
  const container = document.getElementById('wishlist-container');
  container.innerHTML = '';

  items.forEach(item => {
    const card = document.createElement('div');
    card.className = 'wishlist-item';
    card.innerHTML = `
      <h3>${item.noteTitle}</h3>
      <p>Added: ${new Date(item.addedAt).toLocaleDateString()}</p>
      <button onclick="downloadNote(${item.noteId})">Download</button>
      <button onclick="removeFromWishlist(${item.noteId})">Remove</button>
    `;
    container.appendChild(card);
  });
}

async function addToWishlist(noteId) {
  const result = await apiCall(`/wishlist/add/${noteId}`, 'POST');
  if (result.success) {
    alert('Added to wishlist!');
  }
}

async function removeFromWishlist(noteId) {
  const result = await apiCall(`/wishlist/remove/${noteId}`, 'DELETE');
  if (result.success) {
    alert('Removed from wishlist');
    loadWishlist();
  }
}
\`\`\`

---

## PART 9: SETTINGS SECTION

\`\`\`javascript
async function handlePasswordChange(event) {
  event.preventDefault();

  const currentPassword = document.getElementById('current-password').value;
  const newPassword = document.getElementById('new-password').value;
  const confirmPassword = document.getElementById('confirm-password').value;

  if (newPassword !== confirmPassword) {
    alert('Passwords do not match');
    return;
  }

  const result = await apiCall('/users/change-password', 'POST', {
    currentPassword,
    newPassword,
    confirmPassword
  });

  if (result.success) {
    alert('Password changed successfully!');
    document.getElementById('password-form').reset();
  } else {
    alert('Password change failed: ' + result.message);
  }
}
\`\`\`

---

## PART 10: ADMIN FUNCTIONS

\`\`\`javascript
// Create User
async function handleAdminCreateUser(event) {
  event.preventDefault();

  const result = await apiCall('/admin/users/create', 'POST', {
    username: document.getElementById('admin-username').value,
    email: document.getElementById('admin-email').value,
    password: document.getElementById('admin-password').value,
    role: document.getElementById('admin-role').value,
    registeredId: document.getElementById('admin-regid').value,
    fullName: document.getElementById('admin-fullname').value
  });

  if (result.success) {
    alert('User created successfully!');
    document.getElementById('admin-form').reset();
    loadAdminUsers();
  } else {
    alert('User creation failed: ' + result.message);
  }
}

// Delete User
async function deleteAdminUser(userId) {
  if (confirm('Are you sure you want to delete this user?')) {
    const result = await apiCall(`/admin/users/${userId}`, 'DELETE');
    if (result.success) {
      alert('User deleted');
      loadAdminUsers();
    }
  }
}

// Change User Password
async function changeAdminUserPassword(userId) {
  const newPassword = prompt('Enter new password:');
  if (newPassword) {
    const result = await apiCall(`/admin/users/${userId}/change-password`, 'POST', {
      newPassword
    });

    if (result.success) {
      alert('Password changed successfully');
    } else {
      alert('Failed: ' + result.message);
    }
  }
}

// Delete Content
async function deleteAdminContent(type, contentId) {
  if (confirm('Delete this content?')) {
    const result = await apiCall(`/admin/content/${type}/${contentId}`, 'DELETE');
    if (result.success) {
      alert('Content deleted');
      // Reload appropriate section
    }
  }
}
\`\`\`

---

## PART 11: INITIALIZATION

Add this to the beginning of each dashboard HTML file:

\`\`\`html
<script>
  // Check authentication
  checkAuth();

  // Load user info
  const user = getCurrentUser();
  document.getElementById('user-name').textContent = user.fullName;
  document.getElementById('user-id').textContent = user.registeredId;

  // Load initial data
  window.addEventListener('load', () => {
    loadNotes();
    loadEvents();
    loadMarketplaceItems();
    loadLostFoundPosts();
    loadCommunityPosts();
    loadWishlist();
  });
</script>
\`\`\`

---

## SUMMARY

Your frontend is now fully integrated with the backend! Every feature:
✅ Sends requests to backend API
✅ Receives and displays data
✅ Handles errors gracefully
✅ Updates database in real-time
✅ Maintains user authentication

---
