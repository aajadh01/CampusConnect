# 🗺️ CampusConnect Backend & Database - Complete Roadmap

## Overview
This roadmap guides you through building a complete backend and database system for CampusConnect from zero knowledge to a fully functional production system.

**Total Time Estimate:** 20-30 hours (spread over 1-2 weeks)

---

## 📋 Prerequisites (Before You Start)

### What You Need:
1. **A Computer** - Windows, Mac, or Linux
2. **Internet Connection** - To download software
3. **Text Editor** - VS Code (free)
4. **Basic Understanding** - How websites work (frontend sends data, backend processes it, database stores it)

### What You DON'T Need:
- ❌ Prior backend experience
- ❌ Database knowledge
- ❌ Paid software or services
- ❌ Advanced programming skills

---

## 🎯 The Complete Roadmap

### **PHASE 1: Environment Setup (2-3 hours)**
**Goal:** Install all necessary software on your computer

#### Step 1.1: Install Node.js
- **What is it?** The runtime that lets you run JavaScript on your computer (not just in browser)
- **Why?** Your backend will be written in Node.js
- **How:**
  1. Go to https://nodejs.org
  2. Download LTS version (Long Term Support)
  3. Install it (click Next, Next, Finish)
  4. Verify: Open terminal/command prompt and type `node --version`
  5. You should see a version number like `v18.17.0`

#### Step 1.2: Install PostgreSQL
- **What is it?** A database system that stores all your data
- **Why?** CampusConnect needs to store users, resources, events, etc.
- **How:**
  1. Go to https://www.postgresql.org/download
  2. Download for your operating system
  3. Install it (remember the password you set for "postgres" user)
  4. Verify: Open pgAdmin (comes with PostgreSQL) and login

#### Step 1.3: Install VS Code
- **What is it?** A code editor where you'll write your backend code
- **Why?** Makes writing code easier with syntax highlighting and tools
- **How:**
  1. Go to https://code.visualstudio.com
  2. Download and install
  3. Open it and install these extensions:
     - "Prisma" (by Prisma)
     - "Thunder Client" (for testing APIs)
     - "PostgreSQL" (by Chris Kolkman)

#### Step 1.4: Install Git (Optional but Recommended)
- **What is it?** Version control system
- **Why?** Track changes to your code
- **How:**
  1. Go to https://git-scm.com
  2. Download and install
  3. Verify: Type `git --version` in terminal

**✅ Phase 1 Complete When:** You can run `node --version`, `psql --version`, and VS Code opens

---

### **PHASE 2: Database Creation (3-4 hours)**
**Goal:** Create the database structure that will store all CampusConnect data

#### Step 2.1: Create Database
- Open pgAdmin (comes with PostgreSQL)
- Create a new database called `campusconnect_db`
- This is where all data will be stored

#### Step 2.2: Create Database Tables
You'll create 12 tables:

1. **users** - Stores user information (name, email, password, role)
2. **resources** - Stores notes/resources uploaded by faculty
3. **resource_upvotes** - Tracks who upvoted which resources
4. **resource_wishlist** - Tracks which resources students saved
5. **events** - Stores events created by organizers
6. **event_registrations** - Tracks which students registered for events
7. **marketplace_items** - Stores items for buy/sell
8. **marketplace_transactions** - Tracks purchases
9. **lost_found_items** - Stores lost/found posts
10. **community_posts** - Stores community discussion posts
11. **post_votes** - Tracks upvotes/downvotes on posts
12. **post_replies** - Stores replies to posts

**How to Create:**
- Use the SQL scripts provided in `DATABASE_CREATION_STEP_BY_STEP.md`
- Copy-paste each SQL command into pgAdmin
- Verify each table is created

#### Step 2.3: Add Sample Data (Optional)
- Insert test data so you can see how the system works
- Create test users: 1 admin, 1 faculty, 1 organizer, 1 student
- Create sample resources, events, marketplace items

**✅ Phase 2 Complete When:** You can see all 12 tables in pgAdmin with data

---

### **PHASE 3: Backend Project Setup (2-3 hours)**
**Goal:** Create the backend server project structure

#### Step 3.1: Create Project Folder
\`\`\`bash
# Open terminal/command prompt
mkdir campusconnect-backend
cd campusconnect-backend
\`\`\`

#### Step 3.2: Initialize Node.js Project
\`\`\`bash
npm init -y
\`\`\`
This creates a `package.json` file that tracks your project dependencies.

#### Step 3.3: Install Required Packages
\`\`\`bash
npm install express cors dotenv prisma @prisma/client bcryptjs jsonwebtoken
npm install -D nodemon
\`\`\`

**What each does:**
- `express` - Web framework for creating API endpoints
- `cors` - Allows frontend to communicate with backend
- `dotenv` - Manages environment variables (passwords, secrets)
- `prisma` - Makes database easier to work with
- `@prisma/client` - Prisma client for database queries
- `bcryptjs` - Encrypts passwords
- `jsonwebtoken` - Creates secure login tokens
- `nodemon` - Auto-restarts server when you make changes

#### Step 3.4: Setup Prisma
\`\`\`bash
npx prisma init
\`\`\`

This creates:
- `.env` file - For storing secrets
- `prisma/schema.prisma` - Database schema definition

#### Step 3.5: Configure Database Connection
Edit `.env` file:
\`\`\`
DATABASE_URL="postgresql://postgres:YOUR_PASSWORD@localhost:5432/campusconnect_db"
\`\`\`
Replace `YOUR_PASSWORD` with the password you set during PostgreSQL installation.

#### Step 3.6: Create Prisma Schema
Copy the schema from `DATABASE_DOCUMENTATION.md` into `prisma/schema.prisma`

#### Step 3.7: Generate Prisma Client
\`\`\`bash
npx prisma generate
\`\`\`

**✅ Phase 3 Complete When:** You have a project folder with all packages installed and Prisma configured

---

### **PHASE 4: Create API Endpoints (6-8 hours)**
**Goal:** Build the backend API that frontend will communicate with

#### Step 4.1: Create Project Structure
\`\`\`
campusconnect-backend/
├── server.js                 # Main server file
├── .env                      # Environment variables
├── prisma/
│   └── schema.prisma        # Database schema
├── routes/
│   ├── auth.js              # Login/Register endpoints
│   ├── resources.js         # Resources endpoints
│   ├── events.js            # Events endpoints
│   ├── marketplace.js       # Marketplace endpoints
│   ├── lostfound.js         # Lost & Found endpoints
│   └── community.js         # Community endpoints
├── middleware/
│   ├── auth.js              # Authentication middleware
│   └── errorHandler.js      # Error handling
└── controllers/
    ├── authController.js
    ├── resourceController.js
    ├── eventController.js
    ├── marketplaceController.js
    ├── lostfoundController.js
    └── communityController.js
\`\`\`

#### Step 4.2: Create Main Server File (server.js)
\`\`\`javascript
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/resources', require('./routes/resources'));
app.use('/api/events', require('./routes/events'));
app.use('/api/marketplace', require('./routes/marketplace'));
app.use('/api/lostfound', require('./routes/lostfound'));
app.use('/api/community', require('./routes/community'));

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
\`\`\`

#### Step 4.3: Create Authentication Endpoints
**Endpoints to create:**
- `POST /api/auth/login` - User login
- `POST /api/auth/logout` - User logout
- `GET /api/auth/me` - Get current user info

#### Step 4.4: Create Resources Endpoints
**Endpoints to create:**
- `GET /api/resources` - Get all resources
- `POST /api/resources` - Upload new resource
- `GET /api/resources/:id` - Get single resource
- `PUT /api/resources/:id` - Update resource
- `DELETE /api/resources/:id` - Delete resource
- `POST /api/resources/:id/upvote` - Upvote resource
- `POST /api/resources/:id/wishlist` - Add to wishlist
- `GET /api/resources/wishlist/my` - Get my wishlist

#### Step 4.5: Create Events Endpoints
**Endpoints to create:**
- `GET /api/events` - Get all events
- `POST /api/events` - Create event
- `GET /api/events/:id` - Get single event
- `PUT /api/events/:id` - Update event
- `DELETE /api/events/:id` - Delete event
- `POST /api/events/:id/register` - Register for event
- `POST /api/events/:id/unregister` - Unregister from event

#### Step 4.6: Create Marketplace Endpoints
**Endpoints to create:**
- `GET /api/marketplace` - Get all items
- `POST /api/marketplace` - Post item for sale
- `GET /api/marketplace/:id` - Get single item
- `PUT /api/marketplace/:id` - Update item
- `DELETE /api/marketplace/:id` - Delete item
- `POST /api/marketplace/:id/purchase` - Purchase item

#### Step 4.7: Create Lost & Found Endpoints
**Endpoints to create:**
- `GET /api/lostfound` - Get all posts
- `POST /api/lostfound` - Create lost/found post
- `GET /api/lostfound/:id` - Get single post
- `PUT /api/lostfound/:id` - Update post
- `DELETE /api/lostfound/:id` - Delete post
- `POST /api/lostfound/:id/claim` - Claim found item

#### Step 4.8: Create Community Endpoints
**Endpoints to create:**
- `GET /api/community` - Get all posts
- `POST /api/community` - Create post
- `GET /api/community/:id` - Get single post
- `PUT /api/community/:id` - Update post
- `DELETE /api/community/:id` - Delete post
- `POST /api/community/:id/vote` - Upvote/downvote post
- `POST /api/community/:id/reply` - Reply to post
- `GET /api/community/:id/replies` - Get replies

**✅ Phase 4 Complete When:** All endpoints are created and tested with Thunder Client

---

### **PHASE 5: Test Backend (2-3 hours)**
**Goal:** Verify all API endpoints work correctly

#### Step 5.1: Start Backend Server
\`\`\`bash
npm start
\`\`\`
You should see: `Server running on http://localhost:5000`

#### Step 5.2: Test Each Endpoint
Use Thunder Client (VS Code extension) to test:
1. Login endpoint - verify you get a token
2. Get resources - verify you get data
3. Create resource - verify it saves to database
4. Update resource - verify changes are saved
5. Delete resource - verify it's removed
6. Test all other endpoints similarly

#### Step 5.3: Check Database
After each test, check pgAdmin to verify data is actually being saved/updated/deleted.

**✅ Phase 5 Complete When:** All endpoints work and data persists in database

---

### **PHASE 6: Frontend Integration (3-4 hours)**
**Goal:** Connect frontend to backend

#### Step 6.1: Create API Helper File
Create `api-helper.js` in your frontend project:
\`\`\`javascript
const API_URL = 'http://localhost:5000/api';

// Helper function for API calls
async function apiCall(endpoint, method = 'GET', data = null) {
  const options = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${localStorage.getItem('token')}`
    }
  };

  if (data) {
    options.body = JSON.stringify(data);
  }

  const response = await fetch(`${API_URL}${endpoint}`, options);
  return response.json();
}

// Export functions for each feature
module.exports = { apiCall, API_URL };
\`\`\`

#### Step 6.2: Update Login Function
Replace the login function in `script.js`:
\`\`\`javascript
async function login(email, password) {
  const result = await apiCall('/auth/login', 'POST', { email, password });
  
  if (result.token) {
    localStorage.setItem('token', result.token);
    localStorage.setItem('user', JSON.stringify(result.user));
    // Redirect to dashboard
    window.location.href = 'dashboard.html';
  } else {
    alert('Login failed: ' + result.message);
  }
}
\`\`\`

#### Step 6.3: Update All Dashboard Functions
Update functions to call backend instead of using localStorage:
- `loadResources()` - Call `/api/resources`
- `loadEvents()` - Call `/api/events`
- `loadMarketplaceItems()` - Call `/api/marketplace`
- `loadLostFoundItems()` - Call `/api/lostfound`
- `loadCommunityPosts()` - Call `/api/community`

#### Step 6.4: Update Create/Update/Delete Functions
Update all functions that modify data to call backend endpoints.

#### Step 6.5: Test Frontend-Backend Connection
1. Start backend server: `npm start`
2. Open frontend in browser
3. Try logging in - should connect to backend
4. Try creating a resource - should save to database
5. Refresh page - data should still be there (from database, not localStorage)

**✅ Phase 6 Complete When:** Frontend successfully communicates with backend and data persists

---

### **PHASE 7: Add Missing Frontend Features (2-3 hours)**
**Goal:** Add any missing HTML/JavaScript for new features

#### Step 7.1: Create Registration Page
- Create `register.html` for admin to create users
- Add form fields: name, email, password, role
- Add JavaScript to call `/api/auth/register`

#### Step 7.2: Create User Profile Page
- Create `profile.html` for users to view/edit their profile
- Add password change functionality
- Call `/api/auth/updateProfile`

#### Step 7.3: Add Admin User Management
- Create admin page to view all users
- Add ability to delete users
- Add ability to change user roles

#### Step 7.4: Add File Upload
- Update resource upload to handle file uploads
- Backend should save files to server or cloud storage

**✅ Phase 7 Complete When:** All frontend features are complete and working

---

### **PHASE 8: Security & Optimization (2-3 hours)**
**Goal:** Make the system secure and fast

#### Step 8.1: Add Input Validation
- Validate all user inputs on backend
- Check email format, password strength, etc.

#### Step 8.2: Add Error Handling
- Wrap all database queries in try-catch
- Return meaningful error messages
- Log errors for debugging

#### Step 8.3: Add Rate Limiting
- Prevent brute force attacks on login
- Limit API requests per user

#### Step 8.4: Add Logging
- Log all important actions
- Track who did what and when

#### Step 8.5: Optimize Database Queries
- Add indexes to frequently searched columns
- Use pagination for large datasets

**✅ Phase 8 Complete When:** System is secure and performs well

---

### **PHASE 9: Deployment (2-3 hours)**
**Goal:** Make the system live on the internet

#### Step 9.1: Choose Hosting
Free options:
- **Render** (https://render.com) - Free tier for backend
- **Railway** (https://railway.app) - Free tier for backend
- **Vercel** - For frontend
- **Supabase** - Free PostgreSQL database

#### Step 9.2: Deploy Database
- Create PostgreSQL database on Supabase or Railway
- Run migrations to create tables
- Backup your local database

#### Step 9.3: Deploy Backend
- Push code to GitHub
- Connect GitHub to Render/Railway
- Deploy automatically

#### Step 9.4: Deploy Frontend
- Push frontend code to GitHub
- Deploy to Vercel
- Update API URL to point to deployed backend

#### Step 9.5: Test Live System
- Test all features on live website
- Verify data persists
- Check for errors

**✅ Phase 9 Complete When:** Website is live and working

---

## 🚀 Where to Start RIGHT NOW

### **Today (Next 2-3 hours):**
1. Read this entire roadmap
2. Complete PHASE 1 (Environment Setup)
3. Verify all software is installed

### **Tomorrow (Next 3-4 hours):**
1. Complete PHASE 2 (Database Creation)
2. Verify all 12 tables are created
3. Add sample data

### **Day 3 (Next 2-3 hours):**
1. Complete PHASE 3 (Backend Setup)
2. Verify Prisma is configured
3. Test database connection

### **Days 4-5 (Next 6-8 hours):**
1. Complete PHASE 4 (Create API Endpoints)
2. Test each endpoint with Thunder Client
3. Verify data is saved to database

### **Day 6 (Next 3-4 hours):**
1. Complete PHASE 5 (Test Backend)
2. Complete PHASE 6 (Frontend Integration)
3. Test frontend-backend connection

### **Day 7 (Next 2-3 hours):**
1. Complete PHASE 7 (Add Missing Features)
2. Complete PHASE 8 (Security)
3. Test everything

### **Day 8 (Next 2-3 hours):**
1. Complete PHASE 9 (Deployment)
2. Go live!

---

## 📚 Documentation Reference

For detailed instructions, refer to:
- **DATABASE_CREATION_STEP_BY_STEP.md** - Detailed database setup
- **BACKEND_CREATION_STEP_BY_STEP.md** - Detailed backend setup
- **INTEGRATION_STEP_BY_STEP_REVISED.md** - Detailed integration
- **FRONTEND_MODIFICATIONS_NEEDED.md** - Frontend changes needed
- **COMPLETE_FUNCTIONALITY_DOCUMENTATION.md** - How everything works
- **TROUBLESHOOTING_GUIDE.md** - Solutions to common problems

---

## ✅ Success Checklist

By the end of this roadmap, you will have:

- ✅ PostgreSQL database with 12 tables
- ✅ Node.js backend with 40+ API endpoints
- ✅ Frontend connected to backend
- ✅ User authentication system
- ✅ All 6 features working (Resources, Events, Marketplace, Lost & Found, Community, Admin)
- ✅ Multi-user support
- ✅ Data persistence
- ✅ Security implemented
- ✅ System deployed live
- ✅ Production-ready application

---

## 🎯 Key Principles to Remember

1. **One Phase at a Time** - Don't skip ahead
2. **Test After Each Phase** - Verify everything works
3. **Read Documentation** - Refer to detailed guides when stuck
4. **Ask Questions** - Use troubleshooting guide
5. **Take Breaks** - Don't try to do everything in one day
6. **Celebrate Progress** - Each phase is a milestone!

---

## 💡 Tips for Success

1. **Keep Terminal Open** - You'll use it frequently
2. **Use VS Code** - Makes coding much easier
3. **Test Frequently** - Don't wait until the end
4. **Save Your Work** - Use Git to track changes
5. **Document Your Changes** - Write comments in code
6. **Join Communities** - Stack Overflow, Reddit for help
7. **Be Patient** - Learning takes time

---

## 🆘 If You Get Stuck

1. **Check Troubleshooting Guide** - Most issues are covered
2. **Read Error Messages** - They tell you what's wrong
3. **Check Browser Console** - Frontend errors show there
4. **Check Terminal** - Backend errors show there
5. **Google the Error** - Usually someone had the same issue
6. **Take a Break** - Fresh eyes help solve problems

---

## 🎉 You've Got This!

This roadmap is your complete guide from zero to a fully functional CampusConnect system. Follow it step-by-step, and you'll have a professional, production-ready application.

**Start with PHASE 1 today. You can do this!** 🚀
