# CampusConnect - Backend Documentation

## Overview

This document provides comprehensive guidance for building the backend infrastructure for CampusConnect, a campus management platform. The backend will handle authentication, data persistence, business logic, and API services for the frontend application.

---

## Technology Stack Recommendations

### Backend Framework (Choose One)

#### **Option 1: Node.js + Express (Recommended for JavaScript developers)**
- **Pros**: Same language as frontend, large ecosystem, easy to learn
- **Cons**: Single-threaded, not ideal for CPU-intensive tasks
- **Best for**: Rapid development, real-time features
- **Installation**: `npm install express`

#### **Option 2: Python + Django/Flask**
- **Pros**: Clean syntax, excellent ORM, built-in admin panel
- **Cons**: Slower than Node.js, requires Python knowledge
- **Best for**: Complex business logic, data science integration
- **Installation**: `pip install django` or `pip install flask`

#### **Option 3: Python + FastAPI**
- **Pros**: Modern, fast, automatic API documentation
- **Cons**: Smaller ecosystem than Django
- **Best for**: High-performance APIs, microservices
- **Installation**: `pip install fastapi uvicorn`

#### **Option 4: Go + Gin**
- **Pros**: Very fast, compiled, excellent concurrency
- **Cons**: Steeper learning curve
- **Best for**: High-traffic applications
- **Installation**: `go get -u github.com/gin-gonic/gin`

**RECOMMENDED**: Node.js + Express for ease of integration with frontend

---

### Database (Choose One)

#### **Option 1: PostgreSQL (Recommended)**
- **Type**: Relational SQL database
- **Pros**: Powerful, reliable, excellent for complex queries, free and open-source
- **Cons**: Requires more setup than SQLite
- **Best for**: Production applications
- **Installation**: Download from postgresql.org or use Docker
- **Free Hosting**: Render, Railway, Supabase (PostgreSQL with auth)

#### **Option 2: MySQL**
- **Type**: Relational SQL database
- **Pros**: Widely used, good performance, free
- **Cons**: Less advanced features than PostgreSQL
- **Best for**: Web applications
- **Installation**: Download from mysql.com or use Docker
- **Free Hosting**: Render, Railway

#### **Option 3: MongoDB**
- **Type**: NoSQL document database
- **Pros**: Flexible schema, easy to scale, good for rapid development
- **Cons**: Higher memory usage, less suitable for complex relationships
- **Best for**: Flexible data structures
- **Installation**: Download from mongodb.com or use Docker
- **Free Hosting**: MongoDB Atlas (free tier available)

#### **Option 4: SQLite**
- **Type**: Relational SQL database
- **Pros**: No setup required, file-based, perfect for learning
- **Cons**: Not suitable for production, limited concurrency
- **Best for**: Development and testing
- **Installation**: Built into most systems

**RECOMMENDED**: PostgreSQL for production, SQLite for development

---

### ORM/Query Builder

#### **For Node.js + Express**
- **Sequelize**: Full-featured ORM for SQL databases
- **TypeORM**: TypeScript-first ORM
- **Prisma**: Modern ORM with excellent DX (Developer Experience)
- **Knex.js**: Query builder for SQL databases

**RECOMMENDED**: Prisma (easiest to use, great documentation)

#### **For Python + Django**
- **Django ORM**: Built-in, excellent
- **SQLAlchemy**: Powerful, flexible

#### **For Python + FastAPI**
- **SQLAlchemy**: Industry standard
- **Tortoise ORM**: Async ORM

---

### Authentication & Authorization

- **JWT (JSON Web Tokens)**: Stateless authentication
- **bcrypt**: Password hashing library
- **Passport.js** (Node.js): Authentication middleware
- **python-jose** (Python): JWT handling

---

### Additional Libraries

#### **Node.js + Express Stack**
\`\`\`json
{
  "dependencies": {
    "express": "^4.18.0",
    "prisma": "^5.0.0",
    "@prisma/client": "^5.0.0",
    "jsonwebtoken": "^9.0.0",
    "bcryptjs": "^2.4.3",
    "dotenv": "^16.0.0",
    "cors": "^2.8.5",
    "express-validator": "^7.0.0",
    "multer": "^1.4.5",
    "axios": "^1.4.0"
  },
  "devDependencies": {
    "nodemon": "^3.0.0",
    "jest": "^29.0.0"
  }
}
\`\`\`

#### **Python + FastAPI Stack**
\`\`\`
fastapi==0.104.0
uvicorn==0.24.0
sqlalchemy==2.0.0
psycopg2-binary==2.9.0
python-jose==3.3.0
passlib==1.7.4
bcrypt==4.1.0
python-multipart==0.0.6
pydantic==2.0.0
python-dotenv==1.0.0
\`\`\`

---

## Project Structure

### Node.js + Express Backend Structure

\`\`\`
backend/
├── src/
│   ├── config/
│   │   ├── database.js           # Database connection
│   │   ├── environment.js        # Environment variables
│   │   └── constants.js          # App constants
│   ├── middleware/
│   │   ├── auth.js               # JWT authentication
│   │   ├── errorHandler.js       # Error handling
│   │   ├── validation.js         # Input validation
│   │   └── cors.js               # CORS configuration
│   ├── routes/
│   │   ├── auth.js               # Authentication routes
│   │   ├── resources.js          # Resource routes
│   │   ├── marketplace.js        # Marketplace routes
│   │   ├── events.js             # Event routes
│   │   ├── discussions.js        # Discussion routes
│   │   ├── lostFound.js          # Lost & Found routes
│   │   ├── users.js              # User routes
│   │   └── admin.js              # Admin routes
│   ├── controllers/
│   │   ├── authController.js     # Auth logic
│   │   ├── resourceController.js # Resource logic
│   │   ├── marketplaceController.js
│   │   ├── eventController.js
│   │   ├── discussionController.js
│   │   ├── lostFoundController.js
│   │   ├── userController.js
│   │   └── adminController.js
│   ├── models/
│   │   ├── User.js
│   │   ├── Resource.js
│   │   ├── MarketplaceItem.js
│   │   ├── Event.js
│   │   ├── Discussion.js
│   │   ├── LostFoundItem.js
│   │   └── Comment.js
│   ├── services/
│   │   ├── authService.js        # Auth business logic
│   │   ├── emailService.js       # Email notifications
│   │   ├── fileService.js        # File handling
│   │   └── notificationService.js
│   ├── utils/
│   │   ├── validators.js         # Validation functions
│   │   ├── helpers.js            # Helper functions
│   │   ├── logger.js             # Logging
│   │   └── errorHandler.js       # Error utilities
│   ├── uploads/                  # Temporary file storage
│   └── app.js                    # Express app setup
├── prisma/
│   └── schema.prisma             # Database schema
├── tests/
│   ├── auth.test.js
│   ├── resources.test.js
│   └── integration.test.js
├── .env                          # Environment variables (DO NOT COMMIT)
├── .env.example                  # Example env file
├── .gitignore
├── package.json
├── server.js                     # Entry point
└── README.md
\`\`\`

---

## Database Schema Design

### User Table
\`\`\`sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  regNumber VARCHAR(20) UNIQUE NOT NULL,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('student', 'teacher', 'organizer', 'admin') NOT NULL,
  branch VARCHAR(50),
  semester VARCHAR(10),
  profileImage VARCHAR(255),
  bio TEXT,
  points INT DEFAULT 0,
  isBanned BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_regNumber (regNumber),
  INDEX idx_role (role)
);
\`\`\`

### Resource Table
\`\`\`sql
CREATE TABLE resources (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  subject VARCHAR(100) NOT NULL,
  description TEXT,
  branch VARCHAR(50),
  semester VARCHAR(10),
  fileUrl VARCHAR(500) NOT NULL,
  fileName VARCHAR(255),
  uploadedById INT NOT NULL,
  uploadedByRole ENUM('student', 'teacher') NOT NULL,
  status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
  verifiedById INT,
  verificationReason TEXT,
  downloads INT DEFAULT 0,
  upvotes INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (uploadedById) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (verifiedById) REFERENCES users(id),
  INDEX idx_subject (subject),
  INDEX idx_branch (branch),
  INDEX idx_status (status),
  INDEX idx_uploadedById (uploadedById)
);
\`\`\`

### MarketplaceItem Table
\`\`\`sql
CREATE TABLE marketplace_items (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  description TEXT,
  imageUrl VARCHAR(500),
  contact VARCHAR(20) NOT NULL,
  postedById INT NOT NULL,
  purchasedById INT,
  sold BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (postedById) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (purchasedById) REFERENCES users(id),
  INDEX idx_postedById (postedById),
  INDEX idx_sold (sold)
);
\`\`\`

### Event Table
\`\`\`sql
CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  date DATE NOT NULL,
  venue VARCHAR(255) NOT NULL,
  googleFormUrl VARCHAR(500),
  posterUrl VARCHAR(500),
  organizerId INT NOT NULL,
  registrationClosed BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (organizerId) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_organizerId (organizerId),
  INDEX idx_date (date)
);
\`\`\`

### EventRegistration Table
\`\`\`sql
CREATE TABLE event_registrations (
  id SERIAL PRIMARY KEY,
  eventId INT NOT NULL,
  userId INT NOT NULL,
  registeredAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (eventId) REFERENCES events(id) ON DELETE CASCADE,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_registration (eventId, userId),
  INDEX idx_eventId (eventId),
  INDEX idx_userId (userId)
);
\`\`\`

### Discussion Table
\`\`\`sql
CREATE TABLE discussions (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  category ENUM('general', 'academic', 'events', 'help') DEFAULT 'general',
  postedById INT NOT NULL,
  upvotes INT DEFAULT 0,
  downvotes INT DEFAULT 0,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (postedById) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_category (category),
  INDEX idx_postedById (postedById)
);
\`\`\`

### Comment Table
\`\`\`sql
CREATE TABLE comments (
  id SERIAL PRIMARY KEY,
  discussionId INT NOT NULL,
  postedById INT NOT NULL,
  content TEXT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (discussionId) REFERENCES discussions(id) ON DELETE CASCADE,
  FOREIGN KEY (postedById) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_discussionId (discussionId),
  INDEX idx_postedById (postedById)
);
\`\`\`

### LostFoundItem Table
\`\`\`sql
CREATE TABLE lost_found_items (
  id SERIAL PRIMARY KEY,
  type ENUM('lost', 'found') NOT NULL,
  itemName VARCHAR(255) NOT NULL,
  description TEXT,
  location VARCHAR(255),
  contact VARCHAR(20) NOT NULL,
  imageUrl VARCHAR(500),
  postedById INT NOT NULL,
  resolved BOOLEAN DEFAULT FALSE,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (postedById) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_type (type),
  INDEX idx_postedById (postedById),
  INDEX idx_resolved (resolved)
);
\`\`\`

### Vote Table (for tracking upvotes/downvotes)
\`\`\`sql
CREATE TABLE votes (
  id SERIAL PRIMARY KEY,
  userId INT NOT NULL,
  targetType ENUM('resource', 'discussion') NOT NULL,
  targetId INT NOT NULL,
  voteType ENUM('upvote', 'downvote') NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_vote (userId, targetType, targetId),
  INDEX idx_userId (userId),
  INDEX idx_targetType (targetType)
);
\`\`\`

### Announcement Table
\`\`\`sql
CREATE TABLE announcements (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  postedById INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (postedById) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_postedById (postedById)
);
\`\`\`

### OrganizerRequest Table
\`\`\`sql
CREATE TABLE organizer_requests (
  id SERIAL PRIMARY KEY,
  userId INT NOT NULL,
  status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
  reason TEXT,
  requestedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  reviewedAt TIMESTAMP,
  reviewedById INT,
  FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (reviewedById) REFERENCES users(id),
  INDEX idx_status (status),
  INDEX idx_userId (userId)
);
\`\`\`

---

## API Endpoints Specification

### Authentication Endpoints

#### 1. Login
\`\`\`
POST /api/auth/login
Content-Type: application/json

Request:
{
  "regNumber": "23L31A0501",
  "password": "password123"
}

Response (200):
{
  "success": true,
  "token": "eyJhbGciOiJIUzI1NiIs...",
  "user": {
    "id": 1,
    "regNumber": "23L31A0501",
    "name": "User_0501",
    "role": "student",
    "email": "user@viit.ac.in"
  }
}

Response (401):
{
  "success": false,
  "message": "Invalid credentials"
}
\`\`\`

#### 2. Register (Admin Only)
\`\`\`
POST /api/auth/register
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "regNumber": "23L31A0502",
  "password": "password123",
  "role": "student",
  "name": "User_0502",
  "email": "user2@viit.ac.in",
  "branch": "CSE",
  "semester": "3-1"
}

Response (201):
{
  "success": true,
  "message": "User created successfully",
  "user": { ... }
}
\`\`\`

#### 3. Logout
\`\`\`
POST /api/auth/logout
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Logged out successfully"
}
\`\`\`

#### 4. Verify Token
\`\`\`
GET /api/auth/verify
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "user": { ... }
}
\`\`\`

---

### Resource Endpoints

#### 1. Get All Resources
\`\`\`
GET /api/resources?branch=CSE&semester=3-1&subject=DBMS&status=verified

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "DBMS Notes",
      "subject": "Database Management",
      "branch": "CSE",
      "semester": "3-1",
      "uploadedBy": "User_0501",
      "status": "verified",
      "downloads": 5,
      "upvotes": 12,
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ],
  "total": 1
}
\`\`\`

#### 2. Upload Resource
\`\`\`
POST /api/resources
Authorization: Bearer {token}
Content-Type: multipart/form-data

Request:
{
  "title": "DBMS Notes",
  "subject": "Database Management",
  "description": "Comprehensive notes on DBMS",
  "branch": "CSE",
  "semester": "3-1",
  "file": <binary file data>
}

Response (201):
{
  "success": true,
  "message": "Resource uploaded successfully",
  "resource": { ... }
}
\`\`\`

#### 3. Download Resource
\`\`\`
GET /api/resources/:id/download
Authorization: Bearer {token}

Response (200):
<binary file data>
\`\`\`

#### 4. Upvote Resource
\`\`\`
POST /api/resources/:id/upvote
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "upvotes": 13
}
\`\`\`

#### 5. Verify Resource (Faculty)
\`\`\`
POST /api/resources/:id/verify
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "approved": true,
  "reason": "Good quality notes"
}

Response (200):
{
  "success": true,
  "message": "Resource verified",
  "resource": { ... }
}
\`\`\`

#### 6. Delete Resource
\`\`\`
DELETE /api/resources/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Resource deleted"
}
\`\`\`

---

### Marketplace Endpoints

#### 1. Get All Items
\`\`\`
GET /api/marketplace?sold=false

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "Physics Textbook",
      "price": 250,
      "contact": "9876543210",
      "postedBy": "User_0501",
      "sold": false,
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ]
}
\`\`\`

#### 2. Post Item
\`\`\`
POST /api/marketplace
Authorization: Bearer {token}
Content-Type: multipart/form-data

Request:
{
  "title": "Physics Textbook",
  "price": 250,
  "description": "Used but in good condition",
  "contact": "9876543210",
  "image": <binary file data>
}

Response (201):
{
  "success": true,
  "item": { ... }
}
\`\`\`

#### 3. Purchase Item
\`\`\`
POST /api/marketplace/:id/purchase
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Item purchased",
  "item": { ... }
}
\`\`\`

#### 4. Delete Item
\`\`\`
DELETE /api/marketplace/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Item deleted"
}
\`\`\`

---

### Event Endpoints

#### 1. Get All Events
\`\`\`
GET /api/events?date=2024-11-15

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "Tech Fest 2024",
      "date": "2024-11-15",
      "venue": "Main Auditorium",
      "organizer": "Club_President",
      "registrationClosed": false,
      "registeredCount": 45
    }
  ]
}
\`\`\`

#### 2. Create Event (Organizer)
\`\`\`
POST /api/events
Authorization: Bearer {token}
Content-Type: multipart/form-data

Request:
{
  "title": "Tech Fest 2024",
  "date": "2024-11-15",
  "venue": "Main Auditorium",
  "description": "Annual technology festival",
  "googleFormUrl": "https://forms.google.com/...",
  "poster": <binary file data>
}

Response (201):
{
  "success": true,
  "event": { ... }
}
\`\`\`

#### 3. Register for Event
\`\`\`
POST /api/events/:id/register
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Registered for event"
}
\`\`\`

#### 4. Close Registration
\`\`\`
POST /api/events/:id/close-registration
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Registration closed"
}
\`\`\`

#### 5. Delete Event
\`\`\`
DELETE /api/events/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Event deleted"
}
\`\`\`

---

### Discussion Endpoints

#### 1. Get All Discussions
\`\`\`
GET /api/discussions?category=academic

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "title": "Best study resources for DBMS",
      "category": "academic",
      "postedBy": "User_0501",
      "upvotes": 5,
      "downvotes": 1,
      "commentCount": 3,
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ]
}
\`\`\`

#### 2. Post Discussion
\`\`\`
POST /api/discussions
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "title": "Best study resources for DBMS",
  "content": "Can anyone recommend good DBMS resources?",
  "category": "academic"
}

Response (201):
{
  "success": true,
  "discussion": { ... }
}
\`\`\`

#### 3. Add Comment
\`\`\`
POST /api/discussions/:id/comments
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "content": "Check the verified notes section"
}

Response (201):
{
  "success": true,
  "comment": { ... }
}
\`\`\`

#### 4. Upvote Discussion
\`\`\`
POST /api/discussions/:id/upvote
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "upvotes": 6
}
\`\`\`

#### 5. Delete Discussion
\`\`\`
DELETE /api/discussions/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Discussion deleted"
}
\`\`\`

---

### Lost & Found Endpoints

#### 1. Get All Items
\`\`\`
GET /api/lost-found?type=lost&resolved=false

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "type": "lost",
      "itemName": "Blue Backpack",
      "location": "Library, 2nd Floor",
      "contact": "9876543210",
      "postedBy": "User_0501",
      "resolved": false,
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ]
}
\`\`\`

#### 2. Post Item
\`\`\`
POST /api/lost-found
Authorization: Bearer {token}
Content-Type: multipart/form-data

Request:
{
  "type": "lost",
  "itemName": "Blue Backpack",
  "description": "Contains laptop and books",
  "location": "Library, 2nd Floor",
  "contact": "9876543210",
  "image": <binary file data>
}

Response (201):
{
  "success": true,
  "item": { ... }
}
\`\`\`

#### 3. Delete Item
\`\`\`
DELETE /api/lost-found/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "Item deleted"
}
\`\`\`

---

### Admin Endpoints

#### 1. Get All Users
\`\`\`
GET /api/admin/users?role=student&banned=false

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "regNumber": "23L31A0501",
      "name": "User_0501",
      "role": "student",
      "isBanned": false,
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ]
}
\`\`\`

#### 2. Create User
\`\`\`
POST /api/admin/users
Authorization: Bearer {token}
Content-Type: application/json

Request:
{
  "regNumber": "23L31A0502",
  "password": "password123",
  "role": "student",
  "name": "User_0502",
  "email": "user2@viit.ac.in"
}

Response (201):
{
  "success": true,
  "user": { ... }
}
\`\`\`

#### 3. Ban User
\`\`\`
POST /api/admin/users/:id/ban
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "User banned"
}
\`\`\`

#### 4. Delete User
\`\`\`
DELETE /api/admin/users/:id
Authorization: Bearer {token}

Response (200):
{
  "success": true,
  "message": "User deleted"
}
\`\`\`

#### 5. Get Moderation Queue
\`\`\`
GET /api/admin/moderation?type=resources

Response (200):
{
  "success": true,
  "data": [
    {
      "id": 1,
      "type": "resource",
      "title": "DBMS Notes",
      "status": "pending",
      "postedBy": "User_0501",
      "createdAt": "2024-10-17T10:30:00Z"
    }
  ]
}
\`\`\`

---

## Authentication & Authorization

### JWT Implementation

\`\`\`javascript
// Generate JWT Token
const generateToken = (userId, role) => {
  return jwt.sign(
    { userId, role },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Verify JWT Token
const verifyToken = (token) => {
  return jwt.verify(token, process.env.JWT_SECRET);
};

// Middleware to protect routes
const authMiddleware = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ message: 'No token' });
  
  try {
    const decoded = verifyToken(token);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Invalid token' });
  }
};
\`\`\`

### Role-Based Access Control (RBAC)

\`\`\`javascript
const roleMiddleware = (allowedRoles) => {
  return (req, res, next) => {
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ message: 'Forbidden' });
    }
    next();
  };
};

// Usage
app.post('/api/resources/:id/verify', 
  authMiddleware, 
  roleMiddleware(['teacher', 'admin']), 
  verifyResource
);
\`\`\`

---

## File Upload Handling

### Using Multer (Node.js)

\`\`\`javascript
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB
  fileFilter: (req, file, cb) => {
    const allowedTypes = /pdf|doc|docx|txt|jpg|jpeg|png/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Usage
app.post('/api/resources', authMiddleware, upload.single('file'), uploadResource);
\`\`\`

### Cloud Storage Alternative (AWS S3)

\`\`\`javascript
const AWS = require('aws-sdk');
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_KEY
});

const uploadToS3 = (file) => {
  const params = {
    Bucket: process.env.AWS_BUCKET_NAME,
    Key: `${Date.now()}-${file.originalname}`,
    Body: file.buffer,
    ContentType: file.mimetype
  };
  
  return s3.upload(params).promise();
};
\`\`\`

---

## Error Handling

### Centralized Error Handler

\`\`\`javascript
class AppError extends Error {
  constructor(message, statusCode) {
    super(message);
    this.statusCode = statusCode;
  }
}

const errorHandler = (err, req, res, next) => {
  const { statusCode = 500, message } = err;
  
  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack })
  });
};

app.use(errorHandler);
\`\`\`

---

## Environment Variables

### .env File Template

\`\`\`
# Server
PORT=5000
NODE_ENV=development

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/campusconnect

# JWT
JWT_SECRET=your_super_secret_jwt_key_here_change_in_production

# File Upload
MAX_FILE_SIZE=52428800
UPLOAD_DIR=./uploads

# AWS S3 (Optional)
AWS_ACCESS_KEY=your_aws_access_key
AWS_SECRET_KEY=your_aws_secret_key
AWS_BUCKET_NAME=campusconnect-uploads

# Email Service (Optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Frontend URL
FRONTEND_URL=http://localhost:3000
\`\`\`

---

## Deployment Options (Free/Low-Cost)

### Option 1: Render (Recommended)
- **Free tier**: 0.5GB RAM, 0.5 CPU
- **Database**: PostgreSQL included
- **Deployment**: Git integration
- **Website**: render.com

### Option 2: Railway
- **Free tier**: $5/month credit
- **Database**: PostgreSQL, MySQL, MongoDB
- **Deployment**: Git integration
- **Website**: railway.app

### Option 3: Heroku (Paid)
- **Pricing**: $7/month (Eco Dyno)
- **Database**: PostgreSQL add-on
- **Deployment**: Git integration
- **Website**: heroku.com

### Option 4: DigitalOcean
- **Pricing**: $4/month (Droplet)
- **Database**: Managed PostgreSQL
- **Deployment**: Manual or CI/CD
- **Website**: digitalocean.com

### Option 5: Vercel (Frontend) + Supabase (Backend)
- **Frontend**: Free on Vercel
- **Backend**: Free tier on Supabase (PostgreSQL + Auth)
- **Website**: vercel.com, supabase.com

---

## Development Workflow

### 1. Setup Local Development

\`\`\`bash
# Clone repository
git clone <repo-url>
cd backend

# Install dependencies
npm install

# Setup environment
cp .env.example .env
# Edit .env with your local database URL

# Run migrations
npx prisma migrate dev

# Start development server
npm run dev
\`\`\`

### 2. Database Migrations (Prisma)

\`\`\`bash
# Create migration
npx prisma migrate dev --name add_users_table

# Apply migrations
npx prisma migrate deploy

# Reset database (development only)
npx prisma migrate reset
\`\`\`

### 3. Testing

\`\`\`bash
# Run tests
npm test

# Run tests with coverage
npm test -- --coverage

# Run specific test file
npm test -- auth.test.js
\`\`\`

---

## Security Best Practices

1. **Password Hashing**: Use bcrypt with salt rounds ≥ 10
2. **JWT Expiration**: Set reasonable expiration times (7-30 days)
3. **HTTPS**: Always use HTTPS in production
4. **CORS**: Configure CORS to allow only frontend domain
5. **Rate Limiting**: Implement rate limiting on auth endpoints
6. **Input Validation**: Validate all user inputs
7. **SQL Injection**: Use parameterized queries (ORM handles this)
8. **XSS Protection**: Sanitize user inputs
9. **CSRF Protection**: Implement CSRF tokens for state-changing operations
10. **Secrets Management**: Never commit .env files, use environment variables

---

## Performance Optimization

1. **Database Indexing**: Index frequently queried columns
2. **Pagination**: Implement pagination for large datasets
3. **Caching**: Use Redis for caching frequently accessed data
4. **Query Optimization**: Use SELECT specific columns, avoid N+1 queries
5. **Compression**: Enable gzip compression
6. **CDN**: Use CDN for static assets
7. **Connection Pooling**: Use connection pooling for database
8. **Async Operations**: Use async/await for non-blocking operations

---

## Monitoring & Logging

### Logging Setup

\`\`\`javascript
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}
\`\`\`

### Error Tracking (Sentry)

\`\`\`javascript
const Sentry = require("@sentry/node");

Sentry.init({
  dsn: process.env.SENTRY_DSN,
  environment: process.env.NODE_ENV
});

app.use(Sentry.Handlers.errorHandler());
\`\`\`

---

## Testing Strategy

### Unit Tests
- Test individual functions and services
- Mock external dependencies
- Use Jest or Mocha

### Integration Tests
- Test API endpoints
- Test database interactions
- Use Supertest for HTTP testing

### Example Test

\`\`\`javascript
const request = require('supertest');
const app = require('../app');

describe('Auth Endpoints', () => {
  it('should login with valid credentials', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({
        regNumber: '23L31A0501',
        password: 'password123'
      });
    
    expect(res.statusCode).toBe(200);
    expect(res.body).toHaveProperty('token');
  });
});
\`\`\`

---

## Scaling Considerations

1. **Horizontal Scaling**: Deploy multiple instances behind load balancer
2. **Database Replication**: Use master-slave replication
3. **Caching Layer**: Implement Redis for session and data caching
4. **Message Queue**: Use RabbitMQ or Kafka for async operations
5. **Microservices**: Split into separate services as needed
6. **CDN**: Distribute static content globally

---

## Next Steps

1. Choose your tech stack (Node.js + Express recommended)
2. Set up local development environment
3. Create database schema using Prisma
4. Implement authentication system
5. Build API endpoints following the specification
6. Add input validation and error handling
7. Implement file upload handling
8. Add comprehensive logging and monitoring
9. Write unit and integration tests
10. Deploy to production (Render or Railway recommended)

---

## Resources & Documentation

- **Express.js**: https://expressjs.com
- **Prisma**: https://www.prisma.io/docs
- **PostgreSQL**: https://www.postgresql.org/docs
- **JWT**: https://jwt.io
- **Render**: https://render.com/docs
- **Railway**: https://docs.railway.app
- **Supabase**: https://supabase.com/docs

---

## Support & Questions

For questions or clarifications, refer to the inline code comments or consult the official documentation of the chosen technologies.
