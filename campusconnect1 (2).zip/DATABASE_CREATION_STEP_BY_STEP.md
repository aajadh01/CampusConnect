# DATABASE CREATION - COMPLETE BEGINNER GUIDE
## A Mentor's Step-by-Step Walkthrough

---

## PART 1: UNDERSTANDING WHAT WE'RE DOING

### What is a Database?
Think of a database like a **filing cabinet** for your website:
- **Filing Cabinet** = Database (PostgreSQL)
- **Drawers** = Tables (users, events, resources, etc.)
- **Files in each drawer** = Records/Rows (individual user data, event details)
- **Information on each file** = Columns (name, email, date, etc.)

### Why PostgreSQL?
- ✅ **Free** - No cost at all
- ✅ **Reliable** - Used by major companies
- ✅ **Scalable** - Handles millions of records
- ✅ **Secure** - Built-in security features
- ✅ **Easy to learn** - Simple SQL language

---

## PART 2: INSTALLATION (Windows, Mac, Linux)

### Step 1: Download PostgreSQL

**For Windows:**
1. Go to https://www.postgresql.org/download/windows/
2. Click "Download the installer"
3. Download the latest version (15 or 16)
4. Run the installer (.exe file)

**For Mac:**
1. Go to https://www.postgresql.org/download/macosx/
2. Download the installer
3. Run and follow instructions

**For Linux (Ubuntu):**
\`\`\`bash
sudo apt update
sudo apt install postgresql postgresql-contrib
\`\`\`

### Step 2: Installation Process

**During Installation, Remember These:**
- **Password**: Set a password for the "postgres" user (write it down!)
- **Port**: Keep it as 5432 (default)
- **Locale**: Keep as default

**Example Setup:**
\`\`\`
Username: postgres
Password: YourSecurePassword123
Port: 5432
\`\`\`

### Step 3: Verify Installation

**Windows/Mac:**
1. Open "pgAdmin" (installed with PostgreSQL)
2. Login with password you set
3. You should see "Servers" on the left

**Linux:**
\`\`\`bash
sudo -u postgres psql --version
\`\`\`

---

## PART 3: CREATE YOUR FIRST DATABASE

### Step 1: Open pgAdmin

1. Search for "pgAdmin" on your computer
2. Open it
3. Login with password you set during installation
4. You'll see a dashboard

### Step 2: Create Database

**Method 1: Using pgAdmin (Easiest)**

1. Right-click on "Databases" in left panel
2. Click "Create" → "Database"
3. Name it: `campusconnect_db`
4. Click "Save"

**Method 2: Using Command Line**

\`\`\`bash
# Open PostgreSQL terminal
psql -U postgres

# Create database
CREATE DATABASE campusconnect_db;

# Verify it was created
\l

# Exit
\q
\`\`\`

### Step 3: Verify Database Created

In pgAdmin, you should see:
\`\`\`
Servers
  └─ PostgreSQL 15
      └─ Databases
          └─ campusconnect_db
\`\`\`

---

## PART 4: CREATE TABLES (THE FILING DRAWERS)

### Understanding Tables

Each table is like a spreadsheet with:
- **Columns** = Information types (name, email, date)
- **Rows** = Individual records (each user, each event)
- **Data Types** = What kind of information (text, number, date)

### Common Data Types

| Type | What It Stores | Example |
|------|---|---|
| `VARCHAR(255)` | Text (up to 255 characters) | "John Doe" |
| `TEXT` | Long text | Event description |
| `INT` | Whole numbers | 100, 500 |
| `DECIMAL(10,2)` | Numbers with decimals | 99.99 |
| `BOOLEAN` | True/False | true, false |
| `TIMESTAMP` | Date and time | 2024-01-15 10:30:00 |
| `UUID` | Unique identifier | 550e8400-e29b-41d4-a716-446655440000 |

### Step 1: Open Query Editor

In pgAdmin:
1. Right-click on `campusconnect_db`
2. Click "Query Tool"
3. You'll see a text editor

### Step 2: Create Users Table

Copy and paste this code:

\`\`\`sql
CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  email VARCHAR(255) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  role VARCHAR(50) NOT NULL CHECK (role IN ('student', 'faculty', 'organizer', 'admin')),
  department VARCHAR(255),
  phone VARCHAR(20),
  profile_image_url TEXT,
  bio TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

**What This Does:**
- `id` = Unique number for each user (auto-generated)
- `email` = User's email (must be unique)
- `password` = Encrypted password
- `role` = What type of user (student, faculty, etc.)
- `created_at` = When user registered
- `updated_at` = When user last updated profile

**To Execute:**
1. Click the "Execute" button (play icon)
2. You should see "Query returned successfully"

### Step 3: Create Resources Table

\`\`\`sql
CREATE TABLE resources (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  file_url TEXT NOT NULL,
  uploaded_by INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

**What This Does:**
- Stores study materials, notes, books
- `uploaded_by` = Links to the user who uploaded it
- `REFERENCES users(id)` = Connection to users table

### Step 4: Create Events Table

\`\`\`sql
CREATE TABLE events (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  date TIMESTAMP NOT NULL,
  location VARCHAR(255) NOT NULL,
  organizer_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category VARCHAR(100),
  max_attendees INT,
  image_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

### Step 5: Create Event Attendees Table

\`\`\`sql
CREATE TABLE event_attendees (
  id SERIAL PRIMARY KEY,
  event_id INT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(event_id, user_id)
);
\`\`\`

**What This Does:**
- Tracks who is attending which event
- `UNIQUE(event_id, user_id)` = Same person can't join same event twice

### Step 6: Create Discussions Table

\`\`\`sql
CREATE TABLE discussions (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  created_by INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

### Step 7: Create Discussion Comments Table

\`\`\`sql
CREATE TABLE discussion_comments (
  id SERIAL PRIMARY KEY,
  discussion_id INT NOT NULL REFERENCES discussions(id) ON DELETE CASCADE,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  comment TEXT NOT NULL,
  upvotes INT DEFAULT 0,
  downvotes INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

### Step 8: Create Marketplace Items Table

\`\`\`sql
CREATE TABLE marketplace_items (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  price DECIMAL(10, 2) NOT NULL,
  seller_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category VARCHAR(100),
  image_url TEXT,
  condition VARCHAR(50),
  status VARCHAR(50) DEFAULT 'available' CHECK (status IN ('available', 'sold', 'pending')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

### Step 9: Create Lost & Found Table

\`\`\`sql
CREATE TABLE lost_found_items (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT NOT NULL,
  type VARCHAR(50) NOT NULL CHECK (type IN ('lost', 'found')),
  location VARCHAR(255),
  reported_by INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  image_url TEXT,
  status VARCHAR(50) DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
\`\`\`

### Step 10: Create Votes Table

\`\`\`sql
CREATE TABLE votes (
  id SERIAL PRIMARY KEY,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  comment_id INT NOT NULL REFERENCES discussion_comments(id) ON DELETE CASCADE,
  vote_type VARCHAR(10) NOT NULL CHECK (vote_type IN ('upvote', 'downvote')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, comment_id)
);
\`\`\`

---

## PART 5: VERIFY ALL TABLES CREATED

### In pgAdmin:

1. Expand `campusconnect_db` in left panel
2. Expand "Schemas" → "public" → "Tables"
3. You should see all 9 tables:
   - users
   - resources
   - events
   - event_attendees
   - discussions
   - discussion_comments
   - marketplace_items
   - lost_found_items
   - votes

### Using Command Line:

\`\`\`bash
psql -U postgres -d campusconnect_db

# List all tables
\dt

# See structure of a table
\d users

# Exit
\q
\`\`\`

---

## PART 6: UNDERSTANDING RELATIONSHIPS

### Visual Diagram

\`\`\`
users (Main table - all users)
  ├─ resources (uploaded_by → users.id)
  ├─ events (organizer_id → users.id)
  │   └─ event_attendees (user_id → users.id, event_id → events.id)
  ├─ discussions (created_by → users.id)
  │   └─ discussion_comments (user_id → users.id, discussion_id → discussions.id)
  │       └─ votes (user_id → users.id, comment_id → discussion_comments.id)
  ├─ marketplace_items (seller_id → users.id)
  └─ lost_found_items (reported_by → users.id)
\`\`\`

### What This Means

- **One user** can upload **many resources**
- **One user** can organize **many events**
- **Many users** can attend **one event**
- **One user** can create **many discussions**
- **Many users** can comment on **one discussion**
- **One user** can vote on **many comments**

---

## PART 7: ADD SAMPLE DATA (OPTIONAL)

To test your database, add sample data:

\`\`\`sql
-- Add a test user
INSERT INTO users (email, password, full_name, role, department)
VALUES ('student@viit.edu', 'hashed_password_123', 'John Doe', 'student', 'Computer Science');

-- Add a test event
INSERT INTO events (title, description, date, location, organizer_id, category)
VALUES ('Tech Workshop', 'Learn Web Development', '2024-02-15 10:00:00', 'Room 101', 1, 'Workshop');

-- Verify data
SELECT * FROM users;
SELECT * FROM events;
\`\`\`

---

## PART 8: BACKUP YOUR DATABASE

### Automatic Backup (Recommended)

\`\`\`bash
# Create backup file
pg_dump -U postgres campusconnect_db > backup.sql

# Restore from backup
psql -U postgres campusconnect_db < backup.sql
\`\`\`

### Schedule Regular Backups

**Windows:**
1. Create a batch file `backup.bat`:
```batch
@echo off
pg_dump -U postgres campusconnect_db > "C:\backups\backup_%date:~-4,4%%date:~-10,2%%date:~-7,2%.sql"
