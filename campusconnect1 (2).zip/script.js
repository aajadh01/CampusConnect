// Reminder: Always read this file before editing to avoid overwriting important logic.

// Global State Management
const appState = {
  currentUser: null,
  selectedRole: null,
  resources: [],
  marketplaceItems: [],
  events: [],
  lostFoundItems: [],
  discussions: [],
  notifications: [],
  points: 0,
  badges: [],
  users: [],
  organizerRequests: [],
  viewMyUploads: false, // extend global state: special filters
  viewMyPurchases: false, // extend global state: special filters
  lastAdded: null, // extend global state: lastAdded marker
  // extend app state
  chats: {}, // { [itemId]: [{by:'me'|'them', text, at}] }
  currentChatItemId: null,
}

// ===== UTILITY FUNCTIONS =====
function svgIcon(name, size = 16) {
  return `<svg class="icon-inline" width="${size}" height="${size}" aria-hidden="true" focusable="false"><use href="public/icons.jpg#${name}"></use></svg>`
}
function withIcon(name, text, size = 16) {
  // keep for other places that still use SVGs (e.g., buttons)
  const emojiMap = {
    book: "📚",
    tag: "🏷️",
    user: "👤",
    calendar: "📅",
    "map-pin": "📍",
    pin: "📍",
    phone: "📞",
    "id-badge": "🪪",
    branch: "🏫",
    semester: "📘",
    "arrow-up": "👍", // thumbs up for upvote
    download: "📥", // inbox for download
  }
  const e = emojiMap[name] || "•"
  return `<span class="emoji-inline" aria-hidden="true">${e}</span>${text}`
}

function getUserWishlist() {
  const key = "wishlist_" + getUserId()
  try {
    return JSON.parse(localStorage.getItem(key)) || []
  } catch {
    return []
  }
}
function setUserWishlist(arr) {
  const key = "wishlist_" + getUserId()
  localStorage.setItem(key, JSON.stringify(arr || []))
}
function isWishlisted(resourceId) {
  return getUserWishlist().includes(resourceId)
}
function toggleWishlist(resourceId) {
  const list = getUserWishlist()
  const idx = list.indexOf(resourceId)
  if (idx >= 0) list.splice(idx, 1)
  else list.push(resourceId)
  setUserWishlist(list)
  // re-render resources and wishlist to reflect state
  renderResources()
  renderWishlist()
}

// ===== PERMISSION CHECKS =====
function isAdmin() {
  return (appState?.currentUser?.role || "").toLowerCase() === "admin"
}

// Initialize app on page load
document.addEventListener("DOMContentLoaded", () => {
  initializePage()

  const createEventForm = document.getElementById("createEventForm")
  if (createEventForm) {
    createEventForm.addEventListener("submit", (e) => {
      e.preventDefault()
      handleCreateEvent()
    })
  }

  const announcementForm = document.getElementById("announcementForm")
  if (announcementForm) {
    announcementForm.addEventListener("submit", (e) => {
      e.preventDefault()
      postAnnouncement()
    })
  }

  const form = document.getElementById("adminCreateUserForm")
  if (form) {
    form.addEventListener("submit", (e) => {
      e.preventDefault()
      const name = document.getElementById("auName").value
      const role = document.getElementById("auRole").value
      const reg = document.getElementById("auReg").value
      const password = (document.getElementById("auPass")?.value || "").trim()

      if (!name || !role || !reg || !password) {
        alert("Please fill in all fields")
        return
      }

      appState.users.push({ id: Date.now(), name, role, reg, password, banned: false })
      saveStateToStorage()
      renderAdminUsers()
      updateAdminStats()
      form.reset()
      toggleModal("createUserModal")
      alert("User created successfully!")
    })
  }

  // Seed a sample organizer request on first load (if none)
  if ((appState.organizerRequests || []).length === 0) {
    appState.organizerRequests.push({ id: Date.now(), name: "Tech Club", by: "11831", email: "club@viit.ac.in" })
    saveStateToStorage()
  }

  // Profile dropdown toggles (common)
  const toggles = [
    { btn: "profileToggle", menu: "profileDropdown" },
    { btn: "profileToggleFaculty", menu: "profileDropdownFaculty" },
    { btn: "profileToggleOrganizer", menu: "profileDropdownOrganizer" },
    { btn: "profileToggleAdmin", menu: "profileDropdownAdmin" }, // added
  ]
  toggles.forEach(({ btn, menu }) => {
    const b = document.getElementById(btn)
    const m = document.getElementById(menu)
    if (b && m) {
      b.addEventListener("click", () => {
        const isActive = m.classList.contains("active")
        document.querySelectorAll(".profile-dropdown").forEach((el) => el.classList.remove("active"))
        m.classList.toggle("active", !isActive)
        b.setAttribute("aria-expanded", String(!isActive))
      })
      document.addEventListener("click", (e) => {
        if (m && !m.contains(e.target) && !b.contains(e.target)) m.classList.remove("active")
      })
    }
  })

  // Student: resource filter apply
  const applyRes = document.getElementById("applyResourceFilters")
  if (applyRes) applyRes.addEventListener("click", () => renderResources())

  const titleSearch = document.getElementById("filterTitle")
  if (titleSearch) titleSearch.addEventListener("input", () => renderResources())
  const wishlistSearch = document.getElementById("wishlistSearch")
  if (wishlistSearch) wishlistSearch.addEventListener("input", () => renderWishlist())

  // Student: lost & found tabs + search
  const lfTabs = ["lfTabAll", "lfTabLost", "lfTabFound"].map((id) => document.getElementById(id)).filter(Boolean)
  lfTabs.forEach((btn) =>
    btn.addEventListener("click", () => {
      lfTabs.forEach((b) => b.classList.remove("active"))
      btn.classList.add("active")
      renderLostFound()
    }),
  )
  const lfSearch = document.getElementById("lfSearch")
  if (lfSearch) lfSearch.addEventListener("input", () => renderLostFound())

  // Admin: apply user filters
  const adminApply = document.getElementById("adminApplyUserFilters")
  if (adminApply) adminApply.addEventListener("click", () => renderAdminUsers())

  const modApply = document.getElementById("modApplyFilters")
  if (modApply) modApply.addEventListener("click", () => renderModeration())

  const modRoleFilter = document.getElementById("modRoleFilter")
  if (modRoleFilter) {
    modRoleFilter.addEventListener("change", () => {
      updateModerationSections()
      renderModeration()
    })
  }

  const modSectionFilter = document.getElementById("modSectionFilter")
  if (modSectionFilter) {
    modSectionFilter.addEventListener("change", () => renderModeration())
  }

  // Organizer: poster live preview
  const evPoster = document.getElementById("evPoster")
  if (evPoster) {
    evPoster.addEventListener("change", () => {
      const file = evPoster.files?.[0]
      const preview = document.getElementById("posterPreview")
      if (!preview) return
      if (!file) {
        preview.innerHTML = "No poster selected"
        return
      }
      const url = URL.createObjectURL(file)
      preview.innerHTML = `<img src="${url}" alt="Poster preview" style="max-width:100%;border-radius:.5rem"/>`
      preview.setAttribute("aria-hidden", "false")
    })
  }

  // extend app state
  // appState.chats = appState.chats || {} // { [itemId]: [{by:'me'|'them', text, at}] }
  // appState.currentChatItemId = appState.currentChatItemId || null

  // render a chat thread for an item
  function renderChat(itemId) {
    const body = document.getElementById("chatBody")
    if (!body) return
    const thread = appState.chats[itemId] || []
    if (thread.length === 0) {
      // seed a simple starter thread
      appState.chats[itemId] = [
        { by: "them", text: "Hi! Is this available?", at: new Date().toISOString() },
        { by: "me", text: "Yes, it is.", at: new Date().toISOString() },
      ]
    }
    const msgs = (appState.chats[itemId] || [])
      .map((m) => `<div class="chat-message ${m.by === "me" ? "right" : "left"}">${m.text}</div>`)
      .join("")
    body.innerHTML = msgs
    body.scrollTop = body.scrollHeight
  }

  function openChat(itemId) {
    appState.currentChatItemId = itemId
    toggleModal("chatModal")
    renderChat(itemId)
  }
  window.openChat = openChat

  // Student: chat modal send
  const chatSend = document.getElementById("chatSend")
  if (chatSend) {
    chatSend.addEventListener("click", () => {
      const input = document.getElementById("chatInput")
      if (!input?.value) return
      const itemId = appState.currentChatItemId
      if (!itemId) return
      const thread = appState.chats[itemId] || []
      thread.push({ by: "me", text: input.value, at: new Date().toISOString() })
      appState.chats[itemId] = thread
      saveStateToStorage()
      input.value = ""
      renderChat(itemId)
    })
  }

  document.body.removeAttribute("data-theme")
  localStorage.removeItem("theme")
  const themeToggle = document.getElementById("toggleTheme")
  if (themeToggle) {
    const blk = themeToggle.closest(".switch") || themeToggle.closest(".form-group")
    if (blk) blk.remove()
  }

  const changePwdButtons = document.querySelectorAll('.dropdown-item[data-action="change-password"]')
  changePwdButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      navigateToSection("settings")
      // close any open profile dropdowns
      document.querySelectorAll(".profile-dropdown").forEach((el) => el.classList.remove("active"))
    })
  })

  const discussionsFilter = document.getElementById("discussionsFilter")
  if (discussionsFilter) {
    discussionsFilter.addEventListener("change", () => renderDiscussions())
  }

  const verifySearch = document.getElementById("verifySearch")
  if (verifySearch) {
    verifySearch.addEventListener("input", renderPendingVerification)
  }
  const verifySemester = document.getElementById("verifySemester")
  if (verifySemester) {
    verifySemester.addEventListener("change", renderPendingVerification)
  }
  const verifyBranch = document.getElementById("verifyBranch")
  if (verifyBranch) {
    verifyBranch.addEventListener("change", renderPendingVerification)
  }
  const applyVerifyFilters = document.getElementById("applyVerifyFilters")
  if (applyVerifyFilters) {
    applyVerifyFilters.addEventListener("click", renderPendingVerification)
  }

  enhanceDrawerAndProfile()
  roleSpecificCleanup()
})

// Initialize based on current page
function initializePage() {
  const currentPage = window.location.pathname.split("/").pop()

  loadStateFromStorage()

  if (currentPage === "login.html") {
    initializeLogin()
  } else if (currentPage.includes("dashboard.html") && currentPage !== "dashboard.html") {
    initializeDashboard()
  }
}

// ===== ROLE SELECTION =====
function selectRole(role) {
  appState.selectedRole = role
  localStorage.setItem("selectedRole", role)
  window.location.href = "login.html"
}

// ===== LOGIN & REGISTRATION =====
function initializeLogin() {
  const loginForm = document.getElementById("loginForm")
  const roleTitle = document.getElementById("roleTitle")
  const regNumberInput = document.getElementById("regNumber")
  const regNumberHint = document.getElementById("regNumberHint")

  const selectedRole = localStorage.getItem("selectedRole") || "student"
  appState.selectedRole = selectedRole

  const roleInfo = {
    student: {
      title: "Student Login",
      placeholder: "23L31A0501",
      hint: "Students: 23L31A0501 | Staff: 11831",
    },
    teacher: {
      title: "Faculty Login",
      placeholder: "11831",
      hint: "Students: 23L31A0501 | Staff: 11831",
    },
    organizer: {
      title: "Organizer Login",
      placeholder: "11831",
      hint: "Students: 23L31A0501 | Staff: 11831",
    },
    admin: {
      title: "Admin Login",
      placeholder: "11831",
      hint: "Students: 23L31A0501 | Staff: 11831",
    },
  }

  roleTitle.textContent = roleInfo[selectedRole].title
  regNumberInput.placeholder = roleInfo[selectedRole].placeholder
  regNumberHint.textContent = roleInfo[selectedRole].hint

  // Handle form submission
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault()

    const formData = {
      regNumber: document.getElementById("regNumber").value,
      password: document.getElementById("password").value,
      role: selectedRole,
    }

    if (!validateRegNumber(formData.regNumber, selectedRole)) {
      alert(`Please enter a valid registration number`)
      return
    }

    // Simulate authentication (in real app, this would be an API call)
    handleLogin(formData)
  })
}

function validateRegNumber(regNumber, role) {
  // Student format: 2 digits + 1 letter + 2 digits + 1 letter + 4 digits (e.g., 23L31A0501)
  const studentPattern = /^[0-9]{2}[A-Z]{1}[0-9]{2}[A-Z]{1}[0-9]{4}$/i

  // Staff format (faculty, admin, organizer): 5 digits (e.g., 11831)
  const staffPattern = /^[0-9]{5}$/

  if (role === "student") {
    return studentPattern.test(regNumber)
  } else {
    // For faculty, admin, and organizer roles
    return staffPattern.test(regNumber)
  }
}

// function validateEmail(email, role) { ... }

function handleLogin(formData) {
  // Simulate login (placeholder for backend integration)
  appState.currentUser = {
    regNumber: formData.regNumber,
    role: formData.role,
    name: `User_${formData.regNumber.slice(-4)}`,
  }

  localStorage.setItem("currentUser", JSON.stringify(appState.currentUser))
  // Store role for stat updates
  localStorage.setItem("userRole", formData.role)

  // Redirect to appropriate dashboard
  redirectToDashboard(formData.role)
}

function redirectToDashboard(role) {
  window.location.href = `${role}-dashboard.html`
}

// ===== DASHBOARD INITIALIZATION =====
function initializeDashboard() {
  // Check if user is logged in
  const currentUser = localStorage.getItem("currentUser")
  if (!currentUser) {
    window.location.href = "dashboard.html"
    return
  }

  appState.currentUser = JSON.parse(currentUser)

  // Update user display
  const userName = document.getElementById("userName")
  const userNameDisplay = document.getElementById("userNameDisplay")
  const userAvatar = document.querySelector(".user-avatar")

  if (userName) userName.textContent = appState.currentUser.name
  if (userNameDisplay) userNameDisplay.textContent = appState.currentUser.name
  if (userAvatar && appState?.currentUser?.name)
    userAvatar.textContent = appState.currentUser.name.charAt(0).toUpperCase()

  // Initialize navigation
  initializeNavigation()

  // Initialize forms
  initializeForms()

  // Load and render data
  loadAndRenderData()

  // Update stats
  updateStats()

  // Faculty
  renderPendingVerification() // This now calls the updated function
  // Organizer
  renderOrganizerEvents()
  renderAnnouncements()
  // Admin
  renderAdminUsers()
  renderOrganizerRequests()
  renderModeration()
  updateAdminStats()

  // Ensure Dashboard opens the Overview on load (fixes student opening Settings)
  if (document.getElementById("overview")) {
    navigateToSection("overview")
  }
}

// ===== NAVIGATION =====
function initializeNavigation() {
  const navItems = document.querySelectorAll(".nav-item")
  const sections = document.querySelectorAll(".content-section")
  const menuToggle = document.getElementById("menuToggle")
  const sidebar = document.getElementById("sidebar")
  const sidebarClose = document.getElementById("sidebarClose")

  document.body.classList.add("drawer-mode")

  let backdrop = document.getElementById("drawerBackdrop")
  if (!backdrop) {
    backdrop = document.createElement("div")
    backdrop.id = "drawerBackdrop"
    backdrop.className = "drawer-backdrop"
    document.body.appendChild(backdrop)
  }

  // Remove legacy label injection; keep accessible name
  if (menuToggle) {
    menuToggle.setAttribute("aria-label", "Open menu")
  }

  // Navigation click handlers
  navItems.forEach((item) => {
    item.addEventListener("click", function (e) {
      e.preventDefault()
      const targetSection = this.getAttribute("data-section")
      appState.viewMyUploads = false
      appState.viewMyPurchases = false
      navigateToSection(targetSection)
      // re-render to ensure banners disappear
      loadAndRenderData()
    })
  })

  // Drawer open
  if (menuToggle) {
    menuToggle.addEventListener("click", () => {
      sidebar?.classList.add("active")
      backdrop.classList.add("active")
    })
  }

  // Drawer close
  if (sidebarClose) {
    sidebarClose.addEventListener("click", () => {
      sidebar.classList.remove("active")
      backdrop.classList.remove("active")
    })
  }
  backdrop.addEventListener("click", () => {
    sidebar?.classList.remove("active")
    backdrop.classList.remove("active")
  })

  document.getElementById("linkMyUploads")?.addEventListener("click", (e) => {
    e.preventDefault()
    appState.viewMyUploads = false
    navigateToSection("my-uploads")
    renderMyUploads()
  })
  document.getElementById("linkMyPurchases")?.addEventListener("click", (e) => {
    e.preventDefault()
    appState.viewMyPurchases = false
    navigateToSection("my-purchases")
    renderMyPurchases()
  })
  document.getElementById("linkWishlist")?.addEventListener("click", (e) => {
    e.preventDefault()
    navigateToSection("wishlist")
    renderWishlist()
  })
}

function navigateToSection(sectionId) {
  const page = window.location.pathname.split("/").pop() || ""
  const sid = sectionId

  const navItems = document.querySelectorAll(".nav-item")
  const sections = document.querySelectorAll(".content-section")
  navItems.forEach((item) => item.classList.remove("active"))
  sections.forEach((section) => section.classList.remove("active"))

  const selectedNav = document.querySelector(`[data-section="${sid}"]`)
  const selectedSection = document.getElementById(sid)
  if (selectedNav) selectedNav.classList.add("active")
  if (selectedSection) selectedSection.classList.add("active")

  const sidebar = document.getElementById("sidebar")
  const backdrop = document.getElementById("drawerBackdrop")
  if (sidebar) sidebar.classList.remove("active")
  if (backdrop) backdrop.classList.remove("active")
}

// ===== FORMS INITIALIZATION =====
function initializeForms() {
  // Upload Resource Form
  const uploadResourceForm = document.getElementById("uploadResourceForm")
  if (uploadResourceForm) {
    uploadResourceForm.addEventListener("submit", handleUploadResource)
  }

  // Post Item Form
  const postItemForm = document.getElementById("postItemForm")
  if (postItemForm) {
    postItemForm.addEventListener("submit", handlePostItem)
  }

  // Post Lost/Found Form
  const postLostFoundForm = document.getElementById("postLostFoundForm")
  if (postLostFoundForm) {
    postLostFoundForm.addEventListener("submit", handlePostLostFound)
  }

  // Post Discussion Form
  const postDiscussionForm = document.getElementById("postDiscussionForm")
  if (postDiscussionForm) {
    postDiscussionForm.addEventListener("submit", handlePostDiscussion)
  }

  enhanceNumericField("itemContact")
  enhanceNumericField("lfContact")
  // you can add more IDs here if new contact fields are added later
}

// ===== FORM HANDLERS =====
function handleUploadResource(e) {
  e.preventDefault()
  console.log("[v0] handleUploadResource called, appState.currentUser:", appState.currentUser)

  const fileInput = document.getElementById("resourceFile")
  const file = fileInput?.files?.[0] || null

  const base = {
    id: Date.now(),
    title: document.getElementById("resourceTitle").value,
    subject: document.getElementById("resourceSubject").value,
    description: document.getElementById("resourceDescription").value,
    branch: document.getElementById("resourceBranch")?.value || "",
    semester: document.getElementById("resourceSemester")?.value || "",
    fileName: file?.name || "document.pdf",
    fileUrl: null,
    uploadedBy: appState.currentUser.name,
    uploadedByRole: appState.currentUser.role || "",
    uploadedAt: new Date().toISOString(),
    verified: false,
    downloads: 0,
    upvotes: 0,
    status: "pending",
  }

  console.log("[v0] Resource object created:", base)

  const commit = () => {
    console.log("[v0] Before push - appState.resources length:", appState.resources.length)
    appState.resources.push(base)
    console.log("[v0] After push - appState.resources length:", appState.resources.length)
    appState.lastAdded = { type: "resource", id: base.id }
    console.log("[v0] Calling saveStateToStorage...")
    saveStateToStorage()
    console.log("[v0] After saveStateToStorage, calling renderResources...")
    renderResources()
    renderPendingVerification() // Ensure this is called after state update
    updateStats()
    awardPoints(10, "Resource uploaded")
    toggleModal("uploadResourceModal")
    e.target.reset()
    console.log("[v0] Resource uploaded successfully:", base)
  }

  if (file) {
    const reader = new FileReader()
    reader.onload = () => {
      base.fileUrl = reader.result // DataURL
      commit()
    }
    reader.readAsDataURL(file)
  } else {
    // create a small text placeholder blob so Download still works
    const blob = new Blob([base.title + "\n\n" + (base.description || "No description")], { type: "text/plain" })
    base.fileUrl = URL.createObjectURL(blob)
    commit()
  }
}

function handlePostItem(e) {
  e.preventDefault()
  console.log("[v0] handlePostItem called, appState.currentUser:", appState.currentUser)

  const contactVal = document.getElementById("itemContact").value.trim()
  if (!isDigitsOnly(contactVal)) {
    alert("Please enter digits only in Contact Info.")
    document.getElementById("itemContact").focus()
    return
  }

  const file = document.getElementById("itemImage")?.files?.[0]
  const base = {
    id: Date.now(),
    title: document.getElementById("itemTitle").value,
    price: document.getElementById("itemPrice").value,
    description: document.getElementById("itemDescription").value,
    contact: contactVal,
    postedBy: appState.currentUser.name,
    postedByRole: appState.currentUser.role || "",
    postedAt: new Date().toISOString(),
    sold: false,
    image: null,
    purchasedBy: null, // track buyer
  }

  console.log("[v0] Marketplace item object created:", base)

  const commit = () => {
    console.log("[v0] Before push - appState.marketplaceItems length:", appState.marketplaceItems.length)
    appState.marketplaceItems.push(base)
    console.log("[v0] After push - appState.marketplaceItems length:", appState.marketplaceItems.length)
    appState.lastAdded = { type: "marketplace", id: base.id } //
    console.log("[v0] Calling saveStateToStorage...")
    saveStateToStorage()
    console.log("[v0] After saveStateToStorage, calling renderMarketplace...")
    renderMarketplace()
    awardPoints(5, "Item posted")
    toggleModal("postItemModal")
    e.target.reset()
    console.log("[v0] Marketplace item posted successfully:", base)
  }

  if (file) {
    const reader = new FileReader()
    reader.onload = () => {
      base.image = reader.result
      commit()
    }
    reader.readAsDataURL(file)
  } else {
    commit()
  }
}

function handlePostLostFound(e) {
  e.preventDefault()
  console.log("[v0] handlePostLostFound called, appState.currentUser:", appState.currentUser)

  const contactVal = document.getElementById("lfContact").value.trim()
  if (!isDigitsOnly(contactVal)) {
    alert("Please enter digits only in Contact Info.")
    document.getElementById("lfContact").focus()
    return
  }

  const base = {
    id: Date.now(),
    type: document.getElementById("lfType").value,
    itemName: document.getElementById("lfItemName").value,
    description: document.getElementById("lfDescription").value,
    location: document.getElementById("lfLocation").value,
    contact: contactVal,
    postedBy: appState.currentUser.name,
    postedByRole: appState.currentUser.role || "",
    postedAt: new Date().toISOString(),
    image: null,
  }

  console.log("[v0] Lost/Found item object created:", base)

  const file = document.getElementById("lfImage")?.files?.[0]
  const commit = () => {
    console.log("[v0] Before push - appState.lostFoundItems length:", appState.lostFoundItems.length)
    appState.lostFoundItems.push(base)
    console.log("[v0] After push - appState.lostFoundItems length:", appState.lostFoundItems.length)
    appState.lastAdded = { type: "lostfound", id: base.id } //
    console.log("[v0] Calling saveStateToStorage...")
    saveStateToStorage()
    console.log("[v0] After saveStateToStorage, calling renderLostFound...")
    renderLostFound()
    awardPoints(5, "Lost/Found item posted")
    toggleModal("postLostFoundModal")
    e.target.reset()
    console.log("[v0] Lost/Found item posted successfully:", base)
  }
  if (file) {
    const reader = new FileReader()
    reader.onload = () => {
      base.image = reader.result
      commit()
    }
    reader.readAsDataURL(file)
  } else {
    commit()
  }
}

function handlePostDiscussion(e) {
  e.preventDefault()
  console.log("[v0] handlePostDiscussion called, appState.currentUser:", appState.currentUser)

  const formData = {
    id: Date.now(),
    title: document.getElementById("discussionTitle").value,
    content: document.getElementById("discussionContent").value,
    category: document.getElementById("discussionCategory").value,
    postedBy: appState.currentUser.name,
    postedByRole: appState.currentUser?.role || "",
    postedAt: new Date().toISOString(),
    upvotes: 0,
    downvotes: 0,
    comments: [], // start as array
  }

  console.log("[v0] Discussion object created:", formData)
  console.log("[v0] Before push - appState.discussions length:", appState.discussions.length)
  appState.discussions.push(formData)
  console.log("[v0] After push - appState.discussions length:", appState.discussions.length)
  appState.lastAdded = { type: "discussion", id: formData.id } //
  console.log("[v0] Calling saveStateToStorage...")
  saveStateToStorage()
  console.log("[v0] After saveStateToStorage, calling renderDiscussions...")
  renderDiscussions()
  updateStats()
  awardPoints(15, "Discussion posted")
  toggleModal("postDiscussionModal")
  e.target.reset()
  console.log("[v0] Discussion posted successfully:", formData)
}

function handleCreateEvent() {
  const title = document.getElementById("evTitle").value
  const date = document.getElementById("evDate").value
  const venue = document.getElementById("evVenue").value
  const description = document.getElementById("evDesc").value
  const form = document.getElementById("evForm").value
  const posterFile = document.getElementById("evPoster")?.files?.[0]

  const baseEvent = {
    id: Date.now(),
    title,
    date,
    venue,
    description,
    form,
    organizer: appState.currentUser?.name || "Organizer",
    organizerRole: appState.currentUser?.role || "",
    closed: false, // this is now event.registrationClosed
    registered: false,
    poster: null,
    registrationClosed: false, // Added for clarity, was 'closed'
    closedAt: null, // Added for clarity
  }

  if (posterFile) {
    const reader = new FileReader()
    reader.onload = () => {
      baseEvent.poster = reader.result
      appState.events.push(baseEvent)
      saveStateToStorage()
      afterEventCreate()
    }
    reader.readAsDataURL(posterFile)
  } else {
    appState.events.push(baseEvent)
    saveStateToStorage()
    afterEventCreate()
  }

  function afterEventCreate() {
    renderOrganizerEvents()
    updateAdminStats()
    renderEvents()
    document.getElementById("createEventForm").reset()
    const preview = document.getElementById("posterPreview")
    if (preview) preview.innerHTML = ""
    showNotification("Event created")
  }
}

// =====RENDERING FUNCTIONS =====
function renderResources() {
  const resourcesList = document.getElementById("resourcesList")
  if (!resourcesList) return
  const fb = document.getElementById("filterBranch")?.value || ""
  const fs = document.getElementById("filterSemester")?.value || ""
  const q = (document.getElementById("filterTitle")?.value || "").toLowerCase().trim()
  let arr = appState.resources || []

  let banner = ""
  if (appState.viewMyUploads) {
    arr = arr.filter((r) => (r.uploadedBy || "") === (appState.currentUser?.name || ""))
    banner = `<div class="filter-banner">Showing: My Uploads <button class="chip small" onclick="clearSpecialFilters()">Clear</button></div>`
  }

  if (fb) arr = arr.filter((r) => (r.branch || "").toLowerCase() === fb.toLowerCase())
  if (fs) arr = arr.filter((r) => (r.semester || "").toLowerCase() === fs.toLowerCase())
  if (q) {
    arr = arr.filter((r) => (r.title || "").toLowerCase().includes(q) || (r.subject || "").toLowerCase().includes(q))
  }

  const votes = getUserVotes()
  const wishlist = getUserWishlist()

  if (arr.length === 0) {
    resourcesList.innerHTML = banner + '<div class="empty-state"><p>No resources found.</p></div>'
    return
  }

  const me = appState.currentUser?.name || ""

  resourcesList.innerHTML =
    banner +
    arr
      .map((resource) => {
        const voted = votes.resources?.[resource.id] === "up"
        const saved = wishlist.includes(resource.id)
        const isNew = appState.lastAdded?.type === "resource" && appState.lastAdded.id === resource.id
        const canDelete = (resource.uploadedBy || "") === me || isAdmin()
        return `
        <div class="resource-item" data-resource-id="${resource.id}" ${isNew ? 'data-new="true"' : ""}>
          <div class="resource-info">
            <h3>${resource.title}${resource.verified ? ' <span class="verified-badge">✓ Verified</span>' : ""}</h3>
            <p>${resource.description || "No description"}</p>
            <div class="resource-meta">
              <span>${withIcon("book", " " + (resource.subject || "-"))}</span>
              <span>${withIcon("tag", " " + (resource.branch || "-") + " • " + (resource.semester || "-"))}</span>
              <span>${withIcon("user", " " + (resource.uploadedBy || "-"))}</span>
              <span>${withIcon("calendar", " " + formatDate(resource.uploadedAt))}</span>
            </div>
          </div>
          <div class="resource-actions">
             <!-- wishlist toggle button -->
            <button class="btn btn-secondary btn-small ${saved ? "active" : ""}" aria-pressed="${saved}" title="${
              saved ? "Remove from Wishlist" : "Add to Wishlist"
            }" onclick="toggleWishlist(${resource.id})">🔖 ${saved ? "Saved" : "Wishlist"}</button>
            <button class="btn btn-secondary btn-small ${voted ? "active" : ""}" aria-pressed="${voted}" onclick="upvoteResource(${resource.id})">${withIcon("arrow-up", " " + (resource.upvotes || 0))}</button>
            <button class="btn btn-primary btn-small" onclick="downloadResource(${resource.id})">${withIcon("download", " " + (resource.downloads || 0))}</button>
            ${canDelete ? `<button class="btn btn-secondary btn-small" onclick="deleteResource(${resource.id})">Delete</button>` : ""}
          </div>
        </div>`
      })
      .join("")
  if (appState.lastAdded?.type === "resource") appState.lastAdded = null
}

function renderMarketplace() {
  const marketplaceGrid = document.getElementById("marketplaceGrid")
  if (!marketplaceGrid) return

  if (appState.marketplaceItems.length === 0) {
    marketplaceGrid.innerHTML = '<div class="empty-state"><p>No items listed yet. Post something to sell!</p></div>'
    return
  }

  let arr = appState.marketplaceItems || []

  let banner = ""
  if (appState.viewMyPurchases) {
    const uid = appState.currentUser?.regNumber || ""
    arr = arr.filter((i) => i.purchasedBy === uid)
    banner = `<div class="filter-banner">Showing: My Purchases <button class="chip small" onclick="clearSpecialFilters()">Clear</button></div>`
  }

  marketplaceGrid.innerHTML =
    banner +
    arr
      .map((item) => {
        const isNew = appState.lastAdded?.type === "marketplace" && appState.lastAdded.id === item.id
        const me = appState.currentUser?.name || ""
        const isSeller = item.postedBy === me
        const canDelete = isSeller || isAdmin()
        const canBuy = !isSeller && !item.sold
        const buyBtn = canBuy
          ? `<button class="btn btn-primary btn-small" onclick="buyItem(${item.id})">Buy Now</button>`
          : ""
        const sellerBtns = isSeller
          ? `<div class="btn-group" style="display:flex;gap:.5rem;margin-top:.5rem;">
              <button class="btn btn-secondary btn-small" onclick="toggleSold(${item.id})">${item.sold ? "Mark as Available" : "Mark as Sold"}</button>
            </div>`
          : ""
        const extraDelete = canDelete
          ? `<button class="btn btn-secondary btn-small" style="margin-top:.5rem;" onclick="deleteMarketplaceItem(${item.id})">Delete</button>`
          : ""
        const status =
          item.sold && item.purchasedBy
            ? `<span class="verified-badge" style="background:#d1fae5;color:#065f46">PURCHASED</span>`
            : item.sold
              ? `<span class="verified-badge" style="background:#ffe8e8;color:#8b0000">SOLD</span>`
              : ""
        return `
        <div class="marketplace-item ${item.sold ? "sold" : ""}" data-item-id="${item.id}" ${isNew ? 'data-new="true"' : ""}>
          <div class="item-image">
            ${item.image ? `<img src="${item.image}" alt="Item image" style="width:100%;height:160px;object-fit:cover;border-radius:.5rem"/>` : `<svg width="56" height="56" viewBox="0 0 24 24" fill="none" stroke="#8fb6d9" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 6h15l-1.5 9h-12z"/><circle cx="9" cy="20" r="1.8"/><circle cx="18" cy="20" r="1.8"/><path d="M6 6L5 3H2"/></svg>`}
          </div>
          <div class="item-details">
            <h3>${item.title} ${status}</h3>
            <div class="item-price">₹${item.price}</div>
            <p class="item-description">${item.description || "No description"}</p>
            <p class="item-contact">${withIcon("phone", " " + (item.contact || "-"))}</p>
            <p style="font-size:.75rem;color:var(--text-secondary);margin-top:.5rem;">Posted by ${item.postedBy} • ${formatDate(item.postedAt)}</p>
            ${buyBtn}
            ${sellerBtns}
            ${extraDelete}
          </div>
        </div>`
      })
      .join("")
  if (appState.lastAdded?.type === "marketplace") appState.lastAdded = null
}

function renderEvents() {
  const list = document.getElementById("eventsGrid") || document.getElementById("organizerEvents")
  if (!list) return
  if ((appState.events || []).length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No events yet. Check back later!</p></div>'
    return
  }

  const page = (window.location.pathname.split("/").pop() || "").toLowerCase()
  const isStudentOrFaculty = page.includes("student-dashboard") || page.includes("teacher-dashboard")

  list.innerHTML = appState.events
    .map((e) => {
      const poster = e.poster
        ? `<img src="${e.poster}" alt="Event poster" style="width:100%;height:140px;object-fit:cover;border-radius:.5rem .5rem 0 0"/>`
        : `<img src="/public/images/event-icon.png" alt="Event icon" style="width:64px;height:64px;opacity:.85"/>`

      const controls = isStudentOrFaculty
        ? `<button class="btn btn-primary btn-small" ${e.registrationClosed ? "disabled" : ""} onclick="registerForEvent(${e.id})">${e.registrationClosed ? "Registration Closed" : "Register"}</button>`
        : `<div class="btn-group" style="display:flex;gap:.5rem;">
             <button class="btn btn-secondary btn-small" onclick="closeEventRegistration(${e.id})" ${e.registrationClosed ? "disabled" : ""}>${e.registrationClosed ? "Closed" : "Close Reg"}</button>
             <button class="btn btn-secondary btn-small" onclick="deleteEvent(${e.id})">Delete</button>
           </div>`

      return `
        <div class="event-card" data-event-id="${e.id}">
          <div class="event-poster">${poster}</div>
          <div class="event-content">
            <h3>${e.title}</h3>
            <div class="event-meta">
              <span>${withIcon("calendar", " " + (e.date || "-"))}</span>
              <span>${withIcon("pin", " " + (e.venue || "-"))}</span>
            </div>
            <p class="event-description">${e.description || ""}</p>
            ${controls}
          </div>
        </div>`
    })
    .join("")
}

function renderLostFound() {
  const lostFoundList = document.getElementById("lostFoundList")
  if (!lostFoundList) return
  const activeTab = document.querySelector(".chip.active")?.getAttribute("data-lf-tab") || "all"
  const term = (document.getElementById("lfSearch")?.value || "").toLowerCase().trim()

  let arr = appState.lostFoundItems || []
  if (activeTab !== "all") arr = arr.filter((x) => x.type === activeTab)
  if (term) {
    arr = arr.filter(
      (x) =>
        (x.itemName || "").toLowerCase().includes(term) ||
        (x.location || "").toLowerCase().includes(term) ||
        (x.description || "").toLowerCase().includes(term),
    )
  }

  if (arr.length === 0) {
    lostFoundList.innerHTML = '<div class="empty-state"><p>No lost or found items reported.</p></div>'
    return
  }

  const me = appState.currentUser.name || ""
  lostFoundList.innerHTML = arr
    .map((item) => {
      const isNew = appState.lastAdded?.type === "lostfound" && appState.lastAdded.id === item.id
      const canDelete = (item.postedBy || "") === me || isAdmin()
      return `
        <div class="lost-found-item" data-lf-id="${item.id}" ${isNew ? 'data-new="true"' : ""}>
          ${item.image ? `<img class="lf-image" src="${item.image}" alt="Item image">` : `<div class="lf-image" aria-hidden="true"></div>`}
          <div class="lf-content">
            <span class="lf-type ${item.type}">${item.type.toUpperCase()}</span>
            <h3>${item.itemName}</h3>
            <p>${item.description || ""}</p>
            <div class="lf-meta">
              <span>${withIcon("map-pin", " " + (item.location || "-"))}</span>
              <span>${withIcon("phone", " " + (item.contact || "-"))}</span>
              <span>${withIcon("user", " " + (item.postedBy || "-"))}</span>
              <span>${withIcon("calendar", " " + formatDate(item.postedAt))}</span>
            </div>
            ${canDelete ? `<div class="lf-actions" style="margin-top:.5rem;"><button class="btn btn-secondary btn-small" onclick="deleteLostFound(${item.id})">Delete</button></div>` : ""}
          </div>
        </div>
      `
    })
    .join("")
  if (appState.lastAdded?.type === "lostfound") appState.lastAdded = null
}

function renderDiscussions() {
  const discussionsList = document.getElementById("discussionsList")
  if (!discussionsList) return
  const filterEl = document.getElementById("discussionsFilter")
  const filterVal = (filterEl?.value || "").toLowerCase()

  let arr = appState.discussions || []
  if (filterVal) arr = arr.filter((d) => (d.category || "").toLowerCase() === filterVal)

  const announcements = (appState.notifications || []).map((ann) => ({
    ...ann,
    id: "ann-" + ann.id,
    title: ann.title || "Announcement",
    content: ann.text,
    category: "events",
    postedBy: ann.postedBy || "Organizer",
    postedAt: ann.postedAt,
    isAnnouncement: true,
    upvotes: ann.upvotes || 0,
    downvotes: ann.downvotes || 0,
    comments: ann.comments || [],
  }))

  // Include announcements regardless of filter
  arr = [...announcements, ...arr]

  if (arr.length === 0) {
    discussionsList.innerHTML = '<div class="empty-state"><p>No discussions yet. Start a conversation!</p></div>'
    return
  }
  const votes = getUserVotes()
  discussionsList.innerHTML = arr
    .map((d) => {
      const myVote = votes.discussions?.[d.id]
      const isNew = appState.lastAdded?.type === "discussion" && appState.lastAdded.id === d.id
      const comments = (d.comments || [])
        .map(
          (c) =>
            `<div class="comment"><strong>${c.by}:</strong> ${c.text} <small style="opacity:.8">• ${formatDate(c.at)}</small></div>`,
        )
        .join("")
      const replyCount = (d.comments || []).length
      const canDelete = (appState.currentUser?.name || "") === (d.postedBy || "")
      const announcementBadge = d.isAnnouncement
        ? '<span style="background:#ff9800;color:white;padding:2px 8px;border-radius:4px;font-size:12px;margin-left:8px;">📢 Announcement</span>'
        : ""
      return `
        <div class="discussion-item" data-discussion-id="${d.id}" ${isNew ? 'data-new="true"' : ""} ${d.isAnnouncement ? 'style="border-left:4px solid #ff9800;"' : ""}>
          <div class="discussion-header">
            <h3>${d.title}${announcementBadge}</h3>
            <span class="discussion-category">${d.category}</span>
          </div>
          <p class="discussion-content">${d.content}</p>
          <div class="discussion-footer">
            <span>Posted by ${d.postedBy} • ${formatDate(d.postedAt)}</span>
            <div class="discussion-actions">
              <button class="btn btn-secondary btn-small ${myVote === "up" ? "active" : ""}" onclick="upvoteDiscussion('${d.id}')">${withIcon("arrow-up", " " + (d.upvotes || 0))}</button>
              <button class="btn btn-secondary btn-small ${myVote === "down" ? "active" : ""}" onclick="downvoteDiscussion('${d.id}')">👎 ${d.downvotes || 0}</button>
              <button class="btn btn-secondary btn-small" onclick="toggleReplies('${d.id}')" id="toggleRepliesBtn-${d.id}">View replies (${replyCount})</button>
              ${canDelete ? `<button class="btn btn-secondary btn-small" onclick="deleteDiscussion('${d.id}')">Delete</button>` : ""}
            </div>
          </div>
          <div class="comments-list collapsed" id="comments-${d.id}">
            ${comments || '<div class="comment" style="opacity:.8">No replies yet. Be the first to comment.</div>'}
            <div class="form-group" style="display:flex;gap:.5rem;align-items:center;">
              <input id="commentInput-${d.id}" type="text" placeholder="Write a reply..." />
              <button class="btn btn-primary btn-small" onclick="addComment('${d.id}')">Reply</button>
            </div>
          </div>
        </div>`
    })
    .join("")
  if (appState.lastAdded?.type === "discussion") appState.lastAdded = null
}

function renderOrganizerEvents() {
  const list = document.getElementById("organizerEventsList")
  if (!list) return
  if ((appState.events || []).length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No events yet. Create one!</p></div>'
    return
  }
  const me = appState.currentUser?.name || ""
  list.innerHTML = (appState.events || [])
    .map(
      (e) => `
      <div class="event-card" data-event-id="${e.id}">
        <div class="event-poster">
          ${
            e.poster
              ? `<img src="${e.poster}" alt="Event poster" style="width:100%;height:140px;object-fit:cover;border-radius:.5rem .5rem 0 0"/>`
              : `<img src="/public/images/event-icon.png" alt="Event icon" style="width:64px;height:64px;opacity:.8"/>`
          }
        </div>
        <div class="event-content">
          <h3>${e.title}</h3>
          <div class="event-meta"><span>${withIcon("calendar", " " + (e.date || "-"))}</span><span>${withIcon("pin", " " + (e.venue || "-"))}</span></div>
          <p class="event-description">${e.description || ""}</p>
          ${
            (e.organizer || "") === me
              ? `<div class="btn-group" style="display:flex;gap:.5rem;">
                   <button class="btn btn-secondary btn-small" onclick="closeEventRegistration(${e.id})" ${e.registrationClosed ? "disabled" : ""}>${e.registrationClosed ? "Registration Closed" : "Close Reg"}</button>
                   <button class="btn btn-secondary btn-small" onclick="deleteEvent(${e.id})">Delete</button>
                 </div>`
              : ""
          }
        </div>
      </div>`,
    )
    .join("")
  document.getElementById("orgEventCount") &&
    (document.getElementById("orgEventCount").textContent = appState.events.length)
}

function renderAnnouncements() {
  const list = document.getElementById("announcementsList")
  if (!list) return
  const arr = appState.notifications || []
  if (arr.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No announcements yet.</p></div>'
    return
  }
  const me = appState.currentUser?.name || ""
  list.innerHTML = arr
    .map(
      (n) => `
      <div class="discussion-item">
        <div class="discussion-header"><h3>Announcement</h3><span class="discussion-category">events</span></div>
        <p class="discussion-content">${n.text}</p>
        <div class="discussion-footer">
          <span>By ${n.by} • ${formatDate(n.at)}</span>
          ${me === n.by ? `<div class="discussion-actions"><button class="btn btn-secondary btn-small" onclick="deleteAnnouncement(${n.id})">Delete</button></div>` : ""}
        </div>
      </div>`,
    )
    .join("")
}

function renderAdminUsers() {
  const list = document.getElementById("adminUsersList")
  if (!list) return
  const users = appState.users || []
  const q = (document.getElementById("adminUserSearch")?.value || "").toLowerCase().trim()
  const role = (document.getElementById("adminUserRoleFilter")?.value || "").toLowerCase().trim()

  let filtered = users
  if (q) filtered = filtered.filter((u) => u.name.toLowerCase().includes(q) || (u.reg || "").toLowerCase().includes(q))
  if (role) filtered = filtered.filter((u) => (u.role || "").toLowerCase() === role)

  if (filtered.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No users match filters.</p></div>'
    return
  }
  list.innerHTML = filtered
    .map(
      (u) => `
      <div class="resource-item">
        <div class="resource-info">
          <h3>${u.name} ${u.banned ? '<span class="verified-badge" style="background:#ffd1d1;color:#b10000">BANNED</span>' : ""}</h3>
          <div class="resource-meta">
            <span>${withIcon("id-badge", " " + (u.role || "-"))}</span>
            <span>${withIcon("user", " " + (u.reg || "-"))}</span>
          </div>
        </div>
        <div class="resource-actions">
          <!-- Added change password button for admin to change any user's password -->
          <button class="btn btn-primary btn-small" onclick="changeUserPassword(${u.id})">Change Password</button>
          <button class="btn btn-secondary btn-small" onclick="toggleBan(${u.id})">${u.banned ? "Unban" : "Ban"}</button>
          <button class="btn btn-secondary btn-small" onclick="deleteUser(${u.id})">Delete</button>
        </div>
      </div>`,
    )
    .join("")
}

function renderOrganizerRequests() {
  const list = document.getElementById("organizerRequestsList")
  if (!list) return

  const requests = appState.organizerRequests || []
  if (requests.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>No pending organizer requests.</p></div>'
    return
  }

  list.innerHTML = requests
    .map(
      (req) => `
    <div class="resource-item">
      <div class="resource-info">
        <h3>${req.name}</h3>
        <div class="resource-meta">
          <span>${withIcon("user", " " + req.by)}</span>
          <span>${withIcon("mail", " " + req.email)}</span>
        </div>
      </div>
      <div class="resource-actions">
        <button class="btn btn-primary btn-small" onclick="approveOrganizer(${req.id})">Approve</button>
        <button class="btn btn-danger btn-small" onclick="rejectOrganizer(${req.id})">Reject</button>
      </div>
    </div>
  `,
    )
    .join("")
}

function updateModerationSections() {
  const roleFilter = (document.getElementById("modRoleFilter")?.value || "").toLowerCase()
  const sectionSelect = document.getElementById("modSectionFilter")

  if (!sectionSelect) return

  // Define sections available for each role
  const sectionsByRole = {
    student: ["resources", "lostfound", "marketplace", "community"],
    teacher: ["resources", "community"],
    organizer: ["events", "announcements"],
  }

  // Get available sections for selected role
  const availableSections = sectionsByRole[roleFilter] || []

  // Store current selection
  const currentValue = sectionSelect.value

  // Clear and rebuild options
  sectionSelect.innerHTML = '<option value="">All</option>'

  availableSections.forEach((section) => {
    const label =
      section === "lostfound"
        ? "Lost & Found"
        : section === "marketplace"
          ? "Marketplace"
          : section.charAt(0).toUpperCase() + section.slice(1)
    const option = document.createElement("option")
    option.value = section
    option.textContent = label
    sectionSelect.appendChild(option)
  })

  // Reset to "All" if previous selection is not available
  if (!availableSections.includes(currentValue)) {
    sectionSelect.value = ""
  }
}

function renderModeration() {
  const resList = document.getElementById("moderateResourcesList")
  const evList = document.getElementById("moderateEventsList")
  const annList = document.getElementById("moderateAnnouncementsList")
  const lfList = document.getElementById("moderateLostFoundList")
  const mpList = document.getElementById("moderateMarketplaceList")
  const comList = document.getElementById("moderateCommunityList")

  const roleFilter = (document.getElementById("modRoleFilter")?.value || "").toLowerCase()
  const sectionFilter = (document.getElementById("modSectionFilter")?.value || "").toLowerCase()

  // Only show when BOTH filters are selected
  const ready = !!roleFilter && !!sectionFilter

  // Toggle section visibility
  document.querySelectorAll("[data-mod-section]").forEach((wrap) => {
    const key = wrap.getAttribute("data-mod-section")
    wrap.classList.toggle("hidden", !ready || key !== sectionFilter)
  })

  // If not ready, update placeholders and bail
  if (!ready) {
    const placeholder = '<div class="empty-state"><p>Select a role and section to view items.</p></div>'
    if (resList) resList.innerHTML = placeholder
    if (evList) evList.innerHTML = placeholder
    if (annList) annList.innerHTML = placeholder
    if (lfList) lfList.innerHTML = placeholder
    if (mpList) mpList.innerHTML = placeholder
    if (comList) comList.innerHTML = placeholder
    return
  }

  const me = appState.currentUser?.name || ""

  if (resList && sectionFilter === "resources") {
    let arr = appState.resources || []
    if (roleFilter) arr = arr.filter((r) => (r.uploadedByRole || "").toLowerCase() === roleFilter)
    resList.innerHTML =
      arr.length === 0
        ? '<div class="empty-state"><p>No resources.</p></div>'
        : arr
            .map(
              (r) => `
          <div class="resource-item">
            <div class="resource-info">
              <h3>${r.title} ${r.verified ? '<span class="verified-badge">✓ Verified</span>' : ""}</h3>
              <div class="resource-meta">
                <span>${withIcon("book", " " + (r.subject || "-"))}</span>
                <span>${withIcon("branch", " " + (r.branch || "-"))}</span>
                <span>${withIcon("semester", " " + (r.semester || "-"))}</span>
                <span>${withIcon("user", " " + (r.uploadedBy || "-"))}</span>
              </div>
            </div>
            <div class="resource-actions">
              ${(r.uploadedBy || "") === me || isAdmin() ? `<button class="btn btn-secondary btn-small" onclick="deleteResource(${r.id})">Delete</button>` : ""}
            </div>
          </div>`,
            )
            .join("")
  }

  if (evList && sectionFilter === "events") {
    let arrE = appState.events || []
    if (roleFilter) arrE = arrE.filter((e) => (e.organizerRole || "").toLowerCase() === roleFilter)
    evList.innerHTML =
      arrE.length === 0
        ? '<div class="empty-state"><p>No events.</p></div>'
        : arrE
            .map(
              (e) => `
          <div class="event-card">
            <div class="event-content">
              <h3>${e.title}</h3>
              <div class="event-meta">
                <span>${withIcon("calendar", " " + (e.date || "-"))}</span>
                <span>${withIcon("pin", " " + (e.venue || "-"))}</span>
              </div>
              <div class="btn-group" style="display:flex;gap:.5rem;">
                ${(e.organizer || "") === me || isAdmin() ? `<button class="btn btn-secondary btn-small" onclick="deleteEvent(${e.id})">Delete</button>` : ""}
              </div>
            </div>
          </div>`,
            )
            .join("")
  }

  if (annList && sectionFilter === "announcements") {
    let arrAnn = appState.notifications || []
    if (roleFilter) arrAnn = arrAnn.filter((ann) => (ann.byRole || "").toLowerCase() === roleFilter)
    annList.innerHTML =
      arrAnn.length === 0
        ? '<div class="empty-state"><p>No announcements.</p></div>'
        : arrAnn
            .map(
              (ann) => `
          <div class="resource-item">
            <div class="resource-info">
              <h3>Announcement</h3>
              <p>${ann.text || ""}</p>
              <div class="resource-meta">
                <span>${withIcon("user", " " + (ann.by || "-"))}</span>
                <span>${withIcon("calendar", " " + formatDate(ann.at))}</span>
              </div>
            </div>
            <div class="resource-actions">
              ${(ann.by || "") === me || isAdmin() ? `<button class="btn btn-secondary btn-small" onclick="deleteAnnouncement(${ann.id})">Delete</button>` : ""}
            </div>
          </div>`,
            )
            .join("")
  }

  if (lfList && sectionFilter === "lostfound") {
    let arrLF = appState.lostFoundItems || []
    if (roleFilter) arrLF = arrLF.filter((i) => (i.postedByRole || "").toLowerCase() === roleFilter)
    lfList.innerHTML =
      arrLF.length === 0
        ? '<div class="empty-state"><p>No lost or found items.</p></div>'
        : arrLF
            .map(
              (item) => `
          <div class="lost-found-item">
            <h3>${item.itemName} <span class="lf-type ${item.type}">${item.type}</span></h3>
            <p>${item.description || ""}</p>
            <p>${withIcon("pin", " " + (item.location || "-"))}</p>
            ${item.image ? `<img src="${item.image}" alt="Item image" style="max-height:120px;border-radius:8px;margin-top:.5rem;" />` : ""}
            <div class="lf-actions" style="margin-top:.5rem;">
              ${isAdmin() || (item.postedBy || "") === me ? `<button class="btn btn-secondary btn-small" onclick="deleteLostFound(${item.id})">Delete</button>` : ""}
            </div>
          </div>`,
            )
            .join("")
  }

  if (mpList && sectionFilter === "marketplace") {
    let arrMP = appState.marketplaceItems || []
    if (roleFilter) arrMP = arrMP.filter((m) => (m.postedByRole || "").toLowerCase() === roleFilter)
    mpList.innerHTML =
      arrMP.length === 0
        ? '<div class="empty-state"><p>No marketplace items.</p></div>'
        : arrMP
            .map(
              (item) => `
          <div class="resource-item">
            <div class="resource-info">
              <h3>${item.title}</h3>
              <p>${item.description || ""}</p>
              <div class="resource-meta">
                <span>${withIcon("user", " " + (item.postedBy || "-"))}</span>
              </div>
            </div>
            <div class="resource-actions">
              ${isAdmin() || (item.postedBy || "") === me ? `<button class="btn btn-secondary btn-small" onclick="deleteMarketplaceItem(${item.id})">Delete</button>` : ""}
            </div>
          </div>`,
            )
            .join("")
  }

  if (comList && sectionFilter === "community") {
    let arrC = appState.discussions || []
    arrC = arrC.filter((d) => d.category !== "announcements")
    if (roleFilter) arrC = arrC.filter((d) => (d.postedByRole || "").toLowerCase() === roleFilter)
    comList.innerHTML =
      arrC.length === 0
        ? '<div class="empty-state"><p>No community posts.</p></div>'
        : arrC
            .map(
              (post) => `
          <div class="resource-item">
            <div class="resource-info">
              <h3>${post.title}</h3>
              <p>${post.content || ""}</p>
              <div class="resource-meta">
                <span>${withIcon("user", " " + (post.postedBy || "-"))}</span>
              </div>
            </div>
            <div class="resource-actions">
              ${(post.postedBy || "") === me || isAdmin() ? `<button class="btn btn-secondary btn-small" onclick="deleteDiscussion(${post.id})">Delete</button>` : ""}
            </div>
          </div>`,
            )
            .join("")
  }
}

// THIS IS THE UPDATED renderPendingVerification FUNCTION
function renderPendingVerification() {
  const host = document.getElementById("pendingVerifyList")
  if (!host) return

  let arr = (appState.resources || []).filter((r) => r.status === "pending")

  // Apply search filter
  const searchInput = document.getElementById("verifySearch")
  if (searchInput && searchInput.value.trim()) {
    const query = searchInput.value.toLowerCase()
    arr = arr.filter(
      (r) => r.title.toLowerCase().includes(query) || (r.subject && r.subject.toLowerCase().includes(query)),
    )
  }

  // Apply semester filter
  const semesterSelect = document.getElementById("verifySemester")
  if (semesterSelect && semesterSelect.value) {
    arr = arr.filter((r) => r.semester === semesterSelect.value)
  }

  // Apply branch filter
  const branchSelect = document.getElementById("verifyBranch")
  if (branchSelect && branchSelect.value) {
    arr = arr.filter((r) => r.branch === branchSelect.value)
  }

  if (arr.length === 0) {
    host.innerHTML = '<div class="empty-state"><p>No pending notes to verify.</p></div>'
    return
  }

  host.innerHTML = arr
    .map(
      (r) => `
      <div class="resource-item">
        <div class="resource-info">
          <h3>${r.title}</h3>
          <p>${r.description || ""}</p>
          <small>${r.subject || ""} • ${r.branch || ""} • ${r.semester || ""}</small>
        </div>
        <div class="resource-actions">
          <button class="btn btn-primary btn-small" onclick="verifyResource(${r.id})">Verify</button>
        </div>
      </div>`,
    )
    .join("")
}

function renderMyUploads() {
  const host = document.getElementById("myUploadsList")
  if (!host) return
  const yearSel = document.getElementById("myYearFilter")?.value || ""
  const semSel = document.getElementById("mySemFilter")?.value || ""
  const uName = appState.currentUser?.name || ""

  const toYear = (sem) => {
    const n = String(sem || "")
      .trim()
      .split("-")[0]
    const m = Number.parseInt(n, 10)
    return Number.isFinite(m) ? String(m) : ""
  }

  let arr = (appState.resources || []).filter((r) => (r.uploadedBy || "") === uName)
  if (yearSel) arr = arr.filter((r) => toYear(r.semester) === yearSel)
  if (semSel) arr = arr.filter((r) => (r.semester || "").toLowerCase() === semSel.toLowerCase())

  if (arr.length === 0) {
    host.innerHTML = '<div class="empty-state"><p>No uploads yet. Share your first note!</p></div>'
    return
  }

  const votes = getUserVotes()

  host.innerHTML = arr
    .map((r) => {
      const voted = votes.resources?.[r.id] === "up"
      const canDelete = true /* my uploads */ || isAdmin()
      return `
        <div class="resource-item" data-resource-id="${r.id}">
          <div class="resource-info">
            <h3>${r.title} ${r.verified ? '<span class="verified-badge">✓ Verified</span>' : ""}</h3>
            <p>${r.description || ""}</p>
            <div class="resource-meta">
              <span>${withIcon("book", " " + (r.subject || "-"))}</span>
              <span>${withIcon("semester", " " + (r.semester || "-"))}</span>
              <span>${withIcon("calendar", " " + formatDate(r.uploadedAt))}</span>
            </div>
          </div>
          <div class="resource-actions">
            <button class="btn btn-secondary btn-small ${voted ? "active" : ""}" aria-pressed="${voted}" onclick="upvoteResource(${r.id})">${withIcon("arrow-up", " " + (r.upvotes || 0))}</button>
            <button class="btn btn-primary btn-small" onclick="downloadResource(${r.id})">${withIcon("download", " " + (r.downloads || 0))}</button>
            ${canDelete ? `<button class="btn btn-secondary btn-small" onclick="deleteResource(${r.id})">Delete</button>` : ""}
          </div>
        </div>`
    })
    .join("")
}

function renderMyPurchases() {
  const host = document.getElementById("myPurchasesGrid")
  if (!host) return
  const uid = appState.currentUser?.regNumber || ""
  const arr = (appState.marketplaceItems || []).filter((i) => i.purchasedBy === uid)
  if (arr.length === 0) {
    host.innerHTML = '<div class="empty-state"><p>No purchases yet.</p></div>'
    return
  }
  host.innerHTML = arr
    .map(
      (i) => `
      <div class="marketplace-item sold" data-item-id="${i.id}">
        <div class="item-image">
          ${
            i.image
              ? `<img src="${i.image}" alt="Purchased item" style="width:100%;height:160px;object-fit:cover;border-radius:.5rem"/>`
              : ""
          }
        </div>
        <div class="item-details">
          <h3>${i.title} <span class="verified-badge" style="background:#d1fae5;color:#065f46">PURCHASED</span></h3>
          <div class="item-price">₹${i.price}</div>
          <p class="item-description">${i.description || ""}</p>
          <p class="item-contact">Contact: ${i.contact}</p>
          <p style="font-size:.75rem;color:var(--text-secondary);margin-top:.5rem;">From ${i.postedBy} • ${formatDate(i.postedAt)}</p>
        </div>
      </div>`,
    )
    .join("")
}

// ===== ACTION FUNCTIONS =====
function downloadResource(resourceId) {
  const resource = appState.resources.find((r) => r.id === resourceId)
  if (!resource) return

  // ensure a downloadable URL exists; if not, make a fallback blob
  let url = resource.fileUrl
  if (!url) {
    const blob = new Blob([resource.title + "\n\n" + (resource.description || "No description")], {
      type: "text/plain",
    })
    url = URL.createObjectURL(blob)
    resource.fileUrl = url
  }

  resource.downloads = (resource.downloads || 0) + 1
  saveStateToStorage()
  renderResources()
  renderWishlist()

  const link = document.createElement("a")
  link.href = url
  link.download = resource.fileName || "resource"
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  console.log("[v0] Downloading resource:", resource)
}

function registerForEvent(eventId) {
  const event = appState.events.find((e) => e.id === eventId)
  if (!event) return

  if (event.form && typeof event.form === "string") {
    try {
      const url = event.form.startsWith("http") ? event.form : "https://" + event.form
      window.open(url, "_blank", "noopener")
    } catch {}
  }

  event.registered = true // this field isn't used anywhere, potentially remove
  saveStateToStorage()
  renderEvents()
  updateStats()
  showNotification("Event registration opened")
}

function getUserId() {
  return appState?.currentUser?.regNumber || "anon"
}
function getUserVotes() {
  const key = "votes_" + getUserId()
  try {
    return JSON.parse(localStorage.getItem(key)) || { discussions: {}, resources: {} }
  } catch {
    return { discussions: {}, resources: {} }
  }
}
function setUserVotes(v) {
  const key = "votes_" + getUserId()
  localStorage.setItem(key, JSON.stringify(v))
}

function likeDiscussion(discussionId) {
  const discussion = appState.discussions.find((d) => d.id === discussionId)
  if (discussion) {
    discussion.likes++
    saveStateToStorage()
    renderDiscussions()

    console.log("[v0] Liked discussion:", discussion)
  }
}

// Replaced duplicate verifyResource function with the one from the updates.
function verifyResource(id) {
  const r = (appState.resources || []).find((x) => x.id === id)
  if (r) {
    r.verified = true
    r.status = "verified" // Update status to verified
    saveStateToStorage()
    renderResources()
    renderPendingVerification()
    showNotification("Note verified successfully!")
  }
}

function approveResource(id) {
  console.log("[v0] Approving resource with id:", id)
  const r = (appState.resources || []).find((x) => x.id === id)
  if (r) {
    console.log("[v0] Found resource:", r)
    r.verified = true
    r.status = "verified" // Update status to verified
    saveStateToStorage()
    renderResources()
    renderPendingVerification()
    showNotification("Note approved and verified!")
    console.log("[v0] Resource approved successfully")
  } else {
    console.log("[v0] Resource not found with id:", id)
  }
}

function rejectResource(id) {
  console.log("[v0] Rejecting resource with id:", id)
  const r = (appState.resources || []).find((x) => x.id === id)
  if (r) {
    r.status = "rejected" // Update status to rejected
    saveStateToStorage()
    renderResources()
    renderPendingVerification()
    showNotification("Note rejected!")
    console.log("[v0] Resource rejected successfully")
  } else {
    console.log("[v0] Resource not found with id:", id)
  }
}

function deleteResource(id) {
  const idx = (appState.resources || []).findIndex((r) => r.id === id)
  if (idx >= 0) {
    appState.resources.splice(idx, 1)
    saveStateToStorage()
    renderResources()
    renderPendingVerification()
    renderMyUploads?.()
    renderWishlist?.()
    updateStats()
  }
}

function upvoteResource(id) {
  const res = (appState.resources || []).find((r) => r.id === id)
  if (!res) return
  const votes = getUserVotes()
  const current = votes.resources?.[id]
  votes.resources = votes.resources || {}
  if (current === "up") {
    delete votes.resources[id]
    res.upvotes = Math.max(0, (res.upvotes || 0) - 1)
  } else {
    votes.resources[id] = "up"
    res.upvotes = (res.upvotes || 0) + 1
  }
  setUserVotes(votes)
  saveStateToStorage()
  renderResources()
  renderMyUploads?.()
}

function deleteEvent(id) {
  const idx = (appState.events || []).findIndex((e) => e.id === id)
  if (idx >= 0) {
    appState.events.splice(idx, 1)
    saveStateToStorage()
    renderEvents()
    renderOrganizerEvents()
    updateAdminStats()
    updateStats()
  }
}

function toggleEventClosed(id) {
  const ev = (appState.events || []).find((e) => e.id === id)
  if (!ev) return
  ev.closed = !ev.closed // This is likely intended for event.registrationClosed
  saveStateToStorage()
  renderEvents()
  renderOrganizerEvents()
}

function closeEventRegistration(eventId) {
  console.log("[v0] Closing registration for event:", eventId)
  const event = appState.events?.find((e) => e.id === eventId)
  if (!event) {
    console.log("[v0] Event not found with id:", eventId)
    return
  }

  event.registrationClosed = true
  event.closedAt = new Date().toISOString()

  saveStateToStorage()
  renderOrganizerEvents()
  showNotification("Event registration closed successfully!")
  console.log("[v0] Event registration closed:", event)
}

function deleteLostFound(id) {
  const idx = (appState.lostFoundItems || []).findIndex((x) => x.id === id)
  if (idx >= 0) {
    appState.lostFoundItems.splice(idx, 1)
    saveStateToStorage()
    renderLostFound()
    renderModeration()
    updateStats()
  }
}

function upvoteDiscussion(id) {
  // Handle both numeric and string IDs (for announcements)
  const d = (appState.discussions || []).find((x) => x.id === id || x.id === Number.parseInt(id))

  // If not found in discussions, check announcements
  if (!d && typeof id === "string" && id.startsWith("ann-")) {
    const annId = Number.parseInt(id.substring(4))
    const ann = (appState.notifications || []).find((x) => x.id === annId)
    if (ann) {
      ann.upvotes = ann.upvotes || 0
      ann.downvotes = ann.downvotes || 0
      const votes = getUserVotes()
      votes.discussions = votes.discussions || {}
      const cur = votes.discussions[id]
      if (cur === "up") {
        delete votes.discussions[id]
        ann.upvotes = Math.max(0, ann.upvotes - 1)
      } else {
        votes.discussions[id] = "up"
        ann.upvotes = ann.upvotes + 1
        if (cur === "down") ann.downvotes = Math.max(0, ann.downvotes - 1)
      }
      setUserVotes(votes)
      saveStateToStorage()
      renderDiscussions()
      return
    }
  }

  if (!d) return
  const votes = getUserVotes()
  votes.discussions = votes.discussions || {}
  const cur = votes.discussions[id]
  if (cur === "up") {
    delete votes.discussions[id]
    d.upvotes = Math.max(0, (d.upvotes || 0) - 1)
  } else {
    votes.discussions[id] = "up"
    d.upvotes = (d.upvotes || 0) + 1
    if (cur === "down") d.downvotes = Math.max(0, (d.downvotes || 0) - 1)
  }
  setUserVotes(votes)
  saveStateToStorage()
  renderDiscussions()
  renderModeration()
}

function downvoteDiscussion(id) {
  // Handle both numeric and string IDs (for announcements)
  const d = (appState.discussions || []).find((x) => x.id === id || x.id === Number.parseInt(id))

  // If not found in discussions, check announcements
  if (!d && typeof id === "string" && id.startsWith("ann-")) {
    const annId = Number.parseInt(id.substring(4))
    const ann = (appState.notifications || []).find((x) => x.id === annId)
    if (ann) {
      ann.upvotes = ann.upvotes || 0
      ann.downvotes = ann.downvotes || 0
      const votes = getUserVotes()
      votes.discussions = votes.discussions || {}
      const cur = votes.discussions[id]
      if (cur === "down") {
        delete votes.discussions[id]
        ann.downvotes = Math.max(0, ann.downvotes - 1)
      } else {
        votes.discussions[id] = "down"
        ann.downvotes = ann.downvotes + 1
        if (cur === "up") ann.upvotes = Math.max(0, ann.upvotes - 1)
      }
      setUserVotes(votes)
      saveStateToStorage()
      renderDiscussions()
      return
    }
  }

  if (!d) return
  const votes = getUserVotes()
  votes.discussions = votes.discussions || {}
  const cur = votes.discussions[id]
  if (cur === "down") {
    delete votes.discussions[id]
    d.downvotes = Math.max(0, (d.downvotes || 0) - 1)
  } else {
    votes.discussions[id] = "down"
    d.downvotes = (d.downvotes || 0) + 1
    if (cur === "up") d.upvotes = Math.max(0, (d.upvotes || 0) - 1)
  }
  setUserVotes(votes)
  saveStateToStorage()
  renderDiscussions()
  renderModeration()
}

function addComment(id) {
  const input = document.getElementById(`commentInput-${id}`)
  if (!input?.value) return

  // Handle both numeric and string IDs (for announcements)
  const d = (appState.discussions || []).find((x) => x.id === id || x.id === Number.parseInt(id))

  // If not found in discussions, check announcements
  if (!d && typeof id === "string" && id.startsWith("ann-")) {
    const annId = Number.parseInt(id.substring(4))
    const ann = (appState.notifications || []).find((x) => x.id === annId)
    if (ann) {
      ann.comments = ann.comments || []
      ann.comments.push({ by: appState.currentUser?.name || "User", text: input.value, at: new Date().toISOString() })
      input.value = ""
      saveStateToStorage()
      renderDiscussions()
      return
    }
  }

  if (!d) return
  d.comments = d.comments || []
  d.comments.push({ by: appState.currentUser?.name || "User", text: input.value, at: new Date().toISOString() })
  input.value = ""
  saveStateToStorage()
  renderDiscussions()
}

function toggleReplies(id) {
  const wrap = document.getElementById(`comments-${id}`)
  const btn = document.getElementById(`toggleRepliesBtn-${id}`)
  if (!wrap) return
  wrap.classList.toggle("collapsed")
  if (btn) btn.textContent = wrap.classList.contains("collapsed") ? "View replies" : "Hide replies"
}

function deleteDiscussion(id) {
  const idx = (appState.discussions || []).findIndex((d) => d.id === id)
  if (idx >= 0) {
    appState.discussions.splice(idx, 1)
    saveStateToStorage()
    renderDiscussions()
    renderModeration()
    updateAdminStats()
  }
}

function approveOrganizer(id) {
  const req = (appState.organizerRequests || []).find((r) => r.id === id)
  if (!req) return
  // In a real app you would create a user here. We only remove request and notify.
  appState.organizerRequests = (appState.organizerRequests || []).filter((r) => r.id !== id)
  showNotification("Organizer approved")
  saveStateToStorage()
  renderOrganizerRequests()
}

function rejectOrganizer(id) {
  appState.organizerRequests = (appState.organizerRequests || []).filter((r) => r.id !== id)
  showNotification("Request rejected")
  saveStateToStorage()
  renderOrganizerRequests()
}

function toggleBan(userId) {
  const u = (appState.users || []).find((x) => x.id === userId)
  if (!u) return
  u.banned = !u.banned
  saveStateToStorage()
  renderAdminUsers()
}

function deleteUser(userId) {
  appState.users = (appState.users || []).filter((u) => u.id !== userId)
  saveStateToStorage()
  renderAdminUsers()
  updateAdminStats()
}

function buyItem(itemId) {
  const item = (appState.marketplaceItems || []).find((i) => i.id === itemId)
  if (!item || item.sold) return
  item.sold = true
  item.purchasedBy = appState.currentUser?.regNumber || ""
  saveStateToStorage()
  renderMarketplace()
}

function toggleSold(itemId) {
  const item = (appState.marketplaceItems || []).find((i) => i.id === itemId)
  if (!item) return
  item.sold = !item.sold
  if (!item.sold) item.purchasedBy = null
  saveStateToStorage()
  renderMarketplace()
}

function deleteMarketplaceItem(itemId) {
  appState.marketplaceItems = (appState.marketplaceItems || []).filter((i) => i.id !== itemId)
  saveStateToStorage()
  renderMarketplace()
  renderModeration()
  updateStats()
}

function postAnnouncement() {
  const textEl = document.getElementById("annText")
  const text = textEl?.value?.trim()
  if (!text) return
  appState.notifications = appState.notifications || []
  appState.notifications.push({
    id: Date.now(),
    text,
    by: appState.currentUser?.name || "Organizer",
    at: new Date().toISOString(),
  })
  textEl.value = ""
  saveStateToStorage()
  renderAnnouncements()
  showNotification("Announcement posted")
}

function deleteAnnouncement(id) {
  appState.notifications = (appState.notifications || []).filter((n) => n.id !== id)
  saveStateToStorage()
  renderAnnouncements()
  renderModeration()
  updateAdminStats()
}

function enhanceDrawerAndProfile() {
  // already wired in initializeNavigation(); keep as no-op placeholder for compatibility
}

function roleSpecificCleanup() {
  // You can hide/show sections by role here if needed. Keeping default behavior.
}

function awardPoints(n, reason) {
  appState.points = (appState.points || 0) + (Number(n) || 0)
  saveStateToStorage()
  updateStats()
  if (reason) console.log("[v0] Points awarded:", n, reason)
}

// Added function for admin to change user password
function changeUserPassword(userId) {
  const user = appState.users.find((u) => u.id === userId)
  if (!user) {
    alert("User not found")
    return
  }

  const newPassword = prompt(`Enter new password for ${user.name}:`)
  if (newPassword === null) return // User cancelled

  if (!newPassword.trim()) {
    alert("Password cannot be empty")
    return
  }

  user.password = newPassword // In a real app, you'd hash this password server-side
  saveStateToStorage()
  alert(`Password updated successfully for ${user.name}`)
}

// THIS IS THE UPDATED renderWishlist FUNCTION
function renderWishlist() {
  const host = document.getElementById("wishlistGrid")
  if (!host) return
  const ids = getUserWishlist()
  let arr = (appState.resources || []).filter((r) => ids.includes(r.id))

  const searchInput = document.getElementById("wishlistSearch")
  if (searchInput && searchInput.value.trim()) {
    const query = searchInput.value.toLowerCase()
    arr = arr.filter(
      (r) => r.title.toLowerCase().includes(query) || (r.subject && r.subject.toLowerCase().includes(query)),
    )
  }

  if (arr.length === 0) {
    host.innerHTML =
      '<div class="empty-state"><p>No saved notes yet. Tap the Wishlist icon on a note to save it here.</p></div>'
    return
  }

  const votes = getUserVotes()
  const me = appState.currentUser?.name || ""

  host.innerHTML = arr
    .map((r) => {
      const voted = votes.resources?.[r.id] === "up"
      const saved = true // Always true since we're in wishlist
      return `
      <div class="resource-item">
        <div class="resource-info">
          <h3>${r.title}${r.verified ? ' <span class="verified-badge">✓ Verified</span>' : ""}</h3>
          <p>${r.description || "No description"}</p>
          <div class="resource-meta">
            <span>${withIcon("book", " " + (r.subject || "-"))}</span>
            <span>${withIcon("tag", " " + (r.branch || "-") + " • " + (r.semester || "-"))}</span>
            <span>${withIcon("user", " " + (r.uploadedBy || "-"))}</span>
            <span>${withIcon("calendar", " " + formatDate(r.uploadedAt))}</span>
          </div>
        </div>
        <div class="resource-actions">
          <button class="btn btn-secondary btn-small active" aria-pressed="true" title="Remove from Wishlist" onclick="toggleWishlist(${r.id})">🔖 Saved</button>
          <button class="btn btn-secondary btn-small ${voted ? "active" : ""}" aria-pressed="${voted}" onclick="upvoteResource(${r.id})">${withIcon("arrow-up", " " + (r.upvotes || 0))}</button>
          <button class="btn btn-primary btn-small" onclick="downloadResource(${r.id})">${withIcon("download", " " + (r.downloads || 0))}</button>
          ${(r.uploadedBy || "") === me || isAdmin() ? `<button class="btn btn-secondary btn-small" onclick="deleteResource(${r.id})">Delete</button>` : ""}
        </div>
      </div>`
    })
    .join("")
  host.style.display = "grid"
}

function clearSpecialFilters() {
  appState.viewMyUploads = false
  appState.viewMyPurchases = false
  renderResources()
  renderMarketplace()
}

function updateStudentStats() {
  const resourceCount = (appState.resources || []).filter((r) => r.status === "verified").length
  const eventCount = (appState.userRegistrations || []).length // Assuming userRegistrations will hold this data
  const pointsCount = appState.points || 0
  const postCount = (appState.discussions || []).length

  const studentCountMap = {
    resourceCount: resourceCount,
    eventCount: eventCount,
    pointsCount: pointsCount,
    postCount: postCount,
    totalPoints: pointsCount, // Ensure totalPoints is also updated
  }

  Object.entries(studentCountMap).forEach(([id, val]) => {
    const el = document.getElementById(id)
    if (el) el.textContent = String(val)
  })
}

function updateFacultyStats() {
  const resourceCount = (appState.resources || []).length
  const pendingVerifyCount = (appState.resources || []).filter((r) => r.status === "pending").length
  const postCount = (appState.discussions || []).length

  const facultyCountMap = {
    resourceCount: resourceCount,
    pendingVerifyCount: pendingVerifyCount,
    postCount: postCount,
  }

  Object.entries(facultyCountMap).forEach(([id, val]) => {
    const el = document.getElementById(id)
    if (el) el.textContent = String(val)
  })
}

function updateOrganizerStats() {
  const eventCount = (appState.events || []).length
  const announcementCount = (appState.notifications || []).length

  const organizerCountMap = {
    orgEventCount: eventCount,
    orgAnnouncementCount: announcementCount,
  }

  Object.entries(organizerCountMap).forEach(([id, val]) => {
    const el = document.getElementById(id)
    if (el) el.textContent = String(val)
  })
}

// Updated updateAdminStats function
function updateAdminStats() {
  const userCount = (appState.users || []).length
  const eventCount = (appState.events || []).length
  const postCount = (appState.resources || []).length + (appState.discussions || []).length

  const adminCountMap = {
    adminUserCount: userCount,
    adminEventCount: eventCount,
    adminPostCount: postCount,
  }

  Object.entries(adminCountMap).forEach(([id, val]) => {
    const el = document.getElementById(id)
    if (el) el.textContent = String(val)
  })
}

// Updated updateStats function
function updateStats() {
  const currentRole = localStorage.getItem("userRole")

  if (currentRole === "student") {
    updateStudentStats()
  } else if (currentRole === "teacher") {
    updateFacultyStats()
  } else if (currentRole === "organizer") {
    updateOrganizerStats()
  } else if (currentRole === "admin") {
    updateAdminStats()
  }
}

function loadAndRenderData() {
  loadStateFromStorage()
  renderResources()
  renderMarketplace()
  renderEvents()
  renderLostFound()
  renderDiscussions()
  renderOrganizerEvents()
  renderAnnouncements()
  renderAdminUsers()
  renderOrganizerRequests()
  renderModeration()
  updateStats()
  updateAdminStats()
}

function saveStateToStorage() {
  try {
    const {
      users,
      resources,
      marketplaceItems,
      events,
      lostFoundItems,
      discussions,
      notifications,
      points,
      badges,
      organizerRequests,
      chats,
    } = appState
    const snapshot = {
      users,
      resources,
      marketplaceItems,
      events,
      lostFoundItems,
      discussions,
      notifications,
      points,
      badges,
      organizerRequests,
      chats,
    }
    localStorage.setItem("cc_state", JSON.stringify(snapshot))
    console.log("[v0] State saved to localStorage:", snapshot)
  } catch (e) {
    console.warn("[v0] Failed to save state:", e)
  }
}

function loadStateFromStorage() {
  try {
    const raw = localStorage.getItem("cc_state")
    if (!raw) {
      console.log("[v0] No saved state found in localStorage")
      return
    }
    const data = JSON.parse(raw)
    appState.users = data.users || []
    appState.resources = data.resources || []
    appState.marketplaceItems = data.marketplaceItems || []
    appState.events = data.events || []
    appState.lostFoundItems = data.lostFoundItems || []
    appState.discussions = data.discussions || []
    appState.notifications = data.notifications || []
    appState.points = data.points || 0
    appState.badges = data.badges || []
    appState.organizerRequests = data.organizerRequests || []
    appState.chats = data.chats || {}
    console.log("[v0] State loaded from localStorage. Resources count:", appState.resources.length)
  } catch (e) {
    console.warn("[v0] Failed to load state:", e)
  }
}

function formatDate(iso) {
  try {
    const d = new Date(iso)
    return d.toLocaleDateString()
  } catch {
    return ""
  }
}

function isDigitsOnly(val) {
  return /^[0-9]+$/.test(val || "")
}

function enhanceNumericField(id) {
  const el = document.getElementById(id)
  if (!el) return
  el.addEventListener("input", () => {
    el.value = (el.value || "").replace(/\D+/g, "")
  })
}

function showNotification(msg) {
  // Simple non-blocking toast fallback
  try {
    const n = document.createElement("div")
    n.className = "toast"
    n.textContent = msg
    Object.assign(n.style, {
      position: "fixed",
      bottom: "16px",
      right: "16px",
      background: "rgba(20,25,40,.9)",
      color: "#cfe8ff",
      padding: "10px 14px",
      borderRadius: "10px",
      boxShadow: "0 8px 24px rgba(0,0,0,.3)",
      zIndex: 9999,
    })
    document.body.appendChild(n)
    setTimeout(() => n.remove(), 2000)
  } catch {
    alert(msg)
  }
}

function toggleModal(id) {
  const m = document.getElementById(id)
  if (!m) return
  m.classList.toggle("active")
  m.setAttribute("aria-hidden", m.classList.contains("active") ? "false" : "true")
}

function logout() {
  localStorage.removeItem("currentUser")
  localStorage.removeItem("userRole") // Remove user role on logout
  window.location.href = "dashboard.html"
}
