# Frontend to Backend Integration Guide

## Overview

This guide explains how your frontend (HTML/CSS/JavaScript) communicates with your backend (Node.js/Express) and database (PostgreSQL).

---

## How Communication Works

### The Request-Response Cycle

\`\`\`
1. User clicks "Login" button
   ↓
2. Frontend JavaScript sends HTTP request to backend
   POST http://localhost:5000/api/auth/login
   {
     "regNumber": "23L31A0501",
     "password": "password123"
   }
   ↓
3. Backend receives request
   ↓
4. Backend checks database for user
   ↓
5. Backend validates password
   ↓
6. Backend sends response back to frontend
   {
     "success": true,
     "token": "eyJhbGciOiJIUzI1NiIs...",
     "user": { ... }
   }
   ↓
7. Frontend receives response
   ↓
8. Frontend saves token to localStorage
   ↓
9. Frontend redirects to dashboard
\`\`\`

---

## Step 1: Update Frontend Login Function

### Current Frontend Code (Old - Using localStorage)

\`\`\`javascript
function login() {
  const regNumber = document.getElementById('regNumber').value;
  const password = document.getElementById('password').value;

  // OLD: Checking against localStorage
  const users = JSON.parse(localStorage.getItem('users')) || [];
  const user = users.find(u => u.regNumber === regNumber && u.password === password);

  if (user) {
    localStorage.setItem('currentUser', JSON.stringify(user));
    window.location.href = 'student-dashboard.html';
  } else {
    alert('Invalid credentials');
  }
}
\`\`\`

### New Frontend Code (With Backend)

**Replace the login function in `script.js`:**

\`\`\`javascript
async function login() {
  const regNumber = document.getElementById('regNumber').value;
  const password = document.getElementById('password').value;

  // Validate input
  if (!regNumber || !password) {
    alert('Please enter both registration number and password');
    return;
  }

  try {
    // Send request to backend
    const response = await fetch('http://localhost:5000/api/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        regNumber: regNumber,
        password: password
      })
    });

    // Parse response
    const data = await response.json();

    // Check if login was successful
    if (response.ok && data.success) {
      // Save token (for authenticated requests)
      localStorage.setItem('token', data.token);
      
      // Save user info
      localStorage.setItem('currentUser', JSON.stringify(data.user));

      // Redirect to appropriate dashboard based on role
      const role = data.user.role;
      if (role === 'student') {
        window.location.href = 'student-dashboard.html';
      } else if (role === 'teacher') {
        window.location.href = 'teacher-dashboard.html';
      } else if (role === 'organizer') {
        window.location.href = 'organizer-dashboard.html';
      } else if (role === 'admin') {
        window.location.href = 'admin-dashboard.html';
      }
    } else {
      // Show error message from backend
      alert(data.message || 'Login failed');
    }
  } catch (error) {
    console.error('Login error:', error);
    alert('Connection error. Make sure the backend server is running on http://localhost:5000');
  }
}
\`\`\`

---

## Step 2: Create Helper Function for API Calls

**Add this to your `script.js`:**

\`\`\`javascript
// Helper function to make API calls with authentication
async function apiCall(endpoint, method = 'GET', body = null) {
  const token = localStorage.getItem('token');
  
  const options = {
    method: method,
    headers: {
      'Content-Type': 'application/json'
    }
  };

  // Add token if it exists
  if (token) {
    options.headers['Authorization'] = `Bearer ${token}`;
  }

  // Add body if provided
  if (body) {
    options.body = JSON.stringify(body);
  }

  try {
    const response = await fetch(`http://localhost:5000${endpoint}`, options);
    const data = await response.json();

    if (!response.ok) {
      // If token expired, redirect to login
      if (response.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('currentUser');
        window.location.href = 'login.html';
      }
      throw new Error(data.message || 'API call failed');
    }

    return data;
  } catch (error) {
    console.error('API Error:', error);
    throw error;
  }
}
\`\`\`

---

## Step 3: Update Dashboard Functions

### Example: Load Resources

**Old Code (Using localStorage):**
\`\`\`javascript
function loadResources() {
  const resources = JSON.parse(localStorage.getItem('resources')) || [];
  displayResources(resources);
}
\`\`\`

**New Code (Using Backend):**
\`\`\`javascript
async function loadResources() {
  try {
    const data = await apiCall('/api/resources?status=verified');
    displayResources(data.data);
  } catch (error) {
    console.error('Failed to load resources:', error);
    alert('Failed to load resources');
  }
}
\`\`\`

### Example: Upload Resource

**Old Code:**
\`\`\`javascript
function uploadResource() {
  const title = document.getElementById('resourceTitle').value;
  const subject = document.getElementById('resourceSubject').value;
  
  const resource = {
    id: Date.now(),
    title,
    subject,
    uploadedBy: currentUser.name
  };

  const resources = JSON.parse(localStorage.getItem('resources')) || [];
  resources.push(resource);
  localStorage.setItem('resources', JSON.stringify(resources));
  alert('Resource uploaded');
}
\`\`\`

**New Code:**
\`\`\`javascript
async function uploadResource() {
  const title = document.getElementById('resourceTitle').value;
  const subject = document.getElementById('resourceSubject').value;
  const description = document.getElementById('resourceDescription').value;
  const fileInput = document.getElementById('resourceFile');

  if (!title || !subject || !fileInput.files.length) {
    alert('Please fill all fields');
    return;
  }

  try {
    // Create FormData for file upload
    const formData = new FormData();
    formData.append('title', title);
    formData.append('subject', subject);
    formData.append('description', description);
    formData.append('file', fileInput.files[0]);

    const token = localStorage.getItem('token');
    const response = await fetch('http://localhost:5000/api/resources', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });

    const data = await response.json();

    if (response.ok) {
      alert('Resource uploaded successfully');
      loadResources(); // Reload resources
      document.getElementById('resourceForm').reset();
    } else {
      alert(data.message || 'Upload failed');
    }
  } catch (error) {
    console.error('Upload error:', error);
    alert('Upload failed');
  }
}
\`\`\`

---

## Step 4: Update Event Functions

### Load Events

\`\`\`javascript
async function loadEvents() {
  try {
    const data = await apiCall('/api/events');
    displayEvents(data.data);
  } catch (error) {
    console.error('Failed to load events:', error);
  }
}
\`\`\`

### Register for Event

\`\`\`javascript
async function registerForEvent(eventId) {
  try {
    const data = await apiCall(`/api/events/${eventId}/register`, 'POST');
    alert('Registered successfully');
    loadEvents();
  } catch (error) {
    alert('Registration failed');
  }
}
\`\`\`

---

## Step 5: Update Discussion Functions

### Load Discussions

\`\`\`javascript
async function loadDiscussions(category = 'general') {
  try {
    const data = await apiCall(`/api/discussions?category=${category}`);
    displayDiscussions(data.data);
  } catch (error) {
    console.error('Failed to load discussions:', error);
  }
}
\`\`\`

### Post Discussion

\`\`\`javascript
async function postDiscussion() {
  const title = document.getElementById('discussionTitle').value;
  const content = document.getElementById('discussionContent').value;
  const category = document.getElementById('discussionCategory').value;

  if (!title || !content) {
    alert('Please fill all fields');
    return;
  }

  try {
    const data = await apiCall('/api/discussions', 'POST', {
      title,
      content,
      category
    });

    alert('Discussion posted successfully');
    loadDiscussions(category);
    document.getElementById('discussionForm').reset();
  } catch (error) {
    alert('Failed to post discussion');
  }
}
\`\`\`

### Add Comment

\`\`\`javascript
async function addComment(discussionId) {
  const content = document.getElementById(`commentInput-${discussionId}`).value;

  if (!content) {
    alert('Please enter a comment');
    return;
  }

  try {
    const data = await apiCall(`/api/discussions/${discussionId}/comments`, 'POST', {
      content
    });

    alert('Comment added');
    loadDiscussions(); // Reload to show new comment
  } catch (error) {
    alert('Failed to add comment');
  }
}
\`\`\`

---

## Step 6: Update Marketplace Functions

### Load Marketplace Items

\`\`\`javascript
async function loadMarketplaceItems() {
  try {
    const data = await apiCall('/api/marketplace?sold=false');
    displayMarketplaceItems(data.data);
  } catch (error) {
    console.error('Failed to load items:', error);
  }
}
\`\`\`

### Post Item

\`\`\`javascript
async function postMarketplaceItem() {
  const title = document.getElementById('itemTitle').value;
  const price = document.getElementById('itemPrice').value;
  const description = document.getElementById('itemDescription').value;
  const contact = document.getElementById('itemContact').value;
  const imageInput = document.getElementById('itemImage');

  if (!title || !price || !contact) {
    alert('Please fill all required fields');
    return;
  }

  try {
    const formData = new FormData();
    formData.append('title', title);
    formData.append('price', price);
    formData.append('description', description);
    formData.append('contact', contact);
    if (imageInput.files.length) {
      formData.append('image', imageInput.files[0]);
    }

    const token = localStorage.getItem('token');
    const response = await fetch('http://localhost:5000/api/marketplace', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });

    const data = await response.json();

    if (response.ok) {
      alert('Item posted successfully');
      loadMarketplaceItems();
      document.getElementById('marketplaceForm').reset();
    } else {
      alert(data.message || 'Failed to post item');
    }
  } catch (error) {
    alert('Failed to post item');
  }
}
\`\`\`

---

## Step 7: Update Lost & Found Functions

### Load Lost & Found Items

\`\`\`javascript
async function loadLostFoundItems(type = 'lost') {
  try {
    const data = await apiCall(`/api/lost-found?type=${type}&resolved=false`);
    displayLostFoundItems(data.data);
  } catch (error) {
    console.error('Failed to load items:', error);
  }
}
\`\`\`

### Post Lost/Found Item

\`\`\`javascript
async function postLostFoundItem() {
  const type = document.getElementById('itemType').value;
  const itemName = document.getElementById('itemName').value;
  const description = document.getElementById('itemDescription').value;
  const location = document.getElementById('itemLocation').value;
  const contact = document.getElementById('itemContact').value;
  const imageInput = document.getElementById('itemImage');

  if (!type || !itemName || !location || !contact) {
    alert('Please fill all required fields');
    return;
  }

  try {
    const formData = new FormData();
    formData.append('type', type);
    formData.append('itemName', itemName);
    formData.append('description', description);
    formData.append('location', location);
    formData.append('contact', contact);
    if (imageInput.files.length) {
      formData.append('image', imageInput.files[0]);
    }

    const token = localStorage.getItem('token');
    const response = await fetch('http://localhost:5000/api/lost-found', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`
      },
      body: formData
    });

    const data = await response.json();

    if (response.ok) {
      alert('Item posted successfully');
      loadLostFoundItems(type);
      document.getElementById('lostFoundForm').reset();
    } else {
      alert(data.message || 'Failed to post item');
    }
  } catch (error) {
    alert('Failed to post item');
  }
}
\`\`\`

---

## Step 8: Update Voting Functions

### Upvote Resource

\`\`\`javascript
async function upvoteResource(resourceId) {
  try {
    const data = await apiCall(`/api/resources/${resourceId}/upvote`, 'POST');
    // Update UI to show new upvote count
    document.getElementById(`upvotes-${resourceId}`).textContent = data.upvotes;
  } catch (error) {
    alert('Failed to upvote');
  }
}
\`\`\`

### Upvote Discussion

\`\`\`javascript
async function upvoteDiscussion(discussionId) {
  try {
    const data = await apiCall(`/api/discussions/${discussionId}/upvote`, 'POST');
    document.getElementById(`upvotes-${discussionId}`).textContent = data.upvotes;
  } catch (error) {
    alert('Failed to upvote');
  }
}
\`\`\`

---

## Step 9: Update Logout Function

### Old Code

\`\`\`javascript
function logout() {
  localStorage.removeItem('currentUser');
  window.location.href = 'login.html';
}
\`\`\`

### New Code

\`\`\`javascript
async function logout() {
  try {
    // Optional: Notify backend of logout
    await apiCall('/api/auth/logout', 'POST');
  } catch (error) {
    console.log('Logout notification failed, but continuing...');
  }

  // Clear local storage
  localStorage.removeItem('token');
  localStorage.removeItem('currentUser');

  // Redirect to login
  window.location.href = 'login.html';
}
\`\`\`

---

## Step 10: Add Initialization Function

**Add this to your `script.js` to run when page loads:**

\`\`\`javascript
// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
  // Check if user is logged in
  const token = localStorage.getItem('token');
  const currentUser = localStorage.getItem('currentUser');

  // If on login page and already logged in, redirect to dashboard
  if (window.location.pathname.includes('login.html') && token) {
    const user = JSON.parse(currentUser);
    if (user.role === 'student') {
      window.location.href = 'student-dashboard.html';
    }
    // ... etc for other roles
  }

  // If on dashboard but not logged in, redirect to login
  if (!window.location.pathname.includes('login.html') && !token) {
    window.location.href = 'login.html';
  }

  // Load data for current page
  if (window.location.pathname.includes('student-dashboard.html')) {
    loadResources();
    loadEvents();
    loadDiscussions();
  }
  // ... etc for other pages
});
\`\`\`

---

## Environment Configuration

### Development (Local)

\`\`\`javascript
const API_BASE_URL = 'http://localhost:5000';
\`\`\`

### Production (Deployed)

\`\`\`javascript
const API_BASE_URL = 'https://your-backend-domain.com';
\`\`\`

**Create a config file `config.js`:**

\`\`\`javascript
const API_BASE_URL = process.env.NODE_ENV === 'production'
  ? 'https://your-backend-domain.com'
  : 'http://localhost:5000';

export { API_BASE_URL };
\`\`\`

---

## Error Handling

### Common Errors & Solutions

**Error: "Failed to fetch"**
- Backend is not running
- CORS is not enabled
- Wrong URL

**Error: "401 Unauthorized"**
- Token is missing or expired
- User needs to login again

**Error: "400 Bad Request"**
- Missing required fields
- Invalid data format

**Error: "500 Internal Server Error"**
- Backend error
- Check backend logs

---

## Testing Integration

### Using Postman

1. **Test Login:**
   - Method: POST
   - URL: http://localhost:5000/api/auth/login
   - Body: `{"regNumber": "23L31A0501", "password": "password123"}`
   - Expected: Token in response

2. **Test Protected Endpoint:**
   - Method: GET
   - URL: http://localhost:5000/api/resources
   - Headers: `Authorization: Bearer {token}`
   - Expected: List of resources

---

## Checklist

- [ ] Backend is running (`npm start`)
- [ ] Database is connected
- [ ] Frontend login function updated
- [ ] API helper function created
- [ ] All dashboard functions updated
- [ ] Token is saved after login
- [ ] Token is sent with requests
- [ ] Logout clears token
- [ ] Error handling implemented
- [ ] Tested with Postman
- [ ] Tested with frontend

---

## Next Steps

1. Implement all API endpoints in backend
2. Add input validation
3. Add error handling
4. Add file upload functionality
5. Deploy to production
6. Monitor and optimize

Good luck! 🚀
